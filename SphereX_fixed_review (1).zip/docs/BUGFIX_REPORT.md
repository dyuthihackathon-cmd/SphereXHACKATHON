# SphereX Bug-Fix Report

## Fixes applied

1. **Frontend/backend routing:** Vite now listens on port `5173` and proxies `/api` to the FastAPI backend on `127.0.0.1:8000`. This fixes the previous standalone Vite setup, which sent relative `/api` calls to the SPA fallback instead of the Python API.
2. **Python environment discovery:** `server.ts` now detects both `backend/.venv` and `backend/venv` on Windows and POSIX. An empty `SPHEREX_PYTHON_BIN` in `.env.example` allows automatic detection.
3. **WISE/SPHEREx FITS cache validation:** archive bytes are validated as readable FITS images before they are cached. Invalid cached responses are deleted and retried instead of causing persistent repeat failures.
4. **HTTP Range safety:** range downloads now require HTTP `206`, the exact `Content-Range`, identity content encoding, and the exact requested byte count. Servers that ignore Range are rejected before their full response is consumed.
5. **SPHEREx cube numeric decoding:** all standard FITS `BITPIX` types are mapped correctly; `BSCALE`/`BZERO` are applied; byte-range row offsets and edge-pixel flag indexing are corrected; out-of-tile coordinates are rejected instead of silently sampling a tile edge.
6. **Frontend code splitting:** Observations, Spectral, Time Domain, Compare, Sources, Moving Objects, and Research workspaces are lazy-loaded with a loading fallback.
7. **Hero image:** the 1920×1280 JPEG was converted to an 800×533 WebP. The served image is approximately 56 KB instead of 1.2 MB (about 95% smaller). The original asset is preserved under `project_reference/` and is no longer exposed as a public static asset.
8. **Render-blocking fonts:** the external Google Fonts stylesheet and preconnects were removed. The UI now uses local system font stacks, avoiding the external font CSS request.
9. **SEO assets:** added a plain-text `public/robots.txt` and a SphereX SVG favicon.
10. **Accessibility:** added accessible names to responsive/icon-only toolbar controls, including PNG export, playback, previous/next, center/reset, stretch, and quality controls.
11. **Coordinate formatting:** RA and DEC sexagesimal formatting now rounds before splitting fields, avoiding invalid `60.00s` / `60.0″` output at carry boundaries.
12. **Fullscreen state:** the UI now listens for `fullscreenchange`, so pressing Escape updates the fullscreen control state.
13. **Windows scripts and setup docs:** the production start and clean scripts are cross-platform; README ports and dual-terminal instructions now match the Vite proxy configuration.

## Verification performed in the review environment

- Python syntax compilation: passed (`python -m compileall -q backend`).
- Frontend utility tests: 12 passed using Node's TypeScript type stripping test runner.
- New HTTP archive-safety tests: 4 passed (`python -m pytest -q backend/tests/test_http_utils.py`).
- ZIP integrity: passed.
- Optimized hero asset: verified as 800×533 WebP, approximately 56 KB.

## Verification still required on the project machine

- The full Vite production build and TypeScript type-check were not completed in this review environment because `npm ci` timed out while retrieving packages; the local `node_modules` tree was therefore incomplete.
- The full scientific backend suite was not run here because this environment did not have the project's astronomy dependencies installed (`astropy`, `astroquery`, `photutils`, `pyarrow`, and `pyvo`). The four new HTTP transport/cache tests did pass.
- Live NASA/IPAC, SPHEREx S3, WISE, Gaia, and ZTF archive availability cannot be guaranteed by a code-only review. Re-run the archive status endpoint and feature tests with network access.

No mock astronomical observations or synthetic scientific measurements were added by these fixes.
