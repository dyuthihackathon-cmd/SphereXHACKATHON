# SphereX Scientific Methodology & Numerical Guarantees

SphereX adheres strictly to traceable, reproducible astronomical computation: no fabricated fluxes, no unpropagated variance claims, and explicit coordinate/time-frame definitions.

## 1. Celestial Projections & Coordinate Frames
- **All-Sky Viewer (`SkyViewer.tsx` + `src/utils/coordinates.ts`)**:
  - Uses true **Gnomonic (TAN)** tangent-plane projection anchored on field center $(\alpha_0, \delta_0)$ in **ICRS (J2000)** degrees.
  - HiPS basemaps fetch **Górski HEALPix NESTED** order-3 tiles (`NSIDE = 8`, `Npix = 768` all-sky faces) and project $(u, v)$ texture coordinates per screen pixel onto the TAN plane (`src/utils/healpix.ts`), verified directly against `astropy_healpix` across benchmark fields (including M31 `Npix677`).
  - Equatorial-to-Galactic transformations apply exact IAU rotation matrices matching Astropy `SkyCoord(..., frame="galactic")`.
- **FITS Cutouts (`wcs_service.py`)**:
  - Server-side coordinate queries parse actual FITS headers (including `-HPX` cubes and `-TAN-SIP` distorted cutouts) via `astropy.wcs.WCS`.
  - When rendering PNG previews, arrays are vertically inverted (`np.flipud`) so North-up / FITS bottom-left pixel $(0, 0)$ aligns visually with celestial orientation; client clicks invert normalized $y$ back to $(1 - y_{\text{norm}}) \cdot (H - 1)$ before querying `/api/coordinates/pixel-to-world`.

## 2. SPHEREx DR1 102-Channel Spectral Cube Extraction
- **Tile Location**: `HEALPix(nside=32, order="nested", frame="icrs")` resolves $(\text{RA}, \text{Dec}) \to \text{Npix}$.
- **Memory & Bandwidth Discipline**:
  - Rather than downloading ~320 MB 3D FITS cubes per lookup, `spherex_cube_service.py` parses FITS HDU byte offsets via small HTTP Range requests.
  - Axis-3 `-TAB` WCS keywords (`CTYPE3='WAVE-TAB'`, `PS3_*`, `PV3_*`, `PC3_*`) are stripped cleanly from a copy of the `IMAGE` header so `astropy.wcs.WCS` constructs the 2D `RA---HPX` / `DEC--HPX` plane without requiring the full trailing binary table HDU.
  - Individual channel flux/aperture values, `NHITS` depth, and `FLAGS` bitmasks are fetched in parallel via small HTTP Range byte spans (~1 MB total per 102-channel spectrum).
- **Blank Channels & Uncertainties**:
  - Official channels **51** (`D3:17`) and **52** (`D4:01`) are explicitly left as `null` (`blank_dichroic_gap`) and never interpolated.
  - Because DR1 cubes omit a `VARIANCE` HDU, `NHITS` is shown strictly as exposure count depth—**zero synthetic $1\sigma$ error bars are plotted**.

## 3. Image Registration & Difference Imaging (`difference_imaging_service.py`)
- Observation B is reprojected onto Observation A's exact 2D WCS grid using `reproject.reproject_interp`. Overlap below 5% is rejected (`422`).
- Optional **sigma-clipped background matching** measures median sky offsets on overlapping valid pixels (`astropy.stats.sigma_clipped_stats`, $\sigma = 3.0$) and aligns B's zero-level prior to subtraction $D = A - (B_{\text{reproj}} + \Delta_{\text{bg}})$.
- **Variance Propagation Discipline**:
  - Significance maps ($S = D / \sqrt{\text{Var}_A + \text{Var}_B}$) are computed **only** if *both* input FITS files contain positive overlapping `VARIANCE` extensions. Otherwise `has_significance_map = false` and an explicit notice is surfaced.

## 4. Gaia DR3 Proper Motion Propagation (`proper_motion_service.py`)
- Input astrometry defaults to Gaia DR3 reference epoch **J2016.0** (`SkyCoord(..., obstime=Time(2016.0, format="jyear"))`).
- Propagates to target epoch $t$ via `coord.apply_space_motion(new_obstime=Time(t, format="jyear"))`.
- **Missing Radial Velocity**: When `radial_velocity` is absent in Gaia DR3 (common for faint/cool targets such as brown dwarfs), propagation uses tangential motion cleanly and appends an explicit note disclosing zero radial velocity assumption.
- **Positional Error Propagation**: Computes $\sigma_{\alpha*}(t) = \sqrt{\sigma_{\alpha*,0}^2 + (\Delta t \cdot \sigma_{\mu_\alpha})^2}$ and $\sigma_\delta(t) = \sqrt{\sigma_{\delta,0}^2 + (\Delta t \cdot \sigma_{\mu_\delta})^2}$ in milliarcseconds whenever catalogue uncertainties are present.

## 5. Multi-Epoch Time-Domain Photometry & Moving Objects
- **NEOWISE-R**: Separates accepted points (`qual_frame > 0`, clean `cc_flags`, unmasked by moon/SAA) from rejected points, enforcing angular separation $\le r_{\text{assoc}}$ so nearby blended contaminants are visible in the rejected table rather than silently biasing light curves.
- **ZTF DR24 HATS**: Uses O(1) S3 delimiter discovery and `_healpix_29` Parquet footer statistics pruning prior to cone extraction (`lightcurve.hmjd`, `mag`, `magerr`, `catflags`).
- **Moving-Object Tracklet Linking**: Runs background-subtracted `photutils.detection.DAOStarFinder`, links detections within user radius constraints across epochs, cross-matches against Gaia DR3 (when online), and assigns **only** one of the 6 conservative classifications—never claiming unverified detections as confirmed discoveries.
