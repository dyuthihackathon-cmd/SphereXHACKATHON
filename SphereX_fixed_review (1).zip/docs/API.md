# SphereX Scientific FastAPI Reference (`/api`)

All browser UI requests route through `/api/*` (proxied on port `3000` by `server.ts` to the Python FastAPI backend on `127.0.0.1:8000`). OpenAPI interactive documentation is available at `/docs` on the backend port (`http://127.0.0.1:8000/docs`).

## Error Semantics
- `422 Unprocessable Entity`: Invalid celestial coordinates (`ra ∉ [0, 360)`, `dec ∉ [-90, 90]`), missing WCS headers, insufficient overlap (`< 5%`), or blank SPHEREx cube channel (`51` or `52`) requested for FITS/PNG slicing.
- `502 / 503 Provider Unavailable`: External archive upstream outage or timeout. Errors surface verbatim provenance and are never masked with mock responses.

---

## Endpoints

### System & Provenance
- `GET /api/health` — Returns local FastAPI bridge health & configured dataset registry keys.
- `GET /api/archive/status` — Probes external archive providers live (SPHEREx S3, IRSA HiPS, IRSA SIA, WISE S3, ZTF S3, Gaia Primary & Mirror, JPL Horizons, MAST Pan-STARRS) returning per-provider HTTP status.
- `GET /api/resolve-target?name={query}` — Resolves object identifier via SIMBAD Sesame / challenge benchmark table to ICRS `(ra, dec)`.

### Archive Observations & Cutout Rendering
- `GET /api/observations?ra=&dec=&fov_arcmin=&release={dr1|qr3|both}&include_deep=&start_date=&end_date=&limit=` — Searches SPHEREx IRSA SIAv2 collections and parses VOTable metadata.
- `GET /api/observations/preview?access_url=&ra=&dec=&fov_arcmin=&stretch={linear|log|asinh|sqrt|zscale}&palette={monochrome|spherex_ir|cyan_amber|plasma|magma|viridis}&ext_name={IMAGE|VARIANCE|FLAGS|ZODI}` — Server-side Astropy cutout + stretch PNG render.
- `GET /api/observations/inspect?access_url=&ra=&dec=&fov_arcmin=&ext_name=` — Inspects MEF extension dimensions, missing/NaN pixel count, `FLAGS` mask counts, `VARIANCE`/`ZODI` availability, median flux/SNR, and FITS provenance headers.
- `GET /api/observations/fits?access_url=&ra=&dec=&fov_arcmin=` — Downloads WCS-calibrated multi-extension cutout FITS.

### SPHEREx DR1 102-Channel All-Sky Cube
- `GET /api/spherex/channels` — Returns the official 102-channel wavelength array (`0.753–4.988 µm`) and marks blank channels `[51, 52]`.
- `GET /api/spherex/cube/search?ra=&dec=` — Resolves `(ra, dec)` to HEALPix order-5 NESTED tile (`npix`, S3 URL, HiPS URL, pixel `(x, y)`).
- `GET /api/spherex/cube/spectrum?ra=&dec=&aperture_radius_px={0..3}&mask_flagged={true|false}` — Streams target spatial column via HTTP Range across active channels; includes `NHITS`, `FLAGS`, explicit blank-channel entries, and provenance.
- `GET /api/spherex/cube/slice.png?ra=&dec=&channel={1..102}&stretch=&palette=` — Renders 2D sky plane for a single spectral channel. (Returns `422` for channels 51–52.)
- `GET /api/spherex/cube/slice.fits?ra=&dec=&channel={1..102}` — Exports WCS-calibrated 2D single-channel FITS file.

### WISE & NEOWISE-R
- `GET /api/wise/images?ra=&dec=&radius_arcmin=&collection=&limit=` — Searches WISE/AllWISE/NEOWISE-R science images via IRSA.
- `GET /api/wise/preview`, `GET /api/wise/inspect`, `GET /api/wise/fits` — WCS cutout PNG rendering, quality inspection, and FITS export.
- `GET /api/neowise/lightcurve?ra=&dec=&radius_arcsec=&association_radius_arcsec=&partitions=` — Streams NEOWISE-R S3 Parquet partitions and returns `accepted` vs `rejected` photometry with flag diagnostics.

### ESA Gaia DR3 & Proper Motion
- `GET /api/gaia/sources?ra=&dec=&radius_arcmin=&limit=&max_g_mag=` — ADQL cone search on Gaia DR3 (`gea.esac.esa.int` with ARI Heidelberg fallback).
- `POST /api/gaia/propagate` — Propagates J2016.0 astrometry (`ra, dec, pmra, pmdec, parallax, radial_velocity`) to `target_epoch_year` via Astropy `apply_space_motion`, returning displacement, position angle, uncertainty propagation, and multi-epoch track points.

### ZTF DR24 & Reference Catalogues
- `GET /api/ztf/images?ra=&dec=&radius_arcmin=&limit=` — Searches ZTF science exposures via IRSA IBE.
- `GET /api/ztf/lightcurve?ra=&dec=&radius_arcsec=` — Streams ZTF DR24 HATS Parquet light curve tiles over HTTP Range.
- `GET /api/reference/panstarrs?ra=&dec=&radius_arcmin=&limit=` — STScI MAST Pan-STARRS DR2 MeanObject cone search.
- `GET /api/reference/twomass?ra=&dec=&radius_arcmin=&limit=` — IRSA 2MASS Point Source Catalog ADQL cone search.

### WCS, Image Comparison, Moving Objects & Ephemerides
- `GET /api/coordinates/pixel-to-world` & `GET /api/coordinates/world-to-pixel` — Exact Astropy WCS FITS pixel <-> ICRS sky coordinate conversions.
- `POST /api/compare/difference` & `POST /api/compare/difference.fits` — WCS reprojection (`reproject_interp`), background subtraction, variance propagation, difference PNG/FITS export.
- `GET /api/sources/detect` — Single-frame Photutils `DAOStarFinder` source extraction.
- `POST /api/moving-objects/candidates` — Multi-epoch source detection & tracklet linking across 2–8 loaded FITS frames.
- `GET /api/horizons/ephemeris?command=&start_time=&stop_time=&step_size=&center=` — Live NASA JPL Horizons observer ephemeris.
- `GET /api/mpc/observations?designation=&limit=` & `GET /api/mpc/orbit?designation=` — Live IAU MPC ADES observations and orbital elements.

### IRSA HiPS Sky Proxy
- `GET /api/hips/surveys` — Lists configured HiPS survey keys.
- `GET /api/hips/{survey_id}/tile?order=&npix=&frame=` — Proxies IRSA HiPS tile imagery with 24h HTTP cache headers.
