"""ESA Gaia DR3 source catalogue cone search and variability metadata service."""
from __future__ import annotations

from typing import Any

from config import DATASET_REGISTRY
from services.http_utils import ProviderUnavailableError, fetch_json
from services.provenance_service import build_provenance


def query_gaia_sources(
    *,
    ra: float,
    dec: float,
    radius_arcmin: float = 3.0,
    limit: int = 100,
    max_g_mag: float | None = None,
) -> dict[str, Any]:
    radius_deg = radius_arcmin / 60.0
    mag_clause = f"AND phot_g_mean_mag <= {float(max_g_mag):.4f}" if max_g_mag is not None else ""
    adql = f"""
    SELECT TOP {limit}
      source_id, ra, dec, ref_epoch,
      ra_error, dec_error, parallax, parallax_error,
      pmra, pmra_error, pmdec, pmdec_error,
      radial_velocity, radial_velocity_error,
      phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag,
      astrometric_excess_noise, ruwe, phot_variable_flag
    FROM {DATASET_REGISTRY["gaia"]["table_source"]}
    WHERE 1 = CONTAINS(
      POINT('ICRS', ra, dec),
      CIRCLE('ICRS', {ra:.10f}, {dec:.10f}, {radius_deg:.10f})
    )
    {mag_clause}
    ORDER BY phot_g_mean_mag ASC
    """
    endpoints = [DATASET_REGISTRY["gaia"]["tap_primary"], *DATASET_REGISTRY["gaia"]["tap_mirrors"]]
    last_errors: list[str] = []

    for endpoint in endpoints:
        try:
            payload = fetch_json(
                endpoint,
                method="POST",
                data={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "json", "QUERY": adql},
                timeout=(5, 25),
                provider="ESA Gaia DR3 TAP",
            )
            fields = payload.get("metadata", [])
            rows = payload.get("data", [])
            names = [f.get("name") for f in fields]
            sources = [dict(zip(names, row)) for row in rows]
            return {
                "status": "ok" if sources else "no_coverage",
                "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin, "limit": limit},
                "count": len(sources),
                "sources": sources,
                "tap_endpoint_used": endpoint,
                "ref_epoch": 2016.0,
                "source": "ESA Gaia Data Release 3 (gaiadr3.gaia_source)",
                "archive_note": "Live Gaia DR3 TAP cone search. Missing measurements remain null.",
                "provenance": build_provenance(
                    data_provider="European Space Agency (ESA) Gaia Archive",
                    mission_survey="ESA Gaia DR3",
                    data_release="DR3",
                    archive_collection="gaiadr3.gaia_source",
                    source_or_obs_id=f"cone({ra:.5f},{dec:.5f},{radius_arcmin}arcmin)",
                    archive_url=endpoint,
                    ra=ra,
                    dec=dec,
                    units="deg, mas, mas/yr, mag",
                    spherex_processing="Live ADQL cone search",
                ),
            }
        except Exception as exc:
            last_errors.append(f"{endpoint}: {exc}")

    raise ProviderUnavailableError(
        f"Gaia DR3 TAP endpoints unreachable: {'; '.join(last_errors)}",
        provider="ESA Gaia DR3",
    )
