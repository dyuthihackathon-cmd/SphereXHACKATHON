"""Resilient HTTP client, range-read helpers, caching, and structured archive errors."""
from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Any, Callable

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import ARCHIVE_TIMEOUT_SEC, CACHE_DIR, MAX_DOWNLOAD_BYTES

logger = logging.getLogger("spherex.http")


class ArchiveError(Exception):
    status_code = 502
    error_code = "archive_error"

    def __init__(self, message: str, *, provider: str = "Archive", status_code: int | None = None):
        super().__init__(message)
        self.provider = provider
        if status_code is not None:
            self.status_code = status_code


class ProviderUnavailableError(ArchiveError):
    status_code = 502
    error_code = "provider_unavailable"


class InvalidQueryError(ArchiveError):
    status_code = 400
    error_code = "invalid_query"


class FileUnavailableError(ArchiveError):
    status_code = 404
    error_code = "file_unavailable"


class UnsupportedProductError(ArchiveError):
    status_code = 422
    error_code = "unsupported_data_product"


def get_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=2,
        backoff_factor=0.6,
        status_forcelist=[429, 500, 503, 504],
        allowed_methods=["GET", "HEAD", "POST"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=16, pool_maxsize=16)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update({"User-Agent": "SphereX-Scientific-Explorer/1.0"})
    return session


_SESSION = get_session()


def fetch_bytes(
    url: str,
    *,
    params: dict[str, Any] | None = None,
    timeout: float = ARCHIVE_TIMEOUT_SEC,
    max_bytes: int = MAX_DOWNLOAD_BYTES,
    cache_key: str | None = None,
    provider: str = "External Archive",
    validator: Callable[[bytes], None] | None = None,
) -> bytes:
    if cache_key:
        cache_path = _cache_path(cache_key)
        if cache_path.exists() and cache_path.stat().st_size > 0:
            cached = cache_path.read_bytes()
            try:
                if validator:
                    validator(cached)
                return cached
            except Exception:
                # Do not let a previously cached HTML/error response poison future retries.
                cache_path.unlink(missing_ok=True)

    try:
        with _SESSION.get(url, params=params, timeout=timeout, stream=True) as resp:
            if resp.status_code == 404:
                raise FileUnavailableError(f"{provider} returned 404 Not Found for {url}", provider=provider)
            if resp.status_code >= 500:
                raise ProviderUnavailableError(
                    f"{provider} returned HTTP {resp.status_code}",
                    provider=provider,
                    status_code=502,
                )
            resp.raise_for_status()
            content_len = resp.headers.get("Content-Length")
            if content_len and int(content_len) > max_bytes:
                raise UnsupportedProductError(
                    f"Archive object ({int(content_len) / (1024*1024):.1f} MB) exceeds safety limit ({max_bytes / (1024*1024):.0f} MB).",
                    provider=provider,
                )
            chunks: list[bytes] = []
            total = 0
            for chunk in resp.iter_content(chunk_size=131072):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    raise UnsupportedProductError(
                        f"Streamed archive download exceeded {max_bytes / (1024*1024):.0f} MB safety cap.",
                        provider=provider,
                    )
                chunks.append(chunk)
            data = b"".join(chunks)
    except ArchiveError:
        raise
    except requests.RequestException as exc:
        raise ProviderUnavailableError(f"{provider} request failed: {exc}", provider=provider) from exc

    if validator:
        validator(data)

    if cache_key and data:
        cache_path = _cache_path(cache_key)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_bytes(data)
    return data


def fetch_range(
    url: str,
    start: int,
    end: int,
    *,
    timeout: float = ARCHIVE_TIMEOUT_SEC,
    provider: str = "Archive S3",
) -> bytes:
    """Fetch exactly one HTTP byte range; reject servers that ignore Range requests."""
    if start < 0 or end < start:
        raise ValueError("Invalid byte range: expected 0 <= start <= end.")

    headers = {"Range": f"bytes={start}-{end}", "Accept-Encoding": "identity"}
    expected_size = end - start + 1
    try:
        with _SESSION.get(url, headers=headers, timeout=timeout, stream=True) as resp:
            if resp.status_code == 404:
                raise FileUnavailableError(f"Resource not found: {url}", provider=provider)
            if resp.status_code >= 500:
                raise ProviderUnavailableError(f"{provider} returned HTTP {resp.status_code}", provider=provider)
            if resp.status_code != 206:
                raise ProviderUnavailableError(
                    f"{provider} did not honor the requested byte range (HTTP {resp.status_code}; expected 206).",
                    provider=provider,
                )

            content_range = resp.headers.get("Content-Range", "")
            expected_prefix = f"bytes {start}-{end}/"
            if not content_range.startswith(expected_prefix):
                raise ProviderUnavailableError(
                    f"{provider} returned an unexpected Content-Range header: {content_range or 'missing'}.",
                    provider=provider,
                )

            resp.raise_for_status()
            chunks: list[bytes] = []
            total = 0
            for chunk in resp.iter_content(chunk_size=min(131072, expected_size)):
                if not chunk:
                    continue
                total += len(chunk)
                if total > expected_size:
                    raise ProviderUnavailableError(
                        f"{provider} returned more bytes than requested ({total} > {expected_size}).",
                        provider=provider,
                    )
                chunks.append(chunk)
            data = b"".join(chunks)
            if len(data) != expected_size:
                raise ProviderUnavailableError(
                    f"{provider} returned an incomplete byte range ({len(data)} of {expected_size} bytes).",
                    provider=provider,
                )
            return data
    except ArchiveError:
        raise
    except requests.RequestException as exc:
        raise ProviderUnavailableError(f"{provider} range request failed: {exc}", provider=provider) from exc


def fetch_json(
    url: str,
    *,
    method: str = "GET",
    params: dict[str, Any] | None = None,
    data: dict[str, Any] | None = None,
    json_body: Any = None,
    timeout: float = ARCHIVE_TIMEOUT_SEC,
    provider: str = "Archive API",
) -> Any:
    try:
        resp = _SESSION.request(method, url, params=params, data=data, json=json_body, timeout=timeout)
        if resp.status_code == 404:
            raise FileUnavailableError(f"{provider} returned 404 Not Found", provider=provider)
        if resp.status_code >= 500:
            raise ProviderUnavailableError(f"{provider} returned HTTP {resp.status_code}", provider=provider)
        resp.raise_for_status()
        return resp.json()
    except ArchiveError:
        raise
    except ValueError as exc:
        raise ProviderUnavailableError(f"{provider} returned non-JSON response: {exc}", provider=provider) from exc
    except requests.RequestException as exc:
        raise ProviderUnavailableError(f"{provider} request failed: {exc}", provider=provider) from exc


def _cache_path(cache_key: str) -> Path:
    digest = hashlib.sha256(cache_key.encode("utf-8")).hexdigest()
    return CACHE_DIR / digest[:2] / digest
