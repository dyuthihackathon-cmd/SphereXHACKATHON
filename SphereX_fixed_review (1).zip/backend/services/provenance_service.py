"""Standardized scientific provenance tracking for every archive result."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_provenance(
    *,
    data_provider: str,
    mission_survey: str,
    data_release: str,
    archive_collection: str,
    source_or_obs_id: str,
    archive_url: str,
    observation_timestamp: str | None = None,
    ra: float | None = None,
    dec: float | None = None,
    instrument_detector: str | None = None,
    wavelength_or_filter: str | None = None,
    units: str | None = None,
    quality_flags: Any = None,
    uncertainties: Any = None,
    processing_version: str | None = None,
    spherex_processing: str = "Retrieved directly from archive without synthetic modification",
) -> dict[str, Any]:
    return {
        "data_provider": data_provider,
        "mission_survey": mission_survey,
        "data_release": data_release or "Not available",
        "archive_collection": archive_collection or "Not available",
        "source_or_obs_id": source_or_obs_id or "Not available",
        "archive_url": archive_url,
        "observation_timestamp": observation_timestamp or "Not available",
        "ra": ra,
        "dec": dec,
        "instrument_detector": instrument_detector or "Not available",
        "wavelength_or_filter": wavelength_or_filter or "Not available",
        "units": units or "Not available",
        "quality_flags": quality_flags if quality_flags is not None else "Not available",
        "uncertainties": uncertainties if uncertainties is not None else "Not available",
        "processing_version": processing_version or "Not available",
        "retrieval_timestamp": utc_now_iso(),
        "spherex_processing": spherex_processing,
    }
