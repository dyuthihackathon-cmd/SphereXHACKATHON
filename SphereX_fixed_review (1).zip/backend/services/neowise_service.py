"""NEOWISE-R Single-Exposure Parquet and unWISE Time-Domain Parquet light-curve service.

Uses HEALPix order-5 (k5) NESTED spatial partitioning on public S3 bucket `nasa-irsa-wise`
and PyArrow column projection so only relevant partitions and columns are retrieved.
Separates accepted detections from flagged/contaminated or unassociated nearby detections.
"""
from __future__ import annotations

import io
from concurrent.futures import ThreadPoolExecutor
from datetime import timezone
from typing import Any

import numpy as np
import pyarrow.parquet as pq
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.time import Time
from astropy_healpix import HEALPix

from config import DATASET_REGISTRY
from services.http_utils import FileUnavailableError, fetch_bytes
from services.provenance_service import build_provenance

HPX_K5 = HEALPix(nside=32, order="nested", frame="icrs")

NEOWISE_COLUMNS = [
    "source_id",
    "ra",
    "dec",
    "mjd",
    "w1mpro",
    "w1sigmpro",
    "w2mpro",
    "w2sigmpro",
    "qual_frame",
    "ph_qual",
    "cc_flags",
    "moon_masked",
    "saa_sep",
]


def _healpix_k5_and_k0(ra: float, dec: float) -> tuple[int, int]:
    coord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")
    k5 = int(HPX_K5.skycoord_to_healpix(coord))
    k0 = k5 // 1024
    return k5, k0


def _angular_sep_arcsec(ra1: float, dec1: float, ra2: np.ndarray, dec2: np.ndarray) -> np.ndarray:
    c1 = SkyCoord(ra=ra1 * u.deg, dec=dec1 * u.deg, frame="icrs")
    c2 = SkyCoord(ra=ra2 * u.deg, dec=dec2 * u.deg, frame="icrs")
    return c1.separation(c2).arcsec


def _quality_assessment(row: dict[str, Any]) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    qual_frame = row.get("qual_frame")
    if qual_frame is not None and int(qual_frame) == 0:
        reasons.append("qual_frame=0 (low frame quality)")
    cc_flags = str(row.get("cc_flags") or "0000")
    if len(cc_flags) >= 2 and cc_flags[:2] != "00":
        reasons.append(f"cc_flags={cc_flags} (artifact/confusion warning)")
    moon_masked = str(row.get("moon_masked") or "00")
    if len(moon_masked) >= 2 and moon_masked[:2] != "00":
        reasons.append(f"moon_masked={moon_masked}")
    saa_sep = row.get("saa_sep")
    if saa_sep is not None and float(saa_sep) < 0:
        reasons.append("Inside SAA (saa_sep < 0)")
    ph_qual = str(row.get("ph_qual") or "")
    if len(ph_qual) >= 2 and ph_qual[0] in ("U", "X") and ph_qual[1] in ("U", "X"):
        reasons.append(f"ph_qual={ph_qual} (upper limit / no detection)")
    return len(reasons) == 0, reasons


def query_neowise_lightcurve(
    *,
    ra: float,
    dec: float,
    radius_arcsec: float = 5.0,
    partitions: list[str] | None = None,
    association_radius_arcsec: float = 2.5,
) -> dict[str, Any]:
    """Query NEOWISE-R single-exposure Parquet partitions for (ra, dec)."""
    k5, k0 = _healpix_k5_and_k0(ra, dec)
    bucket_url = DATASET_REGISTRY["wise"]["s3_bucket_url"]
    cat_prefix = DATASET_REGISTRY["wise"]["s3_neowiser_catalog"]
    all_parts = DATASET_REGISTRY["wise"]["neowiser_partitions"]
    selected_parts = [p for p in (partitions or all_parts) if p in all_parts]
    if not selected_parts:
        selected_parts = all_parts

    def load_partition(part: str) -> tuple[str, list[dict[str, Any]], str | None]:
        key = f"{cat_prefix}/{part}/neowiser-healpix_k5-{part}.parquet/healpix_k0={k0}/healpix_k5={k5}/part0.snappy.parquet"
        url = f"{bucket_url}/{key}"
        try:
            raw = fetch_bytes(url, cache_key=f"neowise:{part}:{k5}", timeout=30, provider="NEOWISE-R S3")
            table = pq.read_table(io.BytesIO(raw), columns=NEOWISE_COLUMNS)
            df_ra = table["ra"].to_numpy(zero_copy_only=False).astype(float)
            df_dec = table["dec"].to_numpy(zero_copy_only=False).astype(float)
            # Fast bounding-box prefilter before exact spherical separation
            cos_dec = max(0.1, float(np.cos(np.radians(dec))))
            tol_deg = (radius_arcsec / 3600.0) * 1.25
            box_mask = (np.abs(df_dec - dec) <= tol_deg) & (np.abs(((df_ra - ra + 180) % 360) - 180) * cos_dec <= tol_deg)
            indices = np.where(box_mask)[0]
            if len(indices) == 0:
                return part, [], None
            seps = _angular_sep_arcsec(ra, dec, df_ra[indices], df_dec[indices])
            within = indices[seps <= radius_arcsec]
            within_seps = seps[seps <= radius_arcsec]
            rows_out: list[dict[str, Any]] = []
            pydict = table.take(within).to_pydict()
            for idx_pos in range(len(within)):
                mjd_val = float(pydict["mjd"][idx_pos])
                utc_iso = Time(mjd_val, format="mjd", scale="utc").to_datetime(timezone=timezone.utc).isoformat()
                rec = {
                    "partition": part,
                    "source_id": str(pydict["source_id"][idx_pos]),
                    "ra": float(pydict["ra"][idx_pos]),
                    "dec": float(pydict["dec"][idx_pos]),
                    "sep_arcsec": round(float(within_seps[idx_pos]), 4),
                    "mjd": mjd_val,
                    "utc": utc_iso,
                    "w1mpro": _finite_or_none(pydict["w1mpro"][idx_pos]),
                    "w1sigmpro": _finite_or_none(pydict["w1sigmpro"][idx_pos]),
                    "w2mpro": _finite_or_none(pydict["w2mpro"][idx_pos]),
                    "w2sigmpro": _finite_or_none(pydict["w2sigmpro"][idx_pos]),
                    "qual_frame": int(pydict["qual_frame"][idx_pos]) if pydict["qual_frame"][idx_pos] is not None else None,
                    "ph_qual": str(pydict["ph_qual"][idx_pos] or ""),
                    "cc_flags": str(pydict["cc_flags"][idx_pos] or ""),
                    "moon_masked": str(pydict["moon_masked"][idx_pos] or ""),
                    "saa_sep": _finite_or_none(pydict["saa_sep"][idx_pos]),
                }
                is_clean, warnings = _quality_assessment(rec)
                associated = rec["sep_arcsec"] <= association_radius_arcsec
                if not associated:
                    warnings.append(f"Separation {rec['sep_arcsec']}″ exceeds association radius ({association_radius_arcsec}″); may be a neighbor source")
                rec["accepted"] = bool(is_clean and associated)
                rec["warnings"] = warnings
                rows_out.append(rec)
            return part, rows_out, None
        except FileUnavailableError:
            return part, [], None
        except Exception as exc:
            return part, [], f"{part}: {exc}"

    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(load_partition, selected_parts))

    detections: list[dict[str, Any]] = []
    errors: list[str] = []
    for _, rows, err in results:
        detections.extend(rows)
        if err:
            errors.append(err)

    detections.sort(key=lambda r: r["mjd"])
    accepted = [d for d in detections if d["accepted"]]
    rejected = [d for d in detections if not d["accepted"]]

    return {
        "status": "ok" if (detections or not errors) else "provider_unavailable",
        "query": {
            "ra": ra,
            "dec": dec,
            "radius_arcsec": radius_arcsec,
            "association_radius_arcsec": association_radius_arcsec,
            "healpix_k5": k5,
            "healpix_k0": k0,
            "partitions_queried": selected_parts,
        },
        "total_detections": len(detections),
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "accepted": accepted,
        "rejected": rejected,
        "errors": errors,
        "association_note": (
            f"Detections within {radius_arcsec}″ of target are grouped by angular separation (<= {association_radius_arcsec}″) "
            "and filtered using qual_frame, cc_flags, moon_masked, saa_sep, and ph_qual. Rejected/neighbor detections are retained separately."
        ),
        "provenance": build_provenance(
            data_provider="NASA/IPAC IRSA (AWS Open Data S3 nasa-irsa-wise)",
            mission_survey="NASA NEOWISE-R Single-Exposure Source Table",
            data_release="NEOWISE-R Year 1–11 + Addendum",
            archive_collection="wise/neowiser/catalogs/p1bs_psd/healpix_k5",
            source_or_obs_id=f"healpix_k5={k5}",
            archive_url=f"{bucket_url}/{cat_prefix}",
            ra=ra,
            dec=dec,
            wavelength_or_filter="W1 (3.4 µm), W2 (4.6 µm)",
            units="Vega mag (w1mpro, w2mpro)",
            spherex_processing="HEALPix k5 spatial partition read via PyArrow + quality/association separation",
        ),
    }


def _finite_or_none(v: Any) -> float | None:
    if v is None:
        return None
    try:
        f = float(v)
        return f if np.isfinite(f) else None
    except (TypeError, ValueError):
        return None
