"""NASA SPHEREx Level-2 spectral image archive search, cutout download, and rendering."""
from __future__ import annotations

import io
from datetime import timezone
from typing import Any
from urllib.parse import urlparse

import numpy as np
from astropy.io import fits
from astropy.time import Time
from astroquery.ipac.irsa import Irsa

from config import DATASET_REGISTRY
from services.fits_service import build_fits_export, inspect_mef, render_array_to_png
from services.http_utils import InvalidQueryError, ProviderUnavailableError, fetch_bytes
from services.provenance_service import build_provenance

COLLECTION_MAP = {
    "dr1": ["spherex_dr1"],
    "qr3": ["spherex_qr3"],
    "both": ["spherex_dr1", "spherex_qr3"],
}


def _row_val(row: Any, names: tuple[str, ...], default: Any = None) -> Any:
    keys = {str(k).lower(): k for k in row.colnames}
    for name in names:
        key = keys.get(name.lower())
        if key is None:
            continue
        val = row[key]
        if np.ma.is_masked(val):
            continue
        if isinstance(val, bytes):
            return val.decode("utf-8", "replace")
        if hasattr(val, "item"):
            try:
                val = val.item()
            except Exception:
                pass
        return val
    return default


def _as_float(val: Any) -> float | None:
    try:
        f = float(val)
        return f if np.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _mjd_to_iso(val: Any) -> str | None:
    mjd = _as_float(val)
    if mjd is None:
        return None
    try:
        return Time(mjd, format="mjd", scale="utc").to_datetime(timezone=timezone.utc).isoformat()
    except Exception:
        return None


def search_spherex_observations(
    *,
    ra: float,
    dec: float,
    fov_arcmin: float = 6.0,
    release: str = "both",
    include_deep: bool = False,
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    radius_deg = fov_arcmin / 60.0 / 2.0
    base_collections = COLLECTION_MAP.get(release, ["spherex_dr1", "spherex_qr3"])
    collections = list(base_collections)
    if include_deep:
        collections = [c for item in base_collections for c in (item, f"{item}_deep")]

    start_mjd_filter = None
    end_mjd_filter = None
    if start_date:
        start_mjd_filter = Time(start_date, scale="utc").mjd
    if end_date:
        end_mjd_filter = Time(end_date, scale="utc").mjd + 1.0

    records: list[dict[str, Any]] = []
    errors: list[str] = []
    collections_succeeded: list[str] = []

    for collection in collections:
        try:
            table = Irsa.query_sia(pos=(ra, dec, radius_deg), collection=collection, maxrec=limit)
            collections_succeeded.append(collection)
            for row in table:
                access_url = str(_row_val(row, ("access_url", "accessurl"), "") or "")
                if not access_url:
                    continue
                t_min = _as_float(_row_val(row, ("t_min", "tmin")))
                t_max = _as_float(_row_val(row, ("t_max", "tmax")))
                if start_mjd_filter is not None and (t_min is None or t_min < start_mjd_filter):
                    continue
                if end_mjd_filter is not None and (t_min is None or t_min > end_mjd_filter):
                    continue

                obs_id = str(_row_val(row, ("obs_id", "obsid", "obs_publisher_did"), "") or "")
                if not obs_id:
                    continue
                s_ra = _as_float(_row_val(row, ("s_ra", "sra")))
                s_dec = _as_float(_row_val(row, ("s_dec", "sdec")))
                em_min = _as_float(_row_val(row, ("em_min", "emmin")))
                em_max = _as_float(_row_val(row, ("em_max", "emmax")))
                instrument = str(_row_val(row, ("instrument_name", "instrume"), "SPHEREx") or "SPHEREx")
                start_iso = _mjd_to_iso(t_min)
                end_iso = _mjd_to_iso(t_max)

                rel_label = "DR1" if "dr1" in collection else ("QR3" if "qr3" in collection else collection)
                wl_label = (
                    f"{em_min * 1e6:.3f}–{em_max * 1e6:.3f} µm"
                    if em_min is not None and em_max is not None
                    else "Not available"
                )
                records.append({
                    "id": obs_id,
                    "mission": "SPHEREx",
                    "collection": collection,
                    "release": rel_label,
                    "target": str(_row_val(row, ("target_name", "targetname"), "") or "Not available"),
                    "instrument": instrument,
                    "ra": s_ra,
                    "dec": s_dec,
                    "start_mjd": t_min,
                    "end_mjd": t_max,
                    "start_time": start_iso,
                    "end_time": end_iso,
                    "wavelength_min_m": em_min,
                    "wavelength_max_m": em_max,
                    "wavelength_label": wl_label,
                    "data_product_type": str(_row_val(row, ("dataproduct_type",), "image") or "image"),
                    "calibration_level": _as_float(_row_val(row, ("calib_level", "caliblevel"))),
                    "access_url": access_url,
                    "access_format": str(_row_val(row, ("access_format", "accessformat"), "application/fits") or ""),
                    "source": DATASET_REGISTRY["spherex"]["provider"],
                    "provenance": build_provenance(
                        data_provider=DATASET_REGISTRY["spherex"]["provider"],
                        mission_survey="NASA SPHEREx",
                        data_release=rel_label,
                        archive_collection=collection,
                        source_or_obs_id=obs_id,
                        archive_url=access_url,
                        observation_timestamp=start_iso,
                        ra=s_ra,
                        dec=s_dec,
                        instrument_detector=instrument,
                        wavelength_or_filter=wl_label,
                        units="MJy/sr",
                    ),
                })
        except Exception as exc:
            errors.append(f"{collection}: {type(exc).__name__}: {exc}")

    records.sort(key=lambda item: (item["start_mjd"] is None, item["start_mjd"] or 0.0, item["id"]))
    seen: set[tuple[str, str]] = set()
    unique: list[dict[str, Any]] = []
    for rec in records:
        key = (rec["id"], rec["access_url"])
        if key not in seen:
            seen.add(key)
            unique.append(rec)

    if errors and not collections_succeeded:
        raise ProviderUnavailableError(
            f"All SPHEREx IRSA SIA2 queries failed: {'; '.join(errors)}",
            provider="NASA/IPAC IRSA SPHEREx SIA2",
        )

    status = "ok" if not errors else "partial"
    if not unique and not errors:
        status = "no_coverage"

    return {
        "status": status,
        "query": {
            "ra": ra,
            "dec": dec,
            "fov_arcmin": fov_arcmin,
            "release": release,
            "include_deep": include_deep,
        },
        "count": len(unique[:limit]),
        "total_matched": len(unique),
        "observations": unique[:limit],
        "collections_queried": collections,
        "collections_succeeded": collections_succeeded,
        "errors": errors,
        "archive_note": "Live IRSA SIA2 query against time-resolved SPHEREx Level-2 spectral-image collections.",
    }


def validate_spherex_url(access_url: str) -> None:
    parsed = urlparse(access_url)
    allowed_hosts = {"irsa.ipac.caltech.edu", "nasa-irsa-spherex.s3.amazonaws.com"}
    if parsed.scheme != "https" or parsed.hostname not in allowed_hosts:
        raise InvalidQueryError(
            "Only official IRSA SPHEREx HTTPS URLs (irsa.ipac.caltech.edu or nasa-irsa-spherex.s3.amazonaws.com) are accepted.",
            provider="SPHEREx",
        )
    if parsed.hostname == "irsa.ipac.caltech.edu" and not (
        parsed.path.startswith("/ibe/data/spherex/") or parsed.path.startswith("/data/SPHEREx/")
    ):
        raise InvalidQueryError("Unrecognized IRSA SPHEREx image path.", provider="SPHEREx")


def _validate_spherex_fits_payload(raw: bytes) -> None:
    if not raw.startswith(b"SIMPLE  ="):
        raise ProviderUnavailableError("IRSA returned a non-FITS response for the requested cutout.", provider="IRSA SPHEREx")
    try:
        with fits.open(io.BytesIO(raw), memmap=False, lazy_load_hdus=False) as hdul:
            if not any(getattr(hdu, "data", None) is not None and np.asarray(hdu.data).ndim == 2 for hdu in hdul):
                raise ValueError("No two-dimensional image HDU was found.")
    except ProviderUnavailableError:
        raise
    except Exception as exc:
        raise ProviderUnavailableError(f"IRSA returned an invalid or unreadable FITS cutout: {exc}", provider="IRSA SPHEREx") from exc


def fetch_spherex_cutout_bytes(
    *,
    access_url: str,
    ra: float,
    dec: float,
    fov_arcmin: float,
) -> bytes:
    validate_spherex_url(access_url)
    size_deg = fov_arcmin / 60.0
    params = {"center": f"{ra:.8f},{dec:.8f}", "size": f"{size_deg:.6f}"} if "irsa.ipac.caltech.edu" in access_url else None
    cache_key = f"spx_cutout:{access_url}:{ra:.6f}:{dec:.6f}:{size_deg:.5f}"
    return fetch_bytes(
        access_url,
        params=params,
        cache_key=cache_key,
        provider="NASA/IPAC IRSA SPHEREx",
        validator=_validate_spherex_fits_payload,
    )


def render_spherex_preview(
    *,
    access_url: str,
    ra: float,
    dec: float,
    fov_arcmin: float,
    stretch: str = "asinh",
    palette: str = "monochrome",
    ext_name: str = "IMAGE",
) -> tuple[bytes, dict[str, str]]:
    raw = fetch_spherex_cutout_bytes(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    with fits.open(io.BytesIO(raw), memmap=False) as hdul:
        hdu = next((h for h in hdul if getattr(h, "name", "").upper() == ext_name.upper() and getattr(h, "data", None) is not None), None)
        if hdu is None:
            hdu = next((h for h in hdul[1:] if getattr(h, "data", None) is not None and np.asarray(h.data).ndim == 2), None)
        if hdu is None:
            raise ValueError(f"Extension '{ext_name}' was not found in this FITS cutout.")
        data = np.asarray(hdu.data, dtype=np.float32)
        png = render_array_to_png(data, stretch=stretch, palette=palette)
        headers = {
            "X-Spherex-Preview-Units": str(hdu.header.get("BUNIT", "MJy/sr")),
            "X-Spherex-Preview-Extension": str(getattr(hdu, "name", ext_name)),
            "X-Spherex-Preview-Shape": f"{data.shape[1]}x{data.shape[0]}",
            "X-Spherex-Preview-Stretch": stretch,
            "X-Spherex-Preview-Palette": palette,
        }
        return png, headers


def inspect_spherex_cutout(*, access_url: str, ra: float, dec: float, fov_arcmin: float, ext_name: str = "IMAGE") -> dict[str, Any]:
    raw = fetch_spherex_cutout_bytes(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    info = inspect_mef(raw, preferred_ext=ext_name)
    info["provenance"] = build_provenance(
        data_provider=DATASET_REGISTRY["spherex"]["provider"],
        mission_survey="NASA SPHEREx",
        data_release="DR1/QR3",
        archive_collection="Level-2 Spectral Image MEF",
        source_or_obs_id=access_url.rsplit("/", 1)[-1],
        archive_url=access_url,
        ra=ra,
        dec=dec,
        units=info["quality"].get("bunit"),
        spherex_processing="Astropy MEF extension inspection and WCS footprint extraction",
    )
    return info


def export_spherex_cutout_fits(*, access_url: str, ra: float, dec: float, fov_arcmin: float) -> bytes:
    raw = fetch_spherex_cutout_bytes(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    with fits.open(io.BytesIO(raw), memmap=False) as hdul:
        sci = next((h for h in hdul if getattr(h, "name", "").upper() == "IMAGE" and getattr(h, "data", None) is not None), hdul[0])
        var = next((h for h in hdul if getattr(h, "name", "").upper() == "VARIANCE" and getattr(h, "data", None) is not None), None)
        prov = build_provenance(
            data_provider=DATASET_REGISTRY["spherex"]["provider"],
            mission_survey="NASA SPHEREx",
            data_release="Level-2",
            archive_collection="spherex",
            source_or_obs_id=access_url.rsplit("/", 1)[-1],
            archive_url=access_url,
            ra=ra,
            dec=dec,
            units=str(sci.header.get("BUNIT", "MJy/sr")),
            spherex_processing="Cutout FITS export preserving WCS and provenance",
        )
        return build_fits_export(
            np.asarray(sci.data, dtype=np.float32),
            sci.header,
            bunit=str(sci.header.get("BUNIT", "MJy/sr")),
            provenance=prov,
            variance=np.asarray(var.data, dtype=np.float32) if var is not None else None,
        )
