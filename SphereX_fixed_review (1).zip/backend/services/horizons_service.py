"""NASA JPL Horizons ephemeris query and parsing service."""
from __future__ import annotations

import re
from typing import Any

from config import DATASET_REGISTRY
from services.http_utils import InvalidQueryError, ProviderUnavailableError, fetch_json
from services.provenance_service import build_provenance

# Quantities: 1=Astrometric RA/Dec, 3=Rates (dRA*cosD, dDec), 9=Visual mag & SB, 20=Observer range
QUANTITIES = "1,3,9,20"


def query_horizons_ephemeris(
    *,
    command: str,
    start_time: str,
    stop_time: str,
    step_size: str = "1 d",
    center: str = "500@399",
) -> dict[str, Any]:
    cmd = command.strip()
    if not cmd:
        raise InvalidQueryError("Horizons object designation/command is required.", provider="JPL Horizons")

    # Quote string designations unless already quoted or purely numeric SPK-ID
    formatted_cmd = cmd if (cmd.startswith("'") or cmd.isdigit()) else f"'{cmd}'"

    params = {
        "format": "json",
        "COMMAND": formatted_cmd,
        "OBJ_DATA": "YES",
        "MAKE_EPHEM": "YES",
        "EPHEM_TYPE": "OBSERVER",
        "CENTER": f"'{center.strip()}'",
        "START_TIME": f"'{start_time.strip()}'",
        "STOP_TIME": f"'{stop_time.strip()}'",
        "STEP_SIZE": f"'{step_size.strip()}'",
        "ANG_FORMAT": "DEG",
        "CAL_FORMAT": "BOTH",
        "QUANTITIES": f"'{QUANTITIES}'",
        "CSV_FORMAT": "YES",
    }

    payload = fetch_json(
        DATASET_REGISTRY["horizons"]["api_url"],
        params=params,
        timeout=30,
        provider="NASA JPL Horizons",
    )
    result_text = str(payload.get("result") or "")
    if not result_text:
        raise ProviderUnavailableError("JPL Horizons returned an empty result block.", provider="JPL Horizons")

    if "Multiple major-bodies match" in result_text or "Matching small-bodies" in result_text:
        # Return ambiguity explicitly instead of guessing!
        matches = [line.strip() for line in result_text.splitlines() if re.search(r"^\s*\d+", line)][:12]
        raise InvalidQueryError(
            f"Object designation '{cmd}' is ambiguous in JPL Horizons. Specify an exact ID. Matches: {'; '.join(matches)}",
            provider="JPL Horizons",
        )
    if "No matches found" in result_text or "Cannot interpret" in result_text:
        raise InvalidQueryError(f"JPL Horizons found no matching object for '{cmd}'.", provider="JPL Horizons")

    soe = result_text.find("$$SOE")
    eoe = result_text.find("$$EOE")
    if soe == -1 or eoe == -1:
        raise ProviderUnavailableError("JPL Horizons response did not contain $$SOE/$$EOE ephemeris rows.", provider="JPL Horizons")

    target_line = next((ln.strip() for ln in result_text.splitlines() if ln.strip().startswith("Target body name:")), "")
    center_line = next((ln.strip() for ln in result_text.splitlines() if ln.strip().startswith("Center-site name:")), "")

    # Extract CSV column headers right before $$SOE
    pre_soe_lines = [ln.strip() for ln in result_text[:soe].splitlines() if ln.strip()]
    header_line = ""
    for ln in reversed(pre_soe_lines):
        if "Date__" in ln and "," in ln:
            header_line = ln
            break
    headers = [h.strip() for h in header_line.split(",")] if header_line else []

    rows: list[dict[str, Any]] = []
    block = result_text[soe + 5 : eoe].strip()
    for line in block.splitlines():
        if not line.strip():
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 5:
            continue
        # Horizons CSV format with CAL_FORMAT=BOTH: Date__(UT)__HR:MN, Date_________JDUT, , , R.A._(ICRF), DEC__(ICRF), dRA*cosD, d(DEC)/dt, APmag, S-brt, delta, deldot
        utc_str = parts[0]
        jd_val = _safe_float(parts[1])
        # Find numeric RA/Dec columns after blank solar/lunar presence markers
        numeric_tail = [_safe_float(p) for p in parts[4:]]
        ra_deg = numeric_tail[0] if len(numeric_tail) > 0 else None
        dec_deg = numeric_tail[1] if len(numeric_tail) > 1 else None
        dra_arcsec_hr = numeric_tail[2] if len(numeric_tail) > 2 else None
        ddec_arcsec_hr = numeric_tail[3] if len(numeric_tail) > 3 else None
        ap_mag = numeric_tail[4] if len(numeric_tail) > 4 else None
        delta_au = numeric_tail[6] if len(numeric_tail) > 6 else None
        rows.append({
            "utc": utc_str,
            "jd_utc": jd_val,
            "ra_deg": ra_deg,
            "dec_deg": dec_deg,
            "dra_cosd_arcsec_hr": dra_arcsec_hr,
            "ddec_arcsec_hr": ddec_arcsec_hr,
            "ap_mag": ap_mag,
            "delta_au": delta_au,
        })

    return {
        "status": "ok" if rows else "no_coverage",
        "command": cmd,
        "target_body": target_line.replace("Target body name:", "").strip() or cmd,
        "observer_center": center_line.replace("Center-site name:", "").strip() or center,
        "coordinate_system": "ICRF / J2000 Astrometric",
        "time_scale": "UT / JDUT",
        "step_size": step_size,
        "headers": headers,
        "count": len(rows),
        "ephemeris": rows,
        "provenance": build_provenance(
            data_provider=DATASET_REGISTRY["horizons"]["provider"],
            mission_survey="NASA JPL Horizons",
            data_release="Live API v1.2",
            archive_collection="HORIZONS",
            source_or_obs_id=target_line or cmd,
            archive_url=DATASET_REGISTRY["horizons"]["api_url"],
            ra=rows[0]["ra_deg"] if rows else None,
            dec=rows[0]["dec_deg"] if rows else None,
            units="deg, arcsec/hr, mag, AU",
            spherex_processing="Live JPL Horizons API ephemeris query",
        ),
    }


def _safe_float(val: str) -> float | None:
    try:
        return float(val)
    except (TypeError, ValueError):
        return None
