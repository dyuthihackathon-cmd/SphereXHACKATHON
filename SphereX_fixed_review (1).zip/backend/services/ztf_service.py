"""Zwicky Transient Facility (ZTF) Public DR24 objects, light curves, and image metadata."""
from __future__ import annotations

import io
import json
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import timezone
from functools import lru_cache
from typing import Any

import numpy as np
import pyarrow.parquet as pq
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.time import Time
from astropy_healpix import HEALPix

from config import DATASET_REGISTRY
from services.http_utils import FileUnavailableError, ProviderUnavailableError, fetch_bytes, fetch_range, get_session
from services.provenance_service import build_provenance

_S3_NS = {"s": "http://s3.amazonaws.com/doc/2006-03-01/"}


class SeekableHttpFile(io.RawIOBase):
    """Read-only seekable file over HTTP Range so PyArrow reads only needed Parquet row groups/columns."""

    def __init__(self, url: str, timeout: float = 35.0, provider: str = "ZTF DR24 S3"):
        super().__init__()
        self.url = url
        self.timeout = timeout
        self.provider = provider
        self._pos = 0
        resp = get_session().head(url, timeout=timeout)
        if resp.status_code == 404:
            raise FileUnavailableError(f"Resource not found: {url}", provider=provider)
        resp.raise_for_status()
        self.size = int(resp.headers["Content-Length"])

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self._pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if whence == io.SEEK_SET:
            self._pos = max(0, offset)
        elif whence == io.SEEK_CUR:
            self._pos = max(0, self._pos + offset)
        elif whence == io.SEEK_END:
            self._pos = max(0, self.size + offset)
        return self._pos

    def read(self, size: int = -1) -> bytes:
        if self._pos >= self.size:
            return b""
        end = self.size - 1 if size < 0 else min(self.size - 1, self._pos + size - 1)
        data = fetch_range(self.url, self._pos, end, timeout=self.timeout, provider=self.provider)
        self._pos += len(data)
        return data

    def readinto(self, b: bytearray) -> int:
        chunk = self.read(len(b))
        n = len(chunk)
        b[:n] = chunk
        return n


@lru_cache(maxsize=8)
def _list_hats_norders(prefix: str) -> list[int]:
    """List top-level Norder=* directories in 1 fast S3 delimiter query."""
    bucket = DATASET_REGISTRY["ztf"]["s3_bucket_url"]
    url = f"{bucket}/?list-type=2&prefix={prefix}/&delimiter=/"
    raw = fetch_bytes(url, timeout=15, provider="ZTF DR24 S3")
    root = ET.fromstring(raw)
    orders: list[int] = []
    for elem in root.findall(".//s:CommonPrefixes/s:Prefix", _S3_NS):
        txt = (elem.text or "").rstrip("/")
        tail = txt.rsplit("/", 1)[-1]
        if tail.startswith("Norder="):
            try:
                orders.append(int(tail.split("=", 1)[1]))
            except ValueError:
                pass
    return sorted(orders)


def _find_ztf_parquet_keys(ra: float, dec: float, prefix: str) -> list[str]:
    """Resolve matching HATS tile keys for (ra, dec) in O(len(norders)) via direct S3 path checks."""
    orders = _list_hats_norders(prefix)
    if not orders:
        return []
    bucket = DATASET_REGISTRY["ztf"]["s3_bucket_url"]
    coord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")

    def check_order(order: int) -> str | None:
        hpx = HEALPix(nside=2 ** order, order="nested", frame="icrs")
        npix = int(hpx.skycoord_to_healpix(coord))
        dir_idx = (npix // 10000) * 10000
        candidate = f"{prefix}/Norder={order}/Dir={dir_idx}/Npix={npix}/part0.snappy.parquet"
        try:
            resp = get_session().head(f"{bucket}/{candidate}", timeout=8)
            if resp.status_code == 200:
                return candidate
        except Exception:
            pass
        return None

    with ThreadPoolExecutor(max_workers=6) as pool:
        found = [k for k in pool.map(check_order, orders) if k]
    return found


def search_ztf_images(
    *,
    ra: float,
    dec: float,
    radius_arcmin: float = 3.0,
    limit: int = 50,
) -> dict[str, Any]:
    """Query IRSA ZTF IBE/SIA science exposures; falls back to reporting HATS DR24 coverage."""
    size_deg = (radius_arcmin / 60.0) * 2.0
    ibe_url = DATASET_REGISTRY["ztf"]["sia_url"]
    try:
        raw = fetch_bytes(
            ibe_url,
            params={"POS": f"{ra:.6f},{dec:.6f}", "SIZE": f"{size_deg:.5f}", "FORMAT": "json"},
            timeout=(6, 18),
            provider="IRSA ZTF IBE",
        )
        payload = json.loads(raw.decode("utf-8", "replace"))
        rows = payload if isinstance(payload, list) else payload.get("data", [])
        images: list[dict[str, Any]] = []
        for row in rows[:limit]:
            obs_date = row.get("obsdate") or row.get("mjdobs")
            images.append({
                "id": str(row.get("filefracday") or row.get("expid") or f"ztf-{len(images)+1}"),
                "filter": row.get("filtercode") or row.get("fid") or "Not available",
                "obsdate": str(obs_date or "Not available"),
                "ra": row.get("ra"),
                "dec": row.get("dec"),
                "maglimit": row.get("maglimit"),
                "seeing": row.get("seeing"),
                "source": "Caltech/IPAC-IRSA ZTF",
            })
        return {
            "status": "ok" if images else "no_coverage",
            "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin},
            "count": len(images),
            "images": images,
            "coverage_note": (
                "ZTF primarily covers Dec > -30° (Palomar 48-inch). Missing regions reflect genuine telescope footprint limits."
                if not images
                else "Live ZTF science image metadata from IRSA."
            ),
        }
    except Exception as exc:
        dr24_keys = _find_ztf_parquet_keys(ra, dec, DATASET_REGISTRY["ztf"]["s3_dr24_objects_prefix"])
        return {
            "status": "partial" if dr24_keys else "provider_unavailable",
            "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin},
            "count": 0,
            "images": [],
            "dr24_hats_tiles_covering_position": dr24_keys,
            "error": str(exc),
            "coverage_note": (
                f"IRSA ZTF image query unavailable ({exc}). "
                + (
                    f"ZTF DR24 HATS object tiles exist on S3 for this position ({len(dr24_keys)} tile)."
                    if dr24_keys
                    else "No ZTF DR24 HATS tile covers this sky coordinate (likely outside ZTF Dec > -30° footprint)."
                )
            ),
        }


_FILTER_LABELS = {1: "zg", 2: "zr", 3: "zi"}


def query_ztf_dr24_lightcurve(
    *,
    ra: float,
    dec: float,
    radius_arcsec: float = 3.0,
) -> dict[str, Any]:
    """Query ZTF DR24 HATS Parquet lightcurve tiles on ipac-irsa-ztf S3 using HTTP Range."""
    bucket = DATASET_REGISTRY["ztf"]["s3_bucket_url"]
    lc_prefix = DATASET_REGISTRY["ztf"]["s3_dr24_lc_prefix"]
    obj_prefix = DATASET_REGISTRY["ztf"]["s3_dr24_objects_prefix"]

    lc_keys = _find_ztf_parquet_keys(ra, dec, lc_prefix)
    obj_keys = _find_ztf_parquet_keys(ra, dec, obj_prefix) if not lc_keys else []

    if not lc_keys and not obj_keys:
        return {
            "status": "no_coverage",
            "query": {"ra": ra, "dec": dec, "radius_arcsec": radius_arcsec},
            "object_count": 0,
            "objects": [],
            "point_count": 0,
            "points": [],
            "coverage_note": "No ZTF DR24 HATS partition covers this coordinate (ZTF observes from Palomar, roughly Dec > -30°).",
        }

    target = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")
    npix29 = int(HEALPix(nside=2 ** 29, order="nested", frame="icrs").skycoord_to_healpix(target))
    # Coarse margin (~1 arcmin at order-29) so cone boundary crossings aren't skipped
    hpx29_margin = 1 << 24
    cos_dec = max(0.1, float(np.cos(np.radians(dec))))
    tol = (radius_arcsec / 3600.0) * 1.25
    matched_objects: list[dict[str, Any]] = []
    lc_points: list[dict[str, Any]] = []
    source_urls: list[str] = []

    for key in lc_keys[:1]:
        url = f"{bucket}/{key}"
        source_urls.append(url)
        try:
            remote_file = SeekableHttpFile(url, timeout=30.0, provider="ZTF DR24 S3")
            pf = pq.ParquetFile(remote_file)
            schema_names = set(pf.schema_arrow.names)
            ra_col = "objra" if "objra" in schema_names else "ra"
            dec_col = "objdec" if "objdec" in schema_names else "dec"

            # Prune row groups using _healpix_29 min/max statistics from Parquet footer
            candidate_rgs: list[int] = []
            for rg_idx in range(pf.num_row_groups):
                rg_meta = pf.metadata.row_group(rg_idx)
                hpx_min = hpx_max = None
                for c_idx in range(rg_meta.num_columns):
                    col_meta = rg_meta.column(c_idx)
                    if col_meta.path_in_schema == "_healpix_29" and col_meta.statistics:
                        hpx_min = col_meta.statistics.min
                        hpx_max = col_meta.statistics.max
                        break
                if hpx_min is not None and hpx_max is not None:
                    if hpx_max < (npix29 - hpx29_margin) or hpx_min > (npix29 + hpx29_margin):
                        continue
                candidate_rgs.append(rg_idx)

            rg_matches: list[tuple[int, np.ndarray]] = []
            for rg_idx in candidate_rgs:
                rg_tbl = pf.read_row_group(rg_idx, columns=[ra_col, dec_col])
                ras = rg_tbl[ra_col].to_numpy(zero_copy_only=False).astype(float)
                decs = rg_tbl[dec_col].to_numpy(zero_copy_only=False).astype(float)
                mask = (np.abs(decs - dec) <= tol) & (np.abs(((ras - ra + 180) % 360) - 180) * cos_dec <= tol)
                idx = np.where(mask)[0]
                if len(idx):
                    coords = SkyCoord(ra=ras[idx] * u.deg, dec=decs[idx] * u.deg, frame="icrs")
                    seps = target.separation(coords).arcsec
                    keep = idx[seps <= radius_arcsec]
                    if len(keep):
                        rg_matches.append((rg_idx, keep))

            extra_cols = [
                c for c in ("objectid", ra_col, dec_col, "filterid", "nepochs", "lightcurve")
                if c in schema_names
            ]
            for rg_idx, keep in rg_matches:
                full_tbl = pf.read_row_group(rg_idx, columns=extra_cols)
                sub = full_tbl.take(keep).to_pydict()
                n_rows = len(keep)
                for i in range(n_rows):
                    obj_id = str(sub.get("objectid", [None] * n_rows)[i] or "Unknown")
                    fid = sub.get("filterid", [None] * n_rows)[i]
                    filter_label = _FILTER_LABELS.get(int(fid), str(fid)) if fid is not None else "Unknown"
                    matched_objects.append({
                        "objectid": obj_id,
                        "ra": float(sub[ra_col][i]),
                        "dec": float(sub[dec_col][i]),
                        "filterid": fid,
                        "filter_name": filter_label,
                        "nepochs": sub.get("nepochs", [None] * n_rows)[i],
                    })
                    lc_struct = sub.get("lightcurve", [None] * n_rows)[i] or {}
                    hmjd = lc_struct.get("hmjd") or []
                    mags = lc_struct.get("mag") or []
                    errs = lc_struct.get("magerr") or []
                    flags = lc_struct.get("catflags") or []
                    for j in range(min(len(hmjd), len(mags))):
                        mjd_f = float(hmjd[j])
                        lc_points.append({
                            "objectid": obj_id,
                            "filterid": fid,
                            "filter_name": filter_label,
                            "mjd": mjd_f,
                            "utc": Time(mjd_f, format="mjd", scale="utc").to_datetime(timezone=timezone.utc).isoformat(),
                            "mag": float(mags[j]),
                            "magerr": float(errs[j]) if j < len(errs) and errs[j] is not None else None,
                            "catflags": int(flags[j]) if j < len(flags) and flags[j] is not None else None,
                        })
        except FileUnavailableError:
            continue
        except Exception as exc:
            raise ProviderUnavailableError(f"ZTF DR24 S3 range read failed: {exc}", provider="ZTF DR24 S3") from exc

    lc_points.sort(key=lambda p: p["mjd"])
    return {
        "status": "ok" if (matched_objects or lc_points) else "no_coverage",
        "query": {"ra": ra, "dec": dec, "radius_arcsec": radius_arcsec},
        "object_count": len(matched_objects),
        "objects": matched_objects[:50],
        "point_count": len(lc_points),
        "points": lc_points[:3000],
        "tiles_checked": lc_keys[:1] or obj_keys[:1],
        "provenance": build_provenance(
            data_provider="Caltech/IPAC-IRSA ZTF (AWS Open Data S3 ipac-irsa-ztf)",
            mission_survey="ZTF Public DR24",
            data_release="DR24",
            archive_collection="ztf/enhanced/dr24/lc/hats",
            source_or_obs_id=matched_objects[0]["objectid"] if matched_objects else f"cone({ra:.4f},{dec:.4f})",
            archive_url=source_urls[0] if source_urls else f"{bucket}/{lc_prefix}",
            ra=ra,
            dec=dec,
            wavelength_or_filter="zg, zr, zi",
            units="AB mag",
            spherex_processing="ZTF DR24 HATS HTTP-Range Parquet lookup with _healpix_29 row-group pruning",
        ),
    }
