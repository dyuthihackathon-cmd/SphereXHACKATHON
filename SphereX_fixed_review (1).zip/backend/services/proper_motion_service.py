"""Gaia DR3 proper-motion propagation using Astropy SkyCoord and apply_space_motion."""
from __future__ import annotations

import math
from typing import Any

import numpy as np
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.time import Time

from services.provenance_service import build_provenance


def propagate_gaia_proper_motion(
    *,
    source_id: str | int,
    ra: float,
    dec: float,
    pmra: float | None,
    pmdec: float | None,
    parallax: float | None = None,
    radial_velocity: float | None = None,
    ref_epoch: float = 2016.0,
    target_epoch_year: float = 2026.0,
    ra_error_mas: float | None = None,
    dec_error_mas: float | None = None,
    pmra_error: float | None = None,
    pmdec_error: float | None = None,
    n_trajectory_steps: int = 10,
) -> dict[str, Any]:
    """Propagate an ICRS Gaia source from `ref_epoch` (J2016.0) to `target_epoch_year`."""
    if pmra is None or pmdec is None or not (np.isfinite(pmra) and np.isfinite(pmdec)):
        raise ValueError("Cannot propagate proper motion: source lacks measured pmra or pmdec in Gaia DR3.")

    t_ref = Time(ref_epoch, format="jyear", scale="tcb")
    t_target = Time(target_epoch_year, format="jyear", scale="tcb")
    dt_years = float((t_target - t_ref).to(u.yr).value)

    # Handle missing parallax/radial velocity cleanly without inventing distances when parallax <= 0.
    kwargs: dict[str, Any] = {
        "ra": ra * u.deg,
        "dec": dec * u.deg,
        "pm_ra_cosdec": float(pmra) * u.mas / u.yr,
        "pm_dec": float(pmdec) * u.mas / u.yr,
        "obstime": t_ref,
        "frame": "icrs",
    }
    distance_used_pc = None
    if parallax is not None and np.isfinite(parallax) and float(parallax) > 0.05:
        distance_used_pc = 1000.0 / float(parallax)
        kwargs["distance"] = distance_used_pc * u.pc
    if radial_velocity is not None and np.isfinite(radial_velocity) and distance_used_pc is not None:
        kwargs["radial_velocity"] = float(radial_velocity) * u.km / u.s

    origin = SkyCoord(**kwargs)
    propagated = origin.apply_space_motion(new_obstime=t_target)
    sep_arcsec = float(origin.separation(propagated).arcsec)

    # Propagate approximate 1-sigma positional uncertainty: sqrt(sigma_pos0^2 + (dt * sigma_pm)^2)
    sigma_ra_mas = None
    sigma_dec_mas = None
    if ra_error_mas is not None and pmra_error is not None:
        sigma_ra_mas = round(math.sqrt(float(ra_error_mas) ** 2 + (abs(dt_years) * float(pmra_error)) ** 2), 4)
    if dec_error_mas is not None and pmdec_error is not None:
        sigma_dec_mas = round(math.sqrt(float(dec_error_mas) ** 2 + (abs(dt_years) * float(pmdec_error)) ** 2), 4)

    # Build trajectory waypoints between ref_epoch and target_epoch_year
    steps = max(2, min(30, int(n_trajectory_steps)))
    epochs = np.linspace(ref_epoch, target_epoch_year, steps)
    trajectory: list[dict[str, Any]] = []
    for yr in epochs:
        pos = origin.apply_space_motion(new_obstime=Time(float(yr), format="jyear", scale="tcb"))
        trajectory.append({
            "epoch_jyear": round(float(yr), 4),
            "ra": float(pos.ra.deg),
            "dec": float(pos.dec.deg),
        })

    return {
        "source_id": str(source_id),
        "reference_epoch_jyear": ref_epoch,
        "target_epoch_jyear": target_epoch_year,
        "delta_t_years": round(dt_years, 6),
        "catalogue_position": {"ra": float(ra), "dec": float(dec), "frame": "ICRS", "epoch": f"J{ref_epoch}"},
        "propagated_position": {
            "ra": float(propagated.ra.deg),
            "dec": float(propagated.dec.deg),
            "frame": "ICRS",
            "epoch": f"J{target_epoch_year}",
            "sigma_ra_mas": sigma_ra_mas,
            "sigma_dec_mas": sigma_dec_mas,
        },
        "angular_displacement_arcsec": round(sep_arcsec, 6),
        "pmra_cosdec_mas_yr": float(pmra),
        "pmdec_mas_yr": float(pmdec),
        "total_pm_mas_yr": round(math.hypot(float(pmra), float(pmdec)), 4),
        "radial_velocity_used_km_s": float(radial_velocity) if "radial_velocity" in kwargs else None,
        "distance_used_pc": round(distance_used_pc, 2) if distance_used_pc is not None else None,
        "trajectory": trajectory,
        "provenance": build_provenance(
            data_provider="ESA Gaia DR3 + Astropy Coordinate Propagation",
            mission_survey="ESA Gaia DR3",
            data_release="DR3",
            archive_collection="gaiadr3.gaia_source",
            source_or_obs_id=str(source_id),
            archive_url=DATASET_REGISTRY_GAIA_URL(),
            ra=float(propagated.ra.deg),
            dec=float(propagated.dec.deg),
            units="deg, mas, mas/yr",
            uncertainties={"sigma_ra_mas": sigma_ra_mas, "sigma_dec_mas": sigma_dec_mas},
            spherex_processing=f"Astropy SkyCoord.apply_space_motion from J{ref_epoch} to J{target_epoch_year}",
        ),
    }


def DATASET_REGISTRY_GAIA_URL() -> str:
    return "https://gea.esac.esa.int/archive/"
