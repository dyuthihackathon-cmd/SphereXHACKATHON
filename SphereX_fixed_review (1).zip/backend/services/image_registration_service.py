"""Scientific image registration service using Astropy WCS and Reproject."""
from __future__ import annotations

import io
from typing import Any

import numpy as np
from astropy.io import fits
from astropy.stats import sigma_clipped_stats
from astropy.wcs.utils import proj_plane_pixel_scales
from reproject import reproject_interp

from services.wcs_service import extract_2d_wcs


def _load_mef_arrays(fits_bytes: bytes) -> dict[str, Any]:
    with fits.open(io.BytesIO(fits_bytes), memmap=False) as hdul:
        sci = next(
            (h for h in hdul if getattr(h, "name", "").upper() == "IMAGE" and getattr(h, "data", None) is not None),
            None,
        )
        if sci is None:
            sci = next(
                (h for h in hdul if getattr(h, "data", None) is not None and np.asarray(h.data).ndim >= 2),
                None,
            )
        if sci is None:
            raise ValueError("No 2D science image HDU found in FITS input.")

        data = np.asarray(sci.data, dtype=np.float64)
        if data.ndim == 3:
            data = data[0]

        var_hdu = next((h for h in hdul if getattr(h, "name", "").upper() == "VARIANCE" and getattr(h, "data", None) is not None), None)
        flg_hdu = next((h for h in hdul if getattr(h, "name", "").upper() == "FLAGS" and getattr(h, "data", None) is not None), None)

        var = np.asarray(var_hdu.data, dtype=np.float64) if var_hdu is not None else None
        if var is not None and var.ndim == 3:
            var = var[0]

        flg = np.asarray(flg_hdu.data, dtype=np.int32) if flg_hdu is not None else None
        if flg is not None and flg.ndim == 3:
            flg = flg[0]

        wcs = extract_2d_wcs(sci.header)
        scales = proj_plane_pixel_scales(wcs) * 3600.0
        return {
            "data": data,
            "variance": var,
            "flags": flg,
            "header": sci.header.copy(),
            "wcs": wcs,
            "pixel_scale_arcsec": float(np.mean(scales)),
            "bunit": str(sci.header.get("BUNIT", "Not available")),
        }


def register_fits_pair(bytes_a: bytes, bytes_b: bytes) -> dict[str, Any]:
    """Verify WCS and reproject image B (plus variance/flags) onto image A's WCS grid."""
    a = _load_mef_arrays(bytes_a)
    b = _load_mef_arrays(bytes_b)

    data_a = a["data"].copy()
    if a["flags"] is not None:
        data_a = np.where(a["flags"] == 0, data_a, np.nan)

    data_b = b["data"].copy()
    if b["flags"] is not None:
        data_b = np.where(b["flags"] == 0, data_b, np.nan)

    b_reproj, footprint = reproject_interp((data_b, b["wcs"]), a["wcs"], shape_out=data_a.shape)

    var_b_reproj = None
    if b["variance"] is not None:
        var_b_reproj, _ = reproject_interp((b["variance"], b["wcs"]), a["wcs"], shape_out=data_a.shape)

    valid_overlap = np.isfinite(data_a) & np.isfinite(b_reproj) & (footprint > 0.5)
    overlap_fraction = float(valid_overlap.sum()) / float(data_a.size) if data_a.size else 0.0

    # Robust sigma-clipped background estimation on overlapping valid pixels
    bg_a = bg_b = bg_diff = 0.0
    if valid_overlap.sum() >= 25:
        _, med_a, _ = sigma_clipped_stats(data_a[valid_overlap], sigma=3.0)
        _, med_b, _ = sigma_clipped_stats(b_reproj[valid_overlap], sigma=3.0)
        bg_a = float(med_a)
        bg_b = float(med_b)
        bg_diff = bg_a - bg_b

    return {
        "a": a,
        "b": b,
        "data_a": data_a,
        "data_b_reproj": b_reproj,
        "var_a": a["variance"],
        "var_b_reproj": var_b_reproj,
        "valid_overlap": valid_overlap,
        "overlap_fraction": round(overlap_fraction, 4),
        "background_median_a": bg_a,
        "background_median_b": bg_b,
        "background_offset_applied": bg_diff,
        "pixel_scale_a_arcsec": round(a["pixel_scale_arcsec"], 4),
        "pixel_scale_b_arcsec": round(b["pixel_scale_arcsec"], 4),
    }
