"""NASA WISE / AllWISE / NEOWISE-R image search, FITS retrieval, inspection, and rendering."""
from __future__ import annotations

import io
from datetime import timezone
from typing import Any
from urllib.parse import urlparse

import numpy as np
from astropy.io import fits
from astropy.time import Time
from astroquery.ipac.irsa import Irsa

from config import DATASET_REGISTRY
from services.fits_service import build_fits_export, inspect_mef, render_array_to_png
from services.http_utils import InvalidQueryError, ProviderUnavailableError, fetch_bytes
from services.provenance_service import build_provenance

WISE_COLLECTIONS = {
    "wise_allwise": "AllWISE Atlas Coadds",
    "neowiser": "NEOWISE-R Single-Exposure Images",
    "wise_allsky": "WISE All-Sky 4-Band Single Exposure",
    "wise_3band": "WISE 3-Band Cryo Single Exposure",
    "wise_postcryo": "WISE Post-Cryo 2-Band Single Exposure",
}

WISE_BAND_MICRONS = {
    "W1": "3.4 µm",
    "W2": "4.6 µm",
    "W3": "12 µm",
    "W4": "22 µm",
    "1": "3.4 µm",
    "2": "4.6 µm",
    "3": "12 µm",
    "4": "22 µm",
}


def _val(row: Any, names: tuple[str, ...], default: Any = None) -> Any:
    keys = {str(k).lower(): k for k in row.colnames}
    for n in names:
        k = keys.get(n.lower())
        if k is None:
            continue
        v = row[k]
        if np.ma.is_masked(v):
            continue
        if isinstance(v, bytes):
            return v.decode("utf-8", "replace")
        if hasattr(v, "item"):
            try:
                v = v.item()
            except Exception:
                pass
        return v
    return default


def _as_float(v: Any) -> float | None:
    try:
        f = float(v)
        return f if np.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _mjd_iso(mjd: float | None) -> str | None:
    if mjd is None:
        return None
    try:
        return Time(mjd, format="mjd", scale="utc").to_datetime(timezone=timezone.utc).isoformat()
    except Exception:
        return None


def search_wise_images(
    *,
    ra: float,
    dec: float,
    radius_arcmin: float = 3.0,
    collection: str = "wise_allwise",
    limit: int = 50,
) -> dict[str, Any]:
    if collection not in WISE_COLLECTIONS:
        raise InvalidQueryError(f"Unsupported WISE collection '{collection}'.", provider="IRSA WISE")

    radius_deg = radius_arcmin / 60.0
    try:
        table = Irsa.query_sia(pos=(ra, dec, radius_deg), collection=collection, maxrec=limit)
    except Exception as exc:
        raise ProviderUnavailableError(f"WISE IRSA SIA2 query failed: {type(exc).__name__}: {exc}", provider="IRSA WISE") from exc

    products: list[dict[str, Any]] = []
    for row in table:
        url = str(_val(row, ("access_url", "accessurl"), "") or "")
        if not url:
            continue
        obs_id = str(_val(row, ("obs_id", "obsid", "obs_publisher_did"), "") or "")
        if not obs_id:
            continue
        t_min = _as_float(_val(row, ("t_min", "tmin", "mjd_obs")))
        t_max = _as_float(_val(row, ("t_max", "tmax")))
        start_iso = _mjd_iso(t_min)
        band = str(_val(row, ("band", "energy_band", "em_band", "band_name"), "") or "")
        s_ra = _as_float(_val(row, ("s_ra", "sra")))
        s_dec = _as_float(_val(row, ("s_dec", "sdec")))
        fmt = str(_val(row, ("access_format", "accessformat"), "") or "")
        wl = WISE_BAND_MICRONS.get(band.upper(), band or "Not available")

        products.append({
            "id": obs_id,
            "mission": "WISE / NEOWISE-R",
            "collection": collection,
            "collection_label": WISE_COLLECTIONS[collection],
            "target": str(_val(row, ("target_name", "targetname"), "") or "Not available"),
            "ra": s_ra,
            "dec": s_dec,
            "band": band or "Not available",
            "wavelength_label": wl,
            "start_mjd": t_min,
            "end_mjd": t_max,
            "start_time": start_iso,
            "format": fmt or "Not available",
            "access_url": url,
            "source": DATASET_REGISTRY["wise"]["provider"],
            "provenance": build_provenance(
                data_provider=DATASET_REGISTRY["wise"]["provider"],
                mission_survey="NASA WISE / NEOWISE-R",
                data_release=WISE_COLLECTIONS[collection],
                archive_collection=collection,
                source_or_obs_id=obs_id,
                archive_url=url,
                observation_timestamp=start_iso,
                ra=s_ra,
                dec=s_dec,
                instrument_detector=f"WISE {band}" if band else "WISE",
                wavelength_or_filter=wl,
                units="DN (raw WISE calibrated units; see FITS BUNIT)",
            ),
        })

    products.sort(key=lambda p: (p["start_mjd"] is None, p["start_mjd"] or 0.0, p["id"]))
    return {
        "status": "ok" if products else "no_coverage",
        "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin, "collection": collection},
        "count": len(products),
        "products": products,
        "archive_note": f"Live IRSA SIA2 records for {WISE_COLLECTIONS[collection]}.",
    }


def validate_wise_url(access_url: str) -> None:
    parsed = urlparse(access_url)
    if parsed.scheme != "https" or parsed.hostname not in {
        "irsa.ipac.caltech.edu",
        "nasa-irsa-wise.s3.us-west-2.amazonaws.com",
        "nasa-irsa-wise.s3.amazonaws.com",
    }:
        raise InvalidQueryError("Only official IRSA / NASA WISE S3 HTTPS URLs are allowed.", provider="WISE")


def _validate_wise_fits_payload(raw: bytes) -> None:
    if not raw.startswith(b"SIMPLE  ="):
        raise ProviderUnavailableError("WISE archive returned a non-FITS response (missing SIMPLE FITS signature).", provider="WISE")
    try:
        with fits.open(io.BytesIO(raw), memmap=False, lazy_load_hdus=False) as hdul:
            if not any(getattr(hdu, "data", None) is not None and np.asarray(hdu.data).ndim == 2 for hdu in hdul):
                raise ValueError("No two-dimensional image HDU was found.")
    except ProviderUnavailableError:
        raise
    except Exception as exc:
        raise ProviderUnavailableError(f"WISE archive returned an invalid or unreadable FITS file: {exc}", provider="WISE") from exc


def fetch_wise_fits_bytes(access_url: str, *, ra: float | None = None, dec: float | None = None, fov_arcmin: float | None = None) -> bytes:
    validate_wise_url(access_url)
    params = None
    if "irsa.ipac.caltech.edu/ibe/" in access_url and ra is not None and dec is not None and fov_arcmin is not None:
        size_deg = fov_arcmin / 60.0
        params = {"center": f"{ra:.8f},{dec:.8f}", "size": f"{size_deg:.6f}"}
    cache_key = f"wise_fits:{access_url}:{ra}:{dec}:{fov_arcmin}"
    return fetch_bytes(
        access_url,
        params=params,
        cache_key=cache_key,
        provider="NASA/IPAC IRSA WISE",
        validator=_validate_wise_fits_payload,
    )


def render_wise_preview(
    *,
    access_url: str,
    ra: float | None = None,
    dec: float | None = None,
    fov_arcmin: float | None = None,
    stretch: str = "asinh",
    palette: str = "monochrome",
) -> tuple[bytes, dict[str, str]]:
    raw = fetch_wise_fits_bytes(access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    with fits.open(io.BytesIO(raw), memmap=False) as hdul:
        hdu = next((h for h in hdul if getattr(h, "data", None) is not None and np.asarray(h.data).ndim == 2), None)
        if hdu is None:
            raise ValueError("No 2D image found in WISE FITS file.")
        data = np.asarray(hdu.data, dtype=np.float32)
        png = render_array_to_png(data, stretch=stretch, palette=palette)
        headers = {
            "X-Wise-Bunit": str(hdu.header.get("BUNIT", "Not specified")),
            "X-Wise-Band": str(hdu.header.get("BAND", "Not specified")),
            "X-Wise-Date-Obs": str(hdu.header.get("DATE-OBS", hdu.header.get("DATE_OBS", "Not specified"))),
            "X-Wise-Shape": f"{data.shape[1]}x{data.shape[0]}",
        }
        return png, headers


def inspect_wise_fits(*, access_url: str, ra: float | None = None, dec: float | None = None, fov_arcmin: float | None = None) -> dict[str, Any]:
    raw = fetch_wise_fits_bytes(access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    info = inspect_mef(raw)
    with fits.open(io.BytesIO(raw), memmap=False) as hdul:
        hdr = hdul[0].header
        info["wise_metadata"] = {
            "band": hdr.get("BAND", "Not available"),
            "mjd_obs": hdr.get("MJD_OBS", hdr.get("MIDOBS", None)),
            "date_obs": hdr.get("DATE-OBS", hdr.get("DATE_OBS", "Not available")),
            "magzp": hdr.get("MAGZP", None),
            "bunit": hdr.get("BUNIT", "Not available"),
            "coadd_id": hdr.get("COADDID", hdr.get("SCAN_ID", "Not available")),
        }
    return info


def export_wise_fits(*, access_url: str, ra: float | None = None, dec: float | None = None, fov_arcmin: float | None = None) -> bytes:
    raw = fetch_wise_fits_bytes(access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    with fits.open(io.BytesIO(raw), memmap=False) as hdul:
        hdu = next((h for h in hdul if getattr(h, "data", None) is not None and np.asarray(h.data).ndim == 2), hdul[0])
        prov = build_provenance(
            data_provider=DATASET_REGISTRY["wise"]["provider"],
            mission_survey="NASA WISE / NEOWISE-R",
            data_release="IRSA WISE",
            archive_collection="wise",
            source_or_obs_id=str(hdu.header.get("COADDID", hdu.header.get("SCAN_ID", access_url.rsplit("/", 1)[-1]))),
            archive_url=access_url,
            observation_timestamp=str(hdu.header.get("DATE-OBS", hdu.header.get("DATE_OBS", "Not available"))),
            ra=ra,
            dec=dec,
            units=str(hdu.header.get("BUNIT", "Not available")),
            spherex_processing="WCS-preserved WISE cutout export",
        )
        return build_fits_export(
            np.asarray(hdu.data, dtype=np.float32),
            hdu.header,
            bunit=str(hdu.header.get("BUNIT", "DN")),
            provenance=prov,
        )
