"""Caching proxy for official NASA/IPAC IRSA HiPS sky surveys."""
from __future__ import annotations

from typing import Any

from config import DATASET_REGISTRY
from services.http_utils import InvalidQueryError, fetch_bytes

HIPS_SURVEYS: dict[str, dict[str, Any]] = {
    "spherex_cube": {
        "title": "SPHEREx DR1 All-Sky Spectral Cube (Visualization HiPS)",
        "base_url": DATASET_REGISTRY["spherex"]["hips_cube_url"],
        "ext": "png",
        "max_order": 5,
        "is_cube": True,
        "mission": "NASA SPHEREx DR1",
    },
    "allwise_rgb": {
        "title": "AllWISE Color (W4 Red / W2 Green / W1 Blue)",
        "base_url": DATASET_REGISTRY["wise"]["hips"]["allwise_rgb"],
        "ext": "jpg",
        "max_order": 6,
        "is_cube": False,
        "mission": "NASA WISE AllWISE",
    },
    "allwise_w1": {
        "title": "AllWISE W1 (3.4 µm)",
        "base_url": DATASET_REGISTRY["wise"]["hips"]["allwise_w1"],
        "ext": "jpg",
        "max_order": 6,
        "is_cube": False,
        "mission": "NASA WISE AllWISE",
    },
    "allwise_w2": {
        "title": "AllWISE W2 (4.6 µm)",
        "base_url": DATASET_REGISTRY["wise"]["hips"]["allwise_w2"],
        "ext": "jpg",
        "max_order": 6,
        "is_cube": False,
        "mission": "NASA WISE AllWISE",
    },
    "2mass_color": {
        "title": "2MASS Near-IR Color (J, H, Ks)",
        "base_url": DATASET_REGISTRY["reference"]["hips"]["2mass_color"],
        "ext": "jpg",
        "max_order": 9,
        "is_cube": False,
        "mission": "2MASS",
    },
    "dss2_color": {
        "title": "DSS2 Optical Color",
        "base_url": DATASET_REGISTRY["reference"]["hips"]["dss2_color"],
        "ext": "jpg",
        "max_order": 9,
        "is_cube": False,
        "mission": "DSS2 Optical",
    },
    "sdss9_color": {
        "title": "SDSS DR9 Optical Color (Footprint Limited)",
        "base_url": DATASET_REGISTRY["reference"]["hips"]["sdss9_color"],
        "ext": "jpg",
        "max_order": 10,
        "is_cube": False,
        "mission": "SDSS DR9",
    },
}


def fetch_hips_tile(survey_id: str, order: int, npix: int, frame: int | None = None) -> tuple[bytes, str]:
    if survey_id not in HIPS_SURVEYS:
        raise InvalidQueryError(f"Unknown HiPS survey '{survey_id}'.", provider="IRSA HiPS")
    spec = HIPS_SURVEYS[survey_id]
    if order < 0 or order > spec["max_order"]:
        raise InvalidQueryError(f"Order {order} out of range for {survey_id} (0..{spec['max_order']}).", provider="IRSA HiPS")

    dir_idx = (npix // 10000) * 10000
    ext = spec["ext"]
    if spec["is_cube"] and frame is not None and frame >= 0:
        filename = f"Npix{npix}_{frame}.{ext}"
    else:
        filename = f"Npix{npix}.{ext}"

    url = f"{spec['base_url']}/Norder{order}/Dir{dir_idx}/{filename}"
    data = fetch_bytes(url, cache_key=f"hips:{survey_id}:{order}:{npix}:{frame}", timeout=20, provider="IRSA HiPS")
    media_type = "image/png" if ext == "png" else "image/jpeg"
    return data, media_type
