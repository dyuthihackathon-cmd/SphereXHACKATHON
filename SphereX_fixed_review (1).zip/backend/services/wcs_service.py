"""Astropy WCS coordinate transformation helpers (pixel <-> world)."""
from __future__ import annotations

import io
from typing import Any

import numpy as np
from astropy.io import fits
from astropy.wcs import WCS


def extract_2d_wcs(header: fits.Header) -> WCS:
    """Build a 2D celestial WCS from a FITS header, handling SIP/3D headers safely."""
    wcs = WCS(header)
    if wcs.naxis > 2:
        wcs = wcs.celestial
    if not wcs.has_celestial:
        raise ValueError("FITS header does not contain a valid celestial WCS.")
    return wcs


def pixel_to_world_from_bytes(
    fits_bytes: bytes,
    pixel_x: float,
    pixel_y: float,
    ext_name: str = "IMAGE",
) -> dict[str, Any]:
    with fits.open(io.BytesIO(fits_bytes), memmap=False) as hdul:
        hdu = _select_image_hdu(hdul, ext_name)
        wcs = extract_2d_wcs(hdu.header)
        ny, nx = hdu.data.shape[-2], hdu.data.shape[-1]
        if pixel_x < -0.5 or pixel_x >= nx - 0.5 or pixel_y < -0.5 or pixel_y >= ny - 0.5:
            raise ValueError(f"Pixel ({pixel_x}, {pixel_y}) is outside image bounds ({nx}x{ny}).")
        coord = wcs.pixel_to_world(pixel_x, pixel_y)
        icrs = coord.icrs
        ix = int(np.clip(round(pixel_x), 0, nx - 1))
        iy = int(np.clip(round(pixel_y), 0, ny - 1))
        arr = np.asarray(hdu.data)
        if arr.ndim == 3:
            val = float(arr[0, iy, ix])
        else:
            val = float(arr[iy, ix])
        pixel_value = val if np.isfinite(val) else None
        return {
            "pixel_x": float(pixel_x),
            "pixel_y": float(pixel_y),
            "ra": float(icrs.ra.deg),
            "dec": float(icrs.dec.deg),
            "frame": "ICRS",
            "ctype": [str(c) for c in wcs.wcs.ctype],
            "image_shape": [int(nx), int(ny)],
            "pixel_value": pixel_value,
            "bunit": str(hdu.header.get("BUNIT", "Not available")),
        }


def world_to_pixel_from_bytes(
    fits_bytes: bytes,
    ra: float,
    dec: float,
    ext_name: str = "IMAGE",
) -> dict[str, Any]:
    from astropy.coordinates import SkyCoord
    from astropy import units as u

    with fits.open(io.BytesIO(fits_bytes), memmap=False) as hdul:
        hdu = _select_image_hdu(hdul, ext_name)
        wcs = extract_2d_wcs(hdu.header)
        ny, nx = hdu.data.shape[-2], hdu.data.shape[-1]
        coord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")
        px, py = wcs.world_to_pixel(coord)
        px_f, py_f = float(px), float(py)
        in_bounds = (0.0 <= px_f < nx) and (0.0 <= py_f < ny)
        return {
            "ra": float(ra),
            "dec": float(dec),
            "pixel_x": px_f,
            "pixel_y": py_f,
            "in_bounds": bool(in_bounds),
            "image_shape": [int(nx), int(ny)],
        }


def get_wcs_footprint(header: fits.Header, shape_hw: tuple[int, int]) -> dict[str, Any]:
    """Compute celestial footprint corners and pixel scale from FITS WCS."""
    wcs = extract_2d_wcs(header)
    ny, nx = shape_hw
    corners_px = np.array([[0, 0], [nx - 1, 0], [nx - 1, ny - 1], [0, ny - 1]], dtype=float)
    sky = wcs.pixel_to_world(corners_px[:, 0], corners_px[:, 1]).icrs
    center = wcs.pixel_to_world((nx - 1) / 2.0, (ny - 1) / 2.0).icrs
    try:
        from astropy.wcs.utils import proj_plane_pixel_scales
        scales_deg = proj_plane_pixel_scales(wcs)
        pixel_scale_arcsec = float(np.mean(scales_deg) * 3600.0)
    except Exception:
        pixel_scale_arcsec = None
    return {
        "center_ra": float(center.ra.deg),
        "center_dec": float(center.dec.deg),
        "pixel_scale_arcsec": pixel_scale_arcsec,
        "polygon": [[float(r), float(d)] for r, d in zip(sky.ra.deg, sky.dec.deg)],
        "ctype": [str(c) for c in wcs.wcs.ctype],
    }


def _select_image_hdu(hdul: fits.HDUList, preferred_name: str = "IMAGE") -> Any:
    for hdu in hdul:
        if getattr(hdu, "name", "").upper() == preferred_name.upper() and getattr(hdu, "data", None) is not None:
            return hdu
    for hdu in hdul:
        if getattr(hdu, "data", None) is not None and np.asarray(hdu.data).ndim >= 2:
            return hdu
    raise ValueError("No 2D/3D image HDU found in FITS file.")
