"""Scientific difference imaging and significance computation service."""
from __future__ import annotations

import base64
from typing import Any

import numpy as np

from services.fits_service import build_fits_export, render_array_to_png
from services.image_registration_service import register_fits_pair
from services.provenance_service import build_provenance


def compute_difference_analysis(
    bytes_a: bytes,
    bytes_b: bytes,
    *,
    meta_a: dict[str, Any],
    meta_b: dict[str, Any],
    match_background: bool = True,
) -> dict[str, Any]:
    warnings: list[str] = []

    rel_a = str(meta_a.get("collection") or meta_a.get("release") or "")
    rel_b = str(meta_b.get("collection") or meta_b.get("release") or "")
    if rel_a and rel_b and rel_a != rel_b:
        warnings.append(f"Comparing different collections/processing releases ({rel_a} vs {rel_b}); verify calibration consistency.")

    wl_a_min = meta_a.get("wavelength_min_m")
    wl_b_min = meta_b.get("wavelength_min_m")
    if wl_a_min and wl_b_min:
        rel_diff = abs(float(wl_a_min) - float(wl_b_min)) / max(float(wl_a_min), 1e-12)
        if rel_diff > 0.25:
            warnings.append(
                f"Wavelength bands differ significantly ({float(wl_a_min)*1e6:.3f} µm vs {float(wl_b_min)*1e6:.3f} µm). "
                "Difference image reflects spectral/band contrast as well as temporal change."
            )

    reg = register_fits_pair(bytes_a, bytes_b)
    if reg["overlap_fraction"] < 0.05:
        raise ValueError(
            f"Insufficient celestial overlap between Observation A and Observation B ({reg['overlap_fraction']*100:.1f}%)."
        )

    b_aligned = reg["data_b_reproj"]
    if match_background:
        b_aligned = b_aligned + reg["background_offset_applied"]

    diff = np.where(reg["valid_overlap"], reg["data_a"] - b_aligned, np.nan)

    # Propagate variance ONLY when both inputs provide valid VARIANCE extensions
    has_valid_variance = reg["var_a"] is not None and reg["var_b_reproj"] is not None
    sig_map = None
    sig_png_b64 = None
    max_abs_sigma = None
    if has_valid_variance:
        total_var = reg["var_a"] + reg["var_b_reproj"]
        valid_var = reg["valid_overlap"] & np.isfinite(total_var) & (total_var > 0)
        if valid_var.any():
            sig_map = np.where(valid_var, diff / np.sqrt(total_var), np.nan)
            max_abs_sigma = float(np.nanmax(np.abs(sig_map[valid_var])))
            sig_png = render_array_to_png(sig_map, stretch="linear", palette="cyan_amber", percentile=99.5)
            sig_png_b64 = base64.b64encode(sig_png).decode("ascii")
        else:
            has_valid_variance = False
            warnings.append("VARIANCE extensions had no positive overlapping pixels; significance map omitted.")
    else:
        warnings.append("One or both inputs lack a VARIANCE extension; difference significance (SNR) map is not fabricated.")

    diff_png = render_array_to_png(diff, stretch="linear", palette="cyan_amber", percentile=99.5)
    diff_png_b64 = base64.b64encode(diff_png).decode("ascii")

    finite_diff = diff[reg["valid_overlap"]]
    rms = float(np.sqrt(np.nanmean(finite_diff ** 2))) if finite_diff.size else None

    return {
        "status": "ok",
        "warnings": warnings,
        "registration": {
            "overlap_fraction": reg["overlap_fraction"],
            "pixel_scale_a_arcsec": reg["pixel_scale_a_arcsec"],
            "pixel_scale_b_arcsec": reg["pixel_scale_b_arcsec"],
            "background_median_a": reg["background_median_a"],
            "background_median_b": reg["background_median_b"],
            "background_offset_applied": reg["background_offset_applied"] if match_background else 0.0,
            "match_background": match_background,
        },
        "statistics": {
            "bunit": reg["a"]["bunit"],
            "valid_overlap_pixels": int(reg["valid_overlap"].sum()),
            "diff_min": float(np.nanmin(finite_diff)) if finite_diff.size else None,
            "diff_max": float(np.nanmax(finite_diff)) if finite_diff.size else None,
            "diff_rms": rms,
            "has_significance_map": has_valid_variance,
            "max_abs_significance_sigma": max_abs_sigma,
        },
        "difference_png_base64": diff_png_b64,
        "significance_png_base64": sig_png_b64,
        "provenance": build_provenance(
            data_provider="NASA/IPAC IRSA + SphereX Astropy/Reproject Pipeline",
            mission_survey=f"{meta_a.get('mission', 'Archive')} vs {meta_b.get('mission', 'Archive')}",
            data_release=f"{rel_a} / {rel_b}",
            archive_collection=f"{rel_a} - {rel_b}",
            source_or_obs_id=f"{meta_a.get('id', 'ObsA')} MINUS {meta_b.get('id', 'ObsB')}",
            archive_url=str(meta_a.get("access_url", "")),
            observation_timestamp=f"{meta_a.get('start_time', 'Unknown')} vs {meta_b.get('start_time', 'Unknown')}",
            units=reg["a"]["bunit"],
            spherex_processing="WCS Reproject (reproject_interp) + sigma-clipped background matching + pixel subtraction",
        ),
        "_diff_array": diff,
        "_header": reg["a"]["header"],
        "_total_var": (reg["var_a"] + reg["var_b_reproj"]) if has_valid_variance else None,
    }


def export_difference_fits(analysis: dict[str, Any]) -> bytes:
    return build_fits_export(
        analysis["_diff_array"],
        analysis["_header"],
        bunit=analysis["statistics"]["bunit"],
        provenance=analysis["provenance"],
        variance=analysis["_total_var"],
    )
