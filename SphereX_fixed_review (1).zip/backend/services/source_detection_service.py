"""Cautious source detection & moving-object candidate analysis pipeline.

Detects real point-like sources in calibrated FITS images via Photutils DAOStarFinder,
maps detections to ICRS via Astropy WCS, associates multi-epoch detections, fits linear
angular motion, cross-matches against Gaia DR3, and checks MPC/Horizons.
Never declares unverified candidates as discoveries.
"""
from __future__ import annotations

import io
from datetime import timezone
from typing import Any

import numpy as np
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.stats import sigma_clipped_stats
from astropy.time import Time
from photutils.detection import DAOStarFinder

from services.gaia_service import query_gaia_sources
from services.provenance_service import build_provenance
from services.wcs_service import extract_2d_wcs

ALLOWED_LABELS = (
    "Unverified candidate",
    "Possible known-object match",
    "No known-object match found",
    "Insufficient observations",
    "Likely artifact or unreliable detection",
    "Requires human review",
)


def detect_sources_in_fits(
    fits_bytes: bytes,
    *,
    obs_id: str,
    obs_mjd: float | None = None,
    fwhm_px: float = 3.0,
    sigma_threshold: float = 5.0,
    max_sources: int = 80,
) -> dict[str, Any]:
    with fits.open(io.BytesIO(fits_bytes), memmap=False) as hdul:
        sci = next(
            (h for h in hdul if getattr(h, "name", "").upper() == "IMAGE" and getattr(h, "data", None) is not None),
            None,
        )
        if sci is None:
            sci = next(
                (h for h in hdul if getattr(h, "data", None) is not None and np.asarray(h.data).ndim == 2),
                None,
            )
        if sci is None:
            raise ValueError("No 2D science image found in FITS file.")

        data = np.asarray(sci.data, dtype=np.float64)
        flg_hdu = next((h for h in hdul if getattr(h, "name", "").upper() == "FLAGS" and getattr(h, "data", None) is not None), None)
        flg = np.asarray(flg_hdu.data, dtype=np.int32) if flg_hdu is not None else None

        wcs = extract_2d_wcs(sci.header)
        finite = np.isfinite(data)
        if flg is not None:
            finite &= (flg == 0)
        if finite.sum() < 25:
            return {"obs_id": obs_id, "count": 0, "detections": [], "note": "Insufficient unflagged finite pixels."}

        mean, median, std = sigma_clipped_stats(data[finite], sigma=3.0)
        if not np.isfinite(std) or std <= 0:
            return {"obs_id": obs_id, "count": 0, "detections": [], "note": "Image background noise is zero or non-finite."}

        cleaned = np.where(finite, data - median, 0.0)
        finder = DAOStarFinder(fwhm=fwhm_px, threshold=sigma_threshold * std)
        tbl = finder(cleaned, mask=~finite)
        if tbl is None or len(tbl) == 0:
            return {"obs_id": obs_id, "count": 0, "detections": [], "note": "No sources exceeded detection threshold."}

        tbl.sort("flux", reverse=True)
        detections: list[dict[str, Any]] = []
        obs_iso = (
            Time(obs_mjd, format="mjd", scale="utc").to_datetime(timezone=timezone.utc).isoformat()
            if obs_mjd is not None
            else str(sci.header.get("DATE-OBS", "Not available"))
        )
        x_col = "x_centroid" if "x_centroid" in tbl.colnames else "xcentroid"
        y_col = "y_centroid" if "y_centroid" in tbl.colnames else "ycentroid"
        for row in tbl[:max_sources]:
            x_c = float(row[x_col])
            y_c = float(row[y_col])
            coord = wcs.pixel_to_world(x_c, y_c).icrs
            detections.append({
                "obs_id": obs_id,
                "mjd": obs_mjd,
                "obs_time": obs_iso,
                "xcentroid": round(x_c, 3),
                "ycentroid": round(y_c, 3),
                "ra": float(coord.ra.deg),
                "dec": float(coord.dec.deg),
                "flux": float(row["flux"]),
                "peak": float(row["peak"]),
                "snr_approx": round(float(row["peak"]) / float(std), 2),
                "sharpness": round(float(row["sharpness"]), 3),
                "roundness": round(float(row["roundness1"]), 3),
            })

        return {
            "obs_id": obs_id,
            "mjd": obs_mjd,
            "background_median": float(median),
            "background_rms": float(std),
            "count": len(detections),
            "detections": detections,
        }


def analyze_moving_object_candidates(
    *,
    epoch_detections: list[dict[str, Any]],
    ra_center: float,
    dec_center: float,
    search_radius_arcsec: float = 15.0,
    static_match_arcsec: float = 1.5,
    enable_gaia_crossmatch: bool = True,
) -> dict[str, Any]:
    """Associate multi-epoch real detections, exclude Gaia DR3 stationary stars, and fit motion."""
    valid_epochs = [ep for ep in epoch_detections if ep.get("mjd") is not None and ep.get("detections")]
    if len(valid_epochs) < 2:
        return {
            "status": "insufficient_observations",
            "candidate_count": 0,
            "candidates": [{
                "candidate_id": "none",
                "classification": "Insufficient observations",
                "reason": "At least 2 time-stamped epochs with real detections are required to evaluate sky motion.",
                "epochs_analyzed": len(valid_epochs),
            }],
        }

    # Fetch Gaia DR3 reference stars in field for stationary-source cross-checking
    gaia_coords: SkyCoord | None = None
    gaia_ids: list[str] = []
    gaia_note = "Gaia DR3 cross-match active"
    if enable_gaia_crossmatch:
        try:
            gaia_res = query_gaia_sources(ra=ra_center, dec=dec_center, radius_arcmin=4.0, limit=300)
            if gaia_res["sources"]:
                gaia_coords = SkyCoord(
                    ra=[s["ra"] for s in gaia_res["sources"]] * u.deg,
                    dec=[s["dec"] for s in gaia_res["sources"]] * u.deg,
                    frame="icrs",
                )
                gaia_ids = [str(s["source_id"]) for s in gaia_res["sources"]]
        except Exception as exc:
            gaia_note = f"Gaia cross-match unavailable ({exc})"
    else:
        gaia_note = "Gaia cross-match disabled (offline test mode)"

    # Group detections from epoch 0 against subsequent epochs within search_radius_arcsec
    valid_epochs.sort(key=lambda e: float(e["mjd"]))
    base_ep = valid_epochs[0]
    candidates: list[dict[str, Any]] = []

    for det_idx, det0 in enumerate(base_ep["detections"][:40]):
        c0 = SkyCoord(ra=det0["ra"] * u.deg, dec=det0["dec"] * u.deg, frame="icrs")

        # Skip stationary Gaia stars if within static_match_arcsec across epochs
        gaia_match_id = None
        if gaia_coords is not None and len(gaia_coords):
            seps = c0.separation(gaia_coords).arcsec
            min_i = int(np.argmin(seps))
            if seps[min_i] <= static_match_arcsec:
                gaia_match_id = gaia_ids[min_i]

        track: list[dict[str, Any]] = [{**det0, "epoch_index": 0}]
        for ep_idx, ep in enumerate(valid_epochs[1:], start=1):
            dets = ep["detections"]
            if not dets:
                continue
            coords = SkyCoord(ra=[d["ra"] for d in dets] * u.deg, dec=[d["dec"] for d in dets] * u.deg, frame="icrs")
            seps = c0.separation(coords).arcsec
            best_i = int(np.argmin(seps))
            if seps[best_i] <= search_radius_arcsec:
                track.append({**dets[best_i], "epoch_index": ep_idx, "sep_from_epoch0_arcsec": round(float(seps[best_i]), 3)})

        if len(track) < 2:
            continue

        times_hr = np.array([(float(t["mjd"]) - float(track[0]["mjd"])) * 24.0 for t in track])
        dt_total_hr = float(times_hr[-1] - times_hr[0])
        if dt_total_hr <= 0:
            continue

        ras = np.array([t["ra"] for t in track])
        decs = np.array([t["dec"] for t in track])
        cos_d = max(0.1, float(np.cos(np.radians(np.mean(decs)))))
        dx_arcsec = ((ras - ras[0] + 180) % 360 - 180) * 3600.0 * cos_d
        dy_arcsec = (decs - decs[0]) * 3600.0

        # Linear angular motion fit
        A = np.vstack([times_hr, np.ones(len(times_hr))]).T
        mu_ra, x0 = np.linalg.lstsq(A, dx_arcsec, rcond=None)[0]
        mu_dec, y0 = np.linalg.lstsq(A, dy_arcsec, rcond=None)[0]
        res_x = dx_arcsec - (mu_ra * times_hr + x0)
        res_y = dy_arcsec - (mu_dec * times_hr + y0)
        rms_residual_arcsec = float(np.sqrt(np.mean(res_x ** 2 + res_y ** 2)))
        total_rate = float(np.hypot(mu_ra, mu_dec))
        total_disp = float(np.hypot(dx_arcsec[-1], dy_arcsec[-1]))

        # Conservative scientific classification (never claim discovery automatically)
        if gaia_match_id is not None and total_disp < static_match_arcsec:
            continue  # Confirmed stationary Gaia source, not a moving candidate

        if len(track) == 2:
            label = "Insufficient observations"
            reason = "Only 2 epochs linked; at least 3 well-separated detections are needed to evaluate linear motion residuals."
        elif rms_residual_arcsec > 2.5 or any(t.get("snr_approx", 10) < 4.0 for t in track):
            label = "Likely artifact or unreliable detection"
            reason = f"High astrometric residual ({rms_residual_arcsec:.2f}″) or marginal SNR."
        elif total_disp < 0.8:
            label = "Likely artifact or unreliable detection"
            reason = f"Net displacement ({total_disp:.2f}″) is within typical centroiding uncertainty."
        else:
            label = "Requires human review"
            reason = (
                f"Linked across {len(track)} real epochs over {dt_total_hr:.2f} h with displacement {total_disp:.2f}″ "
                f"(rate {total_rate:.3f}″/h, RMS residual {rms_residual_arcsec:.2f}″). Query MPC/Horizons before interpreting."
            )

        candidates.append({
            "candidate_id": f"CAND-{det_idx + 1:03d}",
            "classification": label,
            "reason": reason,
            "epochs_linked": len(track),
            "time_baseline_hours": round(dt_total_hr, 4),
            "total_displacement_arcsec": round(total_disp, 3),
            "angular_rate_arcsec_hr": round(total_rate, 4),
            "mu_ra_cosdec_arcsec_hr": round(float(mu_ra), 4),
            "mu_dec_arcsec_hr": round(float(mu_dec), 4),
            "rms_residual_arcsec": round(rms_residual_arcsec, 3),
            "gaia_crossmatch_id": gaia_match_id,
            "detections": track,
        })

    candidates.sort(key=lambda c: (-c["epochs_linked"], c["rms_residual_arcsec"]))
    return {
        "status": "ok",
        "gaia_note": gaia_note,
        "epochs_analyzed": len(valid_epochs),
        "candidate_count": len(candidates),
        "candidates": candidates[:30],
        "provenance": build_provenance(
            data_provider="SphereX Photutils + Astropy WCS Pipeline",
            mission_survey="Multi-Epoch Moving-Object Candidate Review",
            data_release="Live Analysis",
            archive_collection="multi_epoch_detections",
            source_or_obs_id=f"field({ra_center:.4f},{dec_center:.4f})",
            archive_url="",
            ra=ra_center,
            dec=dec_center,
            spherex_processing="DAOStarFinder + WCS celestial mapping + linear motion fit + Gaia cross-check",
        ),
    }
