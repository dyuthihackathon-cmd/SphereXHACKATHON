"""IAU Minor Planet Center (MPC) observations and orbits verification service."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Any

from config import DATASET_REGISTRY
from services.http_utils import InvalidQueryError, ProviderUnavailableError, fetch_json
from services.provenance_service import build_provenance


def query_mpc_observations(designation: str, limit: int = 100) -> dict[str, Any]:
    desig = designation.strip()
    if not desig:
        raise InvalidQueryError("MPC designation is required.", provider="MPC")

    url = DATASET_REGISTRY["mpc"]["obs_url"]
    payload = fetch_json(
        url,
        method="GET",
        json_body={"desigs": [desig], "output_format": ["XML"]},
        timeout=25,
        provider="IAU Minor Planet Center",
    )
    if not isinstance(payload, list) or not payload:
        return {
            "status": "no_coverage",
            "designation": desig,
            "count": 0,
            "observations": [],
            "message": f"MPC returned no observations for '{desig}'.",
        }

    entry = payload[0]
    xml_str = entry.get("XML")
    observations: list[dict[str, Any]] = []
    if xml_str:
        try:
            root = ET.fromstring(xml_str)
            for node in root.findall(".//optical"):
                observations.append({
                    "permID": node.findtext("permID"),
                    "provID": node.findtext("provID"),
                    "obsID": node.findtext("obsID"),
                    "stn": node.findtext("stn"),
                    "obsTime": node.findtext("obsTime"),
                    "ra": _f(node.findtext("ra")),
                    "dec": _f(node.findtext("dec")),
                    "rmsRA": _f(node.findtext("rmsRA")),
                    "rmsDec": _f(node.findtext("rmsDec")),
                    "mag": _f(node.findtext("mag")),
                    "band": node.findtext("band"),
                    "astCat": node.findtext("astCat"),
                })
        except ET.ParseError as exc:
            raise ProviderUnavailableError(f"Could not parse MPC ADES XML: {exc}", provider="MPC") from exc

    observations.sort(key=lambda o: o.get("obsTime") or "", reverse=True)
    return {
        "status": "ok" if observations else "no_coverage",
        "designation": desig,
        "total_returned": len(observations),
        "count": min(len(observations), limit),
        "observations": observations[:limit],
        "mpc_url": f"https://www.minorplanetcenter.net/db_search/show_object?object_id={desig}",
        "provenance": build_provenance(
            data_provider=DATASET_REGISTRY["mpc"]["provider"],
            mission_survey="Minor Planet Center ADES Observations",
            data_release="Live MPC API",
            archive_collection="get-obs",
            source_or_obs_id=desig,
            archive_url=url,
            ra=observations[0]["ra"] if observations else None,
            dec=observations[0]["dec"] if observations else None,
            units="deg, arcsec, mag",
        ),
    }


def query_mpc_orbit(designation: str) -> dict[str, Any]:
    desig = designation.strip()
    if not desig:
        raise InvalidQueryError("MPC designation is required.", provider="MPC")

    url = DATASET_REGISTRY["mpc"]["orb_url"]
    payload = fetch_json(
        url,
        method="GET",
        json_body={"desig": desig},
        timeout=25,
        provider="IAU Minor Planet Center",
    )
    if not payload:
        return {
            "status": "no_coverage",
            "designation": desig,
            "orbit": None,
            "message": f"No MPC orbit found for '{desig}'.",
        }
    orbit_record = payload[0] if isinstance(payload, list) else payload
    return {
        "status": "ok",
        "designation": desig,
        "orbit": orbit_record,
        "mpc_url": f"https://www.minorplanetcenter.net/db_search/show_object?object_id={desig}",
        "provenance": build_provenance(
            data_provider=DATASET_REGISTRY["mpc"]["provider"],
            mission_survey="Minor Planet Center Orbits",
            data_release="Live MPC API",
            archive_collection="get-orb",
            source_or_obs_id=desig,
            archive_url=url,
        ),
    }


def _f(s: str | None) -> float | None:
    if s is None:
        return None
    try:
        return float(s)
    except ValueError:
        return None
