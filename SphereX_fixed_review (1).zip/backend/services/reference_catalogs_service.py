"""Optional reference catalogues: Pan-STARRS DR2 (MAST) and 2MASS (IRSA/VizieR)."""
from __future__ import annotations

from typing import Any

from config import DATASET_REGISTRY
from services.http_utils import fetch_json
from services.provenance_service import build_provenance


def query_panstarrs_dr2(
    *,
    ra: float,
    dec: float,
    radius_arcmin: float = 1.0,
    limit: int = 50,
) -> dict[str, Any]:
    if dec < -30.5:
        return {
            "status": "no_coverage",
            "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin},
            "count": 0,
            "sources": [],
            "coverage_note": "Pan-STARRS DR2 covers Dec > -30° only. This southern sky coordinate is outside PS1 survey footprint.",
        }

    radius_deg = min(0.5, radius_arcmin / 60.0)
    payload = fetch_json(
        DATASET_REGISTRY["reference"]["panstarrs_dr2"],
        params={
            "ra": f"{ra:.7f}",
            "dec": f"{dec:.7f}",
            "radius": f"{radius_deg:.6f}",
            "pagesize": str(limit),
            "columns": "[objID,objName,raMean,decMean,nDetections,gMeanPSFMag,rMeanPSFMag,iMeanPSFMag,zMeanPSFMag,yMeanPSFMag]",
        },
        timeout=25,
        provider="MAST Pan-STARRS DR2",
    )
    rows = payload.get("data", []) if isinstance(payload, dict) else []
    return {
        "status": "ok" if rows else "no_coverage",
        "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin},
        "count": len(rows),
        "sources": rows,
        "coverage_note": "Live STScI MAST Pan-STARRS DR2 MeanObject catalogue (Dec > -30°).",
        "provenance": build_provenance(
            data_provider="STScI MAST",
            mission_survey="Pan-STARRS DR2",
            data_release="DR2",
            archive_collection="panstarrs/dr2/mean",
            source_or_obs_id=f"cone({ra:.5f},{dec:.5f})",
            archive_url=DATASET_REGISTRY["reference"]["panstarrs_dr2"],
            ra=ra,
            dec=dec,
            wavelength_or_filter="g, r, i, z, y",
            units="AB mag (PSF)",
        ),
    }


def query_twomass_psc(
    *,
    ra: float,
    dec: float,
    radius_arcmin: float = 2.0,
    limit: int = 50,
) -> dict[str, Any]:
    radius_deg = radius_arcmin / 60.0
    adql = (
        f"SELECT TOP {limit} designation, ra, dec, j_m, j_cmsig, h_m, h_cmsig, k_m, k_cmsig, ph_qual "
        f"FROM fp_psc WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra:.8f}, {dec:.8f}, {radius_deg:.8f})) = 1"
    )
    payload = fetch_json(
        DATASET_REGISTRY["reference"]["twomass_tap"],
        method="POST",
        data={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "json", "QUERY": adql},
        timeout=25,
        provider="IRSA 2MASS TAP",
    )
    cols = [m.get("name") for m in payload.get("metadata", [])]
    rows = [dict(zip(cols, r)) for r in payload.get("data", [])]
    return {
        "status": "ok" if rows else "no_coverage",
        "query": {"ra": ra, "dec": dec, "radius_arcmin": radius_arcmin},
        "count": len(rows),
        "sources": rows,
        "provenance": build_provenance(
            data_provider="NASA/IPAC IRSA",
            mission_survey="2MASS All-Sky Point Source Catalog",
            data_release="2MASS PSC",
            archive_collection="fp_psc",
            source_or_obs_id=f"cone({ra:.5f},{dec:.5f})",
            archive_url=DATASET_REGISTRY["reference"]["twomass_tap"],
            ra=ra,
            dec=dec,
            wavelength_or_filter="J (1.25 µm), H (1.65 µm), Ks (2.16 µm)",
            units="Vega mag",
        ),
    }
