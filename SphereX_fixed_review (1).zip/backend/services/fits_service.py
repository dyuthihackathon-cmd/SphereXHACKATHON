"""FITS Multi-Extension inspection, scientific stretch/colormap rendering, and WCS-preserving FITS export."""
from __future__ import annotations

import io
from typing import Any

import numpy as np
from astropy.io import fits
from astropy.visualization import (
    AsinhStretch,
    ImageNormalize,
    LinearStretch,
    LogStretch,
    PercentileInterval,
    SqrtStretch,
    ZScaleInterval,
)
from PIL import Image

from services.wcs_service import get_wcs_footprint


def _build_colormap_lut(palette: str) -> np.ndarray:
    """Return a 256x3 uint8 lookup table for scientific false-color rendering."""
    t = np.linspace(0.0, 1.0, 256)
    if palette == "monochrome":
        g = (t * 255).astype(np.uint8)
        return np.stack([g, g, g], axis=1)
    if palette == "cyan_amber":
        r = np.clip(np.interp(t, [0.0, 0.45, 0.75, 1.0], [5, 12, 245, 255]), 0, 255)
        g = np.clip(np.interp(t, [0.0, 0.45, 0.75, 1.0], [10, 182, 185, 245]), 0, 255)
        b = np.clip(np.interp(t, [0.0, 0.45, 0.75, 1.0], [20, 224, 38, 180]), 0, 255)
        return np.stack([r, g, b], axis=1).astype(np.uint8)
    if palette == "plasma":
        r = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [13, 126, 204, 248, 240]), 0, 255)
        g = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [8, 3, 71, 149, 249]), 0, 255)
        b = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [135, 168, 120, 64, 33]), 0, 255)
        return np.stack([r, g, b], axis=1).astype(np.uint8)
    if palette == "viridis":
        r = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [68, 59, 33, 122, 253]), 0, 255)
        g = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [1, 82, 145, 209, 231]), 0, 255)
        b = np.clip(np.interp(t, [0.0, 0.25, 0.55, 0.85, 1.0], [84, 139, 140, 81, 37]), 0, 255)
        return np.stack([r, g, b], axis=1).astype(np.uint8)
    if palette == "magma":
        r = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [0, 81, 183, 251, 252]), 0, 255)
        g = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [0, 18, 55, 136, 253]), 0, 255)
        b = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [4, 124, 121, 97, 191]), 0, 255)
        return np.stack([r, g, b], axis=1).astype(np.uint8)
    # Default: spherex_ir (deep obsidian -> cobalt -> cyan -> warm amber -> white)
    r = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [7, 14, 48, 245, 255]), 0, 255)
    g = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [11, 78, 196, 175, 250]), 0, 255)
    b = np.clip(np.interp(t, [0.0, 0.3, 0.6, 0.85, 1.0], [22, 132, 222, 65, 235]), 0, 255)
    return np.stack([r, g, b], axis=1).astype(np.uint8)


def render_array_to_png(
    data: np.ndarray,
    *,
    stretch: str = "asinh",
    palette: str = "monochrome",
    percentile: float = 99.5,
) -> bytes:
    """Render a 2D astronomical array with genuine interval + stretch + colormap."""
    arr = np.asarray(data, dtype=np.float32)
    finite = np.isfinite(arr)
    if not finite.any():
        raise ValueError("Image contains no finite pixel values.")

    fill = float(np.nanmedian(arr[finite]))
    cleaned = np.where(finite, arr, fill)

    interval = ZScaleInterval() if stretch == "zscale" else PercentileInterval(percentile)
    stretch_map = {
        "linear": LinearStretch(),
        "log": LogStretch(),
        "asinh": AsinhStretch(),
        "sqrt": SqrtStretch(),
        "zscale": LinearStretch(),
    }
    stretch_obj = stretch_map.get(stretch, AsinhStretch())

    try:
        norm = ImageNormalize(cleaned, interval=interval, stretch=stretch_obj)
        scaled = np.clip(norm(cleaned), 0.0, 1.0)
    except Exception:
        vmin, vmax = np.nanpercentile(cleaned, [1.0, 99.5])
        if vmax <= vmin:
            vmax = vmin + 1e-6
        scaled = np.clip((cleaned - vmin) / (vmax - vmin), 0.0, 1.0)

    # Flip vertically so North-up / FITS origin bottom-left matches standard sky display orientation
    flipped = np.flipud(scaled)
    indices = np.clip((flipped * 255).astype(np.uint8), 0, 255)
    # Mark non-finite pixels with subtle slate border transparency only if needed; keep RGB solid
    lut = _build_colormap_lut(palette)
    rgb = lut[indices]
    img = Image.fromarray(rgb, mode="RGB")
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def inspect_mef(fits_bytes: bytes, preferred_ext: str = "IMAGE") -> dict[str, Any]:
    """Inspect all extensions, headers, WCS, and data-quality statistics of a FITS file."""
    with fits.open(io.BytesIO(fits_bytes), memmap=False) as hdul:
        extensions: list[dict[str, Any]] = []
        science_hdu = None
        variance_hdu = None
        flags_hdu = None

        for idx, hdu in enumerate(hdul):
            name = (getattr(hdu, "name", "") or f"HDU_{idx}").upper()
            data = getattr(hdu, "data", None)
            shape = list(data.shape) if data is not None and hasattr(data, "shape") else []
            extensions.append({
                "index": idx,
                "name": name,
                "type": type(hdu).__name__,
                "shape": shape,
                "bunit": str(hdu.header.get("BUNIT", "")) or None,
            })
            if name == preferred_ext.upper() and data is not None:
                science_hdu = hdu
            elif name == "VARIANCE" and data is not None:
                variance_hdu = hdu
            elif name == "FLAGS" and data is not None:
                flags_hdu = hdu

        if science_hdu is None:
            science_hdu = next(
                (h for h in hdul if getattr(h, "data", None) is not None and np.asarray(h.data).ndim >= 2),
                None,
            )
        if science_hdu is None:
            raise ValueError("No 2D image extension found in FITS file.")

        sci = np.asarray(science_hdu.data, dtype=np.float64)
        if sci.ndim == 3:
            sci = sci[0]

        total_px = int(sci.size)
        finite_mask = np.isfinite(sci)
        finite_count = int(finite_mask.sum())
        nan_count = total_px - finite_count

        stats: dict[str, Any] = {
            "total_pixels": total_px,
            "finite_pixels": finite_count,
            "nan_pixels": nan_count,
            "nan_fraction": round(nan_count / total_px, 6) if total_px else None,
            "min": float(np.nanmin(sci[finite_mask])) if finite_count else None,
            "max": float(np.nanmax(sci[finite_mask])) if finite_count else None,
            "median": float(np.nanmedian(sci[finite_mask])) if finite_count else None,
            "mean": float(np.nanmean(sci[finite_mask])) if finite_count else None,
            "bunit": str(science_hdu.header.get("BUNIT", "Not available")),
            "has_variance": variance_hdu is not None,
            "has_flags": flags_hdu is not None,
        }

        if flags_hdu is not None:
            flg = np.asarray(flags_hdu.data)
            if flg.ndim == 3:
                flg = flg[0]
            nonzero_flags = int((flg != 0).sum())
            stats["flagged_pixels"] = nonzero_flags
            stats["flagged_fraction"] = round(nonzero_flags / int(flg.size), 6) if flg.size else None

        if variance_hdu is not None:
            var = np.asarray(variance_hdu.data, dtype=np.float64)
            if var.ndim == 3:
                var = var[0]
            valid_var = np.isfinite(var) & (var > 0) & finite_mask
            if valid_var.any():
                snr_map = sci[valid_var] / np.sqrt(var[valid_var])
                stats["median_snr"] = float(np.nanmedian(snr_map))
                stats["max_snr"] = float(np.nanmax(snr_map))
                stats["snr_note"] = "Computed from FITS IMAGE / sqrt(VARIANCE)."
            else:
                stats["median_snr"] = None
                stats["snr_note"] = "VARIANCE extension present but contains no positive finite entries."
        else:
            stats["median_snr"] = None
            stats["snr_note"] = "No VARIANCE extension in this product; SNR not computed."

        try:
            wcs_info = get_wcs_footprint(science_hdu.header, sci.shape)
        except Exception as exc:
            wcs_info = {"error": str(exc)}

        header_cards = [
            {"key": k, "value": str(v), "comment": str(science_hdu.header.comments[k])}
            for k, v in list(science_hdu.header.items())[:80]
            if k and k not in ("COMMENT", "HISTORY")
        ]

        return {
            "extensions": extensions,
            "selected_extension": getattr(science_hdu, "name", "PRIMARY") or "PRIMARY",
            "quality": stats,
            "wcs": wcs_info,
            "header": header_cards,
        }


def build_fits_export(
    data: np.ndarray,
    header: fits.Header,
    *,
    bunit: str,
    provenance: dict[str, Any],
    variance: np.ndarray | None = None,
) -> bytes:
    """Create a valid multi-extension FITS export preserving WCS, units, and provenance."""
    hdr = header.copy()
    hdr["BUNIT"] = bunit
    hdr["HISTORY"] = f"Processed by SphereX: {provenance.get('spherex_processing', '')}"
    hdr["ORIGIN"] = str(provenance.get("data_provider", "SphereX"))[:68]
    hdr["SURVEY"] = str(provenance.get("mission_survey", ""))[:68]
    hdr["OBSID"] = str(provenance.get("source_or_obs_id", ""))[:68]
    hdr["RET_UTC"] = str(provenance.get("retrieval_timestamp", ""))[:68]

    primary = fits.PrimaryHDU()
    primary.header["ORIGIN"] = str(provenance.get("data_provider", "SphereX"))[:68]
    primary.header["DATE"] = str(provenance.get("retrieval_timestamp", ""))[:68]
    img_hdu = fits.ImageHDU(data=np.asarray(data, dtype=np.float32), header=hdr, name="IMAGE")
    hdus = [primary, img_hdu]
    if variance is not None:
        vhdr = hdr.copy()
        vhdr["BUNIT"] = f"({bunit})^2" if bunit and bunit != "Not available" else "variance"
        hdus.append(fits.ImageHDU(data=np.asarray(variance, dtype=np.float32), header=vhdr, name="VARIANCE"))

    out = io.BytesIO()
    fits.HDUList(hdus).writeto(out)
    return out.getvalue()
