"""Astronomical target name resolution using SIMBAD (primary) and NED/IPAC (fallback)."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Any

from astropy import units as u
from astropy.coordinates import SkyCoord

from config import CHALLENGE_TARGETS, DATASET_REGISTRY
from services.http_utils import ProviderUnavailableError, fetch_bytes, fetch_json
from services.provenance_service import build_provenance


def resolve_target(name: str) -> dict[str, Any]:
    cleaned = name.strip()
    if not cleaned:
        raise ValueError("Target name must not be empty.")

    if cleaned.upper() == "WISE 0855":
        spec = CHALLENGE_TARGETS["WISE 0855"]
        return {
            "query": cleaned,
            "resolved_name": spec["resolved_name"],
            "ra": spec["ra"],
            "dec": spec["dec"],
            "coordinate_system": spec["coordinate_system"],
            "source": spec["source"],
            "notes": spec["notes"],
            "provenance": build_provenance(
                data_provider="NASA SPHEREx / Challenge Specification",
                mission_survey="Challenge Reference Target",
                data_release="Official Challenge Brief",
                archive_collection="WISE 0855",
                source_or_obs_id=spec["resolved_name"],
                archive_url="https://irsa.ipac.caltech.edu/Missions/wise.html",
                ra=spec["ra"],
                dec=spec["dec"],
                spherex_processing="Converted sexagesimal J2000/ICRS coordinates to decimal degrees",
            ),
        }

    errors: list[str] = []

    # 1. Try SIMBAD TAP ADQL first
    try:
        escaped = cleaned.replace("'", "''")
        adql = (
            "SELECT TOP 1 main_id, ra, dec, otype_txt "
            f"FROM basic JOIN ident ON oid = ident.oidref WHERE ident.id = '{escaped}'"
        )
        payload = fetch_json(
            DATASET_REGISTRY["reference"]["simbad_tap"],
            method="POST",
            data={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "json", "QUERY": adql},
            timeout=15,
            provider="SIMBAD TAP",
        )
        rows = payload.get("data") or []
        if rows:
            main_id, ra_val, dec_val, otype = rows[0]
            if ra_val is not None and dec_val is not None:
                ra_f = float(ra_val)
                dec_f = float(dec_val)
                return {
                    "query": cleaned,
                    "resolved_name": str(main_id),
                    "ra": ra_f,
                    "dec": dec_f,
                    "object_type": str(otype or "Unknown"),
                    "coordinate_system": "ICRS",
                    "source": "SIMBAD Astronomical Database (CDS TAP)",
                    "provenance": build_provenance(
                        data_provider="CDS Strasbourg SIMBAD",
                        mission_survey="SIMBAD",
                        data_release="Live TAP",
                        archive_collection="basic/ident",
                        source_or_obs_id=str(main_id),
                        archive_url=DATASET_REGISTRY["reference"]["simbad_tap"],
                        ra=ra_f,
                        dec=dec_f,
                    ),
                }
    except Exception as exc:
        errors.append(f"SIMBAD TAP: {exc}")

    # 2. Try CDS Sesame XML resolver
    try:
        raw = fetch_bytes(
            f"{DATASET_REGISTRY['reference']['simbad_sesame']}?{cleaned}",
            timeout=15,
            provider="CDS Sesame",
        )
        text = raw.decode("utf-8", "replace")
        if "<Resolver" in text:
            root = ET.fromstring(text)
            jradeg = root.findtext(".//jradeg")
            jdedeg = root.findtext(".//jdedeg")
            oname = root.findtext(".//oname") or cleaned
            if jradeg and jdedeg:
                ra_f = float(jradeg)
                dec_f = float(jdedeg)
                return {
                    "query": cleaned,
                    "resolved_name": oname,
                    "ra": ra_f,
                    "dec": dec_f,
                    "coordinate_system": "ICRS",
                    "source": "SIMBAD via CDS Sesame Resolver",
                    "provenance": build_provenance(
                        data_provider="CDS Sesame / SIMBAD",
                        mission_survey="SIMBAD",
                        data_release="Live Sesame",
                        archive_collection="SNV",
                        source_or_obs_id=oname,
                        archive_url=DATASET_REGISTRY["reference"]["simbad_sesame"],
                        ra=ra_f,
                        dec=dec_f,
                    ),
                }
    except Exception as exc:
        errors.append(f"CDS Sesame: {exc}")

    # 3. Try Astroquery SIMBAD
    try:
        from astroquery.simbad import Simbad

        table = Simbad.query_object(cleaned)
        if table is not None and len(table) > 0:
            cols = {c.lower(): c for c in table.colnames}
            ra_col = cols.get("ra")
            dec_col = cols.get("dec")
            if ra_col and dec_col:
                row = table[0]
                coord = SkyCoord(str(row[ra_col]), str(row[dec_col]), unit=(u.hourangle, u.deg), frame="icrs")
                main_col = cols.get("main_id")
                resolved = str(row[main_col]) if main_col else cleaned
                return {
                    "query": cleaned,
                    "resolved_name": resolved,
                    "ra": float(coord.ra.deg),
                    "dec": float(coord.dec.deg),
                    "coordinate_system": "ICRS",
                    "source": "SIMBAD Astronomical Database (Astroquery)",
                    "provenance": build_provenance(
                        data_provider="CDS SIMBAD",
                        mission_survey="SIMBAD",
                        data_release="Live",
                        archive_collection="simbad",
                        source_or_obs_id=resolved,
                        archive_url="https://simbad.cds.unistra.fr/",
                        ra=float(coord.ra.deg),
                        dec=float(coord.dec.deg),
                    ),
                }
    except Exception as exc:
        errors.append(f"Astroquery SIMBAD: {exc}")

    # 4. Try NASA/IPAC Extragalactic Database (NED) ObjectLookup as official IPAC fallback
    try:
        ned_payload = fetch_json(
            DATASET_REGISTRY["reference"]["ned_lookup"],
            params={"name": cleaned},
            timeout=15,
            provider="NASA/IPAC NED",
        )
        preferred = ned_payload.get("Preferred") or {}
        pos = preferred.get("Position") or {}
        ra_v = pos.get("RA")
        dec_v = pos.get("Dec")
        if ra_v is not None and dec_v is not None:
            ra_f = float(ra_v)
            dec_f = float(dec_v)
            resolved = str(preferred.get("Name") or ned_payload.get("Supplied") or cleaned)
            return {
                "query": cleaned,
                "resolved_name": resolved,
                "ra": ra_f,
                "dec": dec_f,
                "coordinate_system": "ICRS",
                "source": "NASA/IPAC NED Name Resolver (SIMBAD fallback)",
                "fallback_note": "; ".join(errors),
                "provenance": build_provenance(
                    data_provider="NASA/IPAC NED",
                    mission_survey="NED Name Resolver",
                    data_release="Live",
                    archive_collection="ObjectLookup",
                    source_or_obs_id=resolved,
                    archive_url=DATASET_REGISTRY["reference"]["ned_lookup"],
                    ra=ra_f,
                    dec=dec_f,
                ),
            }
    except Exception as exc:
        errors.append(f"NASA/IPAC NED: {exc}")

    raise ProviderUnavailableError(
        f"Could not resolve '{cleaned}'. Upstream name resolvers returned: {'; '.join(errors)}",
        provider="SIMBAD / NED",
    )
