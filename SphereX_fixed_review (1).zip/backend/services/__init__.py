"""SphereX scientific backend service modules."""
