"""NASA SPHEREx DR1 All-Sky Spectral Cube service (HEALPix order-5 NESTED, 102 channels).

Uses official NASA/IPAC S3 cube FITS tiles and IRSA HiPS properties / calibration metadata.
Avoids downloading full 320 MB tiles by default: parses FITS extension offsets via HTTP Range
and fetches only the target 2D channel plane (1.05 MB) or pixel/aperture column (~1 MB total).
"""
from __future__ import annotations

import io
import math
import struct
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from typing import Any

import numpy as np
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.wcs import WCS
from astropy_healpix import HEALPix

from config import DATASET_REGISTRY
from services.fits_service import build_fits_export, render_array_to_png
from services.http_utils import fetch_bytes, fetch_range
from services.provenance_service import build_provenance

HPX_ORDER5 = HEALPix(nside=32, order="nested", frame="icrs")
BLANK_CHANNELS_1BASED = {51, 52}


def radec_to_healpix_order5(ra: float, dec: float) -> dict[str, Any]:
    coord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")
    npix = int(HPX_ORDER5.skycoord_to_healpix(coord))
    dir_idx = (npix // 10000) * 10000
    s3_base = DATASET_REGISTRY["spherex"]["s3_bucket_url"]
    s3_prefix = DATASET_REGISTRY["spherex"]["s3_cube_prefix"]
    hips_base = DATASET_REGISTRY["spherex"]["hips_cube_url"]
    rel_path = f"Norder5/Dir{dir_idx}/Npix{npix}_cube.fits"
    return {
        "order": 5,
        "nside": 32,
        "ordering": "NESTED",
        "npix": npix,
        "dir_index": dir_idx,
        "s3_url": f"{s3_base}/{s3_prefix}/{rel_path}",
        "irsa_hips_cube_url": f"{hips_base}/{rel_path}",
        "hips_tile_url_template": f"{hips_base}/Norder5/Dir{dir_idx}/Npix{npix}_{{frame}}.png",
    }


@lru_cache(maxsize=1)
def get_official_spectral_channels() -> list[dict[str, Any]]:
    """Load the official 102 SPHEREx spectral channel wavelengths from IRSA HiPS / S3 calibration."""
    # Try IRSA HiPS properties first (fast, ~3.5 KB, lists exact data_cube_crval3_arr + blank channels)
    props_url = f"{DATASET_REGISTRY['spherex']['hips_cube_url']}/properties"
    raw = fetch_bytes(props_url, cache_key="spherex_hips_cube_properties", timeout=20, provider="IRSA SPHEREx HiPS")
    text = raw.decode("utf-8", "replace")
    wavelengths: list[float] = []
    for line in text.splitlines():
        if line.startswith("data_cube_crval3_arr"):
            _, rhs = line.split("=", 1)
            wavelengths = [float(x) for x in rhs.strip().split()]
            break

    if len(wavelengths) != 102:
        raise ValueError(f"Expected 102 wavelengths in SPHEREx cube properties, found {len(wavelengths)}.")

    channels: list[dict[str, Any]] = []
    for idx0, lam_um in enumerate(wavelengths):
        ch_1 = idx0 + 1
        band = (idx0 // 17) + 1
        band_ch = (idx0 % 17) + 1
        is_blank = ch_1 in BLANK_CHANNELS_1BASED
        channels.append({
            "channel": ch_1,
            "frame_index_0based": idx0,
            "band": band,
            "array": f"Array {band}",
            "band_channel": band_ch,
            "wavelength_um": round(lam_um, 6),
            "is_blank": is_blank,
            "status": "blank_dichroic_gap" if is_blank else "active",
            "note": "Blank channel (dichroic transition; no data in DR1 cube)" if is_blank else None,
        })
    return channels


def _read_fits_header_at_offset(url: str, offset: int) -> tuple[fits.Header, int, int, int]:
    """Read a FITS header starting at byte `offset` via small HTTP Range calls."""
    raw = b""
    pos = offset
    for _ in range(12):
        chunk = fetch_range(url, pos, pos + 2880 * 4 - 1, provider="SPHEREx S3 Cube")
        raw += chunk
        pos += len(chunk)
        end_idx = None
        for i in range(0, len(raw), 80):
            if raw[i : i + 80].startswith(b"END     "):
                end_idx = ((i // 2880) + 1) * 2880
                break
        if end_idx is not None:
            hdr = fits.Header.fromstring(raw[:end_idx].decode("ascii", "replace"))
            data_offset = offset + end_idx
            naxis = int(hdr.get("NAXIS", 0))
            bitpix = abs(int(hdr.get("BITPIX", 8))) // 8
            pcount = int(hdr.get("PCOUNT", 0))
            gcount = int(hdr.get("GCOUNT", 1))
            if naxis == 0:
                nbytes = 0
            else:
                nelem = 1
                for k in range(1, naxis + 1):
                    nelem *= int(hdr.get(f"NAXIS{k}", 1))
                nbytes = (nelem + pcount) * gcount * bitpix
            padded = ((nbytes + 2879) // 2880) * 2880
            return hdr, data_offset, nbytes, data_offset + padded
    raise ValueError("Could not locate FITS END card within 12 header blocks.")


@lru_cache(maxsize=64)
def _inspect_cube_layout(tile_url: str) -> dict[str, Any]:
    """Parse FITS HDU offsets (PRIMARY, IMAGE, NHITS, FLAGS) and 2D WCS for a cube tile."""
    off = 0
    hdus: dict[str, dict[str, Any]] = {}
    for idx in range(6):
        try:
            hdr, doff, nbytes, next_off = _read_fits_header_at_offset(tile_url, off)
        except Exception:
            break
        extname = str(hdr.get("EXTNAME", "PRIMARY" if idx == 0 else f"HDU_{idx}")).strip().upper()
        hdus[extname] = {
            "index": idx,
            "header": hdr,
            "data_offset": doff,
            "nbytes": nbytes,
            "bitpix": int(hdr.get("BITPIX", 8)),
            "dims": [int(hdr.get(f"NAXIS{k}", 0)) for k in range(1, int(hdr.get("NAXIS", 0)) + 1)],
        }
        off = next_off

    if "IMAGE" not in hdus:
        raise ValueError("SPHEREx cube FITS does not contain an IMAGE extension.")

    img_hdr = hdus["IMAGE"]["header"].copy()
    for key in list(img_hdr.keys()):
        if key.endswith("3") or "_3" in key or key.startswith(("PS3", "PV3", "PC3")):
            del img_hdr[key]
    img_hdr["NAXIS"] = 2
    img_hdr["WCSAXES"] = 2
    wcs_2d = WCS(img_hdr).celestial
    return {
        "hdus": hdus,
        "wcs_2d": wcs_2d,
        "bunit": str(img_hdr.get("BUNIT", "MJy/sr")).strip(),
        "blankch": str(hdus.get("PRIMARY", {}).get("header", {}).get("BLANKCH", "D3:17,D4:01")),
        "dims": hdus["IMAGE"]["dims"],
    }


def _resolve_tile_and_pixel(ra: float, dec: float) -> tuple[dict[str, Any], dict[str, Any], float, float]:
    tile = radec_to_healpix_order5(ra, dec)
    layout = _inspect_cube_layout(tile["s3_url"])
    coord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame="icrs")
    px, py = layout["wcs_2d"].world_to_pixel(coord)
    return tile, layout, float(px), float(py)


def search_cube_tile(ra: float, dec: float) -> dict[str, Any]:
    tile, layout, px, py = _resolve_tile_and_pixel(ra, dec)
    dims = layout["dims"]
    nx, ny, nchan = dims[0], dims[1], dims[2]
    in_bounds = (0 <= px < nx) and (0 <= py < ny)
    channels = get_official_spectral_channels()
    return {
        "tile": tile,
        "target": {"ra": ra, "dec": dec, "pixel_x": px, "pixel_y": py, "in_bounds": in_bounds},
        "cube_dimensions": {"nx": nx, "ny": ny, "n_channels": nchan},
        "bunit": layout["bunit"],
        "blank_channels_header": layout["blankch"],
        "has_variance": "VARIANCE" in layout["hdus"],
        "channels": channels,
        "provenance": build_provenance(
            data_provider="NASA/IPAC IRSA (AWS Open Data S3)",
            mission_survey="NASA SPHEREx DR1 All-Sky Spectral Cube",
            data_release="DR1",
            archive_collection="spherex_dr1_cube",
            source_or_obs_id=f"Norder5/Npix{tile['npix']}_cube.fits",
            archive_url=tile["s3_url"],
            ra=ra,
            dec=dec,
            instrument_detector="SPHEREx LVF Arrays 1–6",
            wavelength_or_filter="0.753–4.988 µm (102 channels)",
            units=layout["bunit"],
            processing_version="hips_20261026",
            spherex_processing="HEALPix order-5 NESTED lookup + HTTP Range FITS WCS header inspection",
        ),
    }



def _dtype_for_bitpix(bitpix: int) -> np.dtype:
    mapping = {8: ">u1", 16: ">i2", 32: ">i4", 64: ">i8", -32: ">f4", -64: ">f8"}
    if bitpix not in mapping:
        raise ValueError(f"Unsupported FITS BITPIX value: {bitpix}")
    return np.dtype(mapping[bitpix])


def _apply_fits_scaling(values: np.ndarray, header: fits.Header) -> np.ndarray:
    bscale = float(header.get("BSCALE", 1.0))
    bzero = float(header.get("BZERO", 0.0))
    if bscale != 1.0 or bzero != 0.0:
        return values.astype(np.float64) * bscale + bzero
    return values.astype(np.float64, copy=False)

def _read_box_for_channel(
    url: str,
    data_offset: int,
    bitpix: int,
    nx: int,
    ny: int,
    ch_idx0: int,
    ix: int,
    iy: int,
    radius_px: int,
    bscale: float = 1.0,
    bzero: float = 0.0,
) -> np.ndarray:
    """Read a small spatial box (2*radius_px+1)^2 at channel `ch_idx0` via HTTP Range."""
    dtype = _dtype_for_bitpix(bitpix)
    elem_bytes = dtype.itemsize
    y0 = max(0, iy - radius_px)
    y1 = min(ny - 1, iy + radius_px)
    x0 = max(0, ix - radius_px)
    x1 = min(nx - 1, ix + radius_px)
    row_start_byte = data_offset + ((ch_idx0 * ny * nx) + (y0 * nx) + x0) * elem_bytes
    row_end_byte = data_offset + ((ch_idx0 * ny * nx) + (y1 * nx) + x1 + 1) * elem_bytes - 1
    raw = fetch_range(url, row_start_byte, row_end_byte, provider="SPHEREx S3 Cube")
    expected_elements = (y1 - y0) * nx + (x1 - x0 + 1)
    if len(raw) != expected_elements * elem_bytes:
        raise ValueError("SPHEREx cube range response has an unexpected byte length.")
    flat = np.frombuffer(raw, dtype=dtype)
    # Extract exact sub-box from contiguous span [y0..y1]
    vals: list[float] = []
    for row in range(y0, y1 + 1):
        offset_elems = 0 if row == y0 else (row - y0) * nx - x0
        seg = flat[offset_elems : offset_elems + (x1 - x0 + 1)]
        vals.extend(seg.tolist())
    return np.asarray(vals, dtype=np.float64) * bscale + bzero


def extract_cube_spectrum(
    *,
    ra: float,
    dec: float,
    aperture_radius_px: int = 0,
    mask_flagged: bool = True,
) -> dict[str, Any]:
    """Extract a genuine 102-channel spectrum from the DR1 All-Sky Cube at (ra, dec)."""
    tile, layout, px, py = _resolve_tile_and_pixel(ra, dec)
    dims = layout["dims"]
    nx, ny, nchan = dims[0], dims[1], dims[2]
    if not (0 <= px < nx and 0 <= py < ny):
        raise ValueError("The requested sky coordinate falls outside the selected SPHEREx cube tile.")
    ix = int(np.clip(round(px), 0, nx - 1))
    iy = int(np.clip(round(py), 0, ny - 1))
    radius_px = max(0, min(3, int(aperture_radius_px)))

    url = tile["s3_url"]
    img_meta = layout["hdus"]["IMAGE"]
    nhits_meta = layout["hdus"].get("NHITS")
    flags_meta = layout["hdus"].get("FLAGS")
    channels_meta = get_official_spectral_channels()

    def fetch_channel_point(ch_idx0: int) -> dict[str, Any]:
        ch_info = channels_meta[ch_idx0]
        if ch_info["is_blank"]:
            return {
                **ch_info,
                "surface_brightness": None,
                "nhits": 0,
                "flags": None,
                "valid": False,
                "reason": "Blank channel (D3:17 / D4:01)",
            }

        img_vals = _read_box_for_channel(url, img_meta["data_offset"], img_meta["bitpix"], nx, ny, ch_idx0, ix, iy, radius_px,
                                        float(img_meta["header"].get("BSCALE", 1.0)), float(img_meta["header"].get("BZERO", 0.0)))
        nhits_vals = (
            _read_box_for_channel(url, nhits_meta["data_offset"], nhits_meta["bitpix"], nx, ny, ch_idx0, ix, iy, radius_px,
                                  float(nhits_meta["header"].get("BSCALE", 1.0)), float(nhits_meta["header"].get("BZERO", 0.0)))
            if nhits_meta
            else np.zeros_like(img_vals)
        )
        flags_vals = (
            _read_box_for_channel(url, flags_meta["data_offset"], flags_meta["bitpix"], nx, ny, ch_idx0, ix, iy, radius_px,
                                  float(flags_meta["header"].get("BSCALE", 1.0)), float(flags_meta["header"].get("BZERO", 0.0)))
            if flags_meta
            else np.zeros_like(img_vals)
        )

        valid_mask = np.isfinite(img_vals)
        if mask_flagged and flags_meta is not None:
            valid_mask &= (flags_vals == 0)

        x0 = max(0, ix - radius_px)
        y0 = max(0, iy - radius_px)
        x1 = min(nx - 1, ix + radius_px)
        row_width = x1 - x0 + 1
        center_idx = (iy - y0) * row_width + (ix - x0)
        center_flag = int(flags_vals[center_idx]) if flags_meta else 0
        nhits_med = int(round(float(np.median(nhits_vals)))) if len(nhits_vals) else 0

        if valid_mask.any():
            sb = float(np.mean(img_vals[valid_mask]))
            valid = True
            reason = None
        else:
            sb = None
            valid = False
            reason = "Masked by quality FLAGS" if (np.isfinite(img_vals).any() and mask_flagged) else "NaN in archive cube"

        return {
            **ch_info,
            "surface_brightness": sb,
            "nhits": nhits_med,
            "flags": center_flag,
            "valid": valid,
            "reason": reason,
        }

    with ThreadPoolExecutor(max_workers=12) as pool:
        points = list(pool.map(fetch_channel_point, range(nchan)))

    valid_count = sum(1 for p in points if p["valid"])
    return {
        "tile": tile,
        "position": {
            "ra": ra,
            "dec": dec,
            "pixel_x": ix,
            "pixel_y": iy,
            "subpixel_x": px,
            "subpixel_y": py,
            "aperture_radius_px": radius_px,
            "measurement_type": "Single-pixel surface brightness" if radius_px == 0 else f"Aperture-averaged surface brightness ({2*radius_px+1}x{2*radius_px+1} px)",
        },
        "units": layout["bunit"],
        "uncertainty_note": "SPHEREx DR1 All-Sky Cube does not include a VARIANCE extension; NHITS represents contributing exposure count, not measurement uncertainty. No synthetic error bars are plotted.",
        "blank_channels": sorted(BLANK_CHANNELS_1BASED),
        "valid_channels": valid_count,
        "total_channels": nchan,
        "mask_flagged": mask_flagged,
        "spectrum": points,
        "provenance": build_provenance(
            data_provider="NASA/IPAC IRSA (AWS Open Data S3)",
            mission_survey="NASA SPHEREx DR1 All-Sky Spectral Cube",
            data_release="DR1",
            archive_collection="spherex_dr1_cube",
            source_or_obs_id=f"Norder5/Npix{tile['npix']}_cube.fits",
            archive_url=tile["s3_url"],
            ra=ra,
            dec=dec,
            instrument_detector="SPHEREx LVF Arrays 1–6",
            wavelength_or_filter="0.753–4.988 µm (102 channels)",
            units=layout["bunit"],
            uncertainties="Not provided in DR1 cube (no VARIANCE extension)",
            processing_version="hips_20261026",
            spherex_processing="Exact pixel/aperture extraction from FITS IMAGE, NHITS, and FLAGS extensions",
        ),
    }


def _fetch_channel_plane(url: str, hdu_meta: dict[str, Any], channel_1based: int) -> np.ndarray:
    nx, ny, nchan = hdu_meta["dims"]
    if channel_1based < 1 or channel_1based > nchan:
        raise ValueError(f"Channel must be between 1 and {nchan}.")
    ch0 = channel_1based - 1
    dtype = _dtype_for_bitpix(hdu_meta["bitpix"])
    elem_bytes = dtype.itemsize
    plane_bytes = nx * ny * elem_bytes
    start = hdu_meta["data_offset"] + ch0 * plane_bytes
    end = start + plane_bytes - 1
    raw = fetch_range(url, start, end, provider="SPHEREx S3 Cube")
    if len(raw) != plane_bytes:
        raise ValueError("SPHEREx cube channel range response has an unexpected byte length.")
    plane = np.frombuffer(raw, dtype=dtype).reshape((ny, nx))
    return _apply_fits_scaling(plane, hdu_meta["header"]).astype(np.float32)


def render_cube_channel_png(
    *,
    ra: float,
    dec: float,
    channel: int,
    stretch: str = "asinh",
    palette: str = "spherex_ir",
) -> tuple[bytes, dict[str, str]]:
    if channel in BLANK_CHANNELS_1BASED:
        raise ValueError(f"Channel {channel} is an intentional blank dichroic channel in SPHEREx DR1 cube.")
    tile, layout, px, py = _resolve_tile_and_pixel(ra, dec)
    nx, ny = layout["dims"][:2]
    if not (0 <= px < nx and 0 <= py < ny):
        raise ValueError("The requested sky coordinate falls outside the selected SPHEREx cube tile.")
    plane = _fetch_channel_plane(tile["s3_url"], layout["hdus"]["IMAGE"], channel)
    png = render_array_to_png(plane, stretch=stretch, palette=palette)
    ch_meta = get_official_spectral_channels()[channel - 1]
    headers = {
        "X-Spherex-Tile-Npix": str(tile["npix"]),
        "X-Spherex-Channel": str(channel),
        "X-Spherex-Wavelength-Um": str(ch_meta["wavelength_um"]),
        "X-Spherex-Units": layout["bunit"],
        "X-Spherex-Target-Pixel": f"{px:.2f},{py:.2f}",
    }
    return png, headers


def export_cube_channel_fits(*, ra: float, dec: float, channel: int) -> bytes:
    if channel in BLANK_CHANNELS_1BASED:
        raise ValueError(f"Channel {channel} is blank and has no image plane to export.")
    tile, layout, px, py = _resolve_tile_and_pixel(ra, dec)
    nx, ny = layout["dims"][:2]
    if not (0 <= px < nx and 0 <= py < ny):
        raise ValueError("The requested sky coordinate falls outside the selected SPHEREx cube tile.")
    plane = _fetch_channel_plane(tile["s3_url"], layout["hdus"]["IMAGE"], channel)
    ch_meta = get_official_spectral_channels()[channel - 1]
    hdr_2d = layout["wcs_2d"].to_header()
    hdr_2d["CHANNEL"] = channel
    hdr_2d["WAVE_UM"] = ch_meta["wavelength_um"]
    prov = build_provenance(
        data_provider="NASA/IPAC IRSA (AWS Open Data S3)",
        mission_survey="NASA SPHEREx DR1 All-Sky Spectral Cube",
        data_release="DR1",
        archive_collection="spherex_dr1_cube",
        source_or_obs_id=f"Npix{tile['npix']}_ch{channel}",
        archive_url=tile["s3_url"],
        ra=ra,
        dec=dec,
        wavelength_or_filter=f"{ch_meta['wavelength_um']} um (Channel {channel})",
        units=layout["bunit"],
        spherex_processing="Single-channel 2D FITS slice extracted from SPHEREx DR1 All-Sky Cube",
    )
    return build_fits_export(plane, hdr_2d, bunit=layout["bunit"], provenance=prov)
