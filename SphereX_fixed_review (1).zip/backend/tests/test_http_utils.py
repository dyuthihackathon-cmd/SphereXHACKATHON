"""Focused tests for safe archive byte retrieval and cache validation."""
from __future__ import annotations

from pathlib import Path
import sys
from unittest.mock import Mock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from services import http_utils  # noqa: E402


class FakeResponse:
    def __init__(self, status_code: int, headers: dict[str, str], chunks: list[bytes]):
        self.status_code = status_code
        self.headers = headers
        self._chunks = chunks

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def raise_for_status(self):
        return None

    def iter_content(self, chunk_size: int):
        yield from self._chunks


def test_fetch_range_requires_partial_content_and_exact_range(monkeypatch):
    expected = b"abcdef"
    response = FakeResponse(206, {"Content-Range": "bytes 10-15/100"}, [b"abc", b"def"])
    get = Mock(return_value=response)
    monkeypatch.setattr(http_utils._SESSION, "get", get)

    assert http_utils.fetch_range("https://archive.example/data", 10, 15) == expected
    assert get.call_args.kwargs["headers"]["Range"] == "bytes=10-15"
    assert get.call_args.kwargs["headers"]["Accept-Encoding"] == "identity"
    assert get.call_args.kwargs["stream"] is True


def test_fetch_range_rejects_server_that_ignores_range(monkeypatch):
    response = FakeResponse(200, {}, [b"whole file"])
    monkeypatch.setattr(http_utils._SESSION, "get", Mock(return_value=response))

    with pytest.raises(http_utils.ProviderUnavailableError, match="did not honor"):
        http_utils.fetch_range("https://archive.example/data", 10, 15)


def test_fetch_range_rejects_incomplete_content_range(monkeypatch):
    response = FakeResponse(206, {"Content-Range": "bytes 10-14/100"}, [b"abcde"])
    monkeypatch.setattr(http_utils._SESSION, "get", Mock(return_value=response))

    with pytest.raises(http_utils.ProviderUnavailableError, match="unexpected Content-Range"):
        http_utils.fetch_range("https://archive.example/data", 10, 15)


def test_fetch_bytes_does_not_cache_invalid_payload(monkeypatch, tmp_path: Path):
    cache_file = tmp_path / "bad-cache.bin"
    cache_file.write_bytes(b"old invalid response")
    monkeypatch.setattr(http_utils, "_cache_path", lambda _key: cache_file)
    response = FakeResponse(200, {}, [b"new invalid response"])
    monkeypatch.setattr(http_utils._SESSION, "get", Mock(return_value=response))

    def validator(_payload: bytes) -> None:
        raise http_utils.ProviderUnavailableError("invalid archive payload")

    with pytest.raises(http_utils.ProviderUnavailableError, match="invalid archive payload"):
        http_utils.fetch_bytes("https://archive.example/data", cache_key="bad", validator=validator)
    assert not cache_file.exists()
