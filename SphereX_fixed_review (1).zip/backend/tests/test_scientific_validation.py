"""Scientific validation and API tests for SphereX backend."""
from __future__ import annotations

import io
import sys
from pathlib import Path

import numpy as np
import pytest
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.wcs import WCS
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from main import app  # noqa: E402
from services.difference_imaging_service import compute_difference_analysis  # noqa: E402
from services.fits_service import build_fits_export, inspect_mef, render_array_to_png  # noqa: E402
from services.proper_motion_service import propagate_gaia_proper_motion  # noqa: E402
from services.provenance_service import build_provenance  # noqa: E402
from services.source_detection_service import ALLOWED_LABELS, analyze_moving_object_candidates, detect_sources_in_fits  # noqa: E402
from services.spherex_cube_service import BLANK_CHANNELS_1BASED, radec_to_healpix_order5  # noqa: E402
from services.wcs_service import pixel_to_world_from_bytes, world_to_pixel_from_bytes  # noqa: E402

client = TestClient(app)


def _make_test_fits(
    *,
    ra_center: float = 133.79512917,
    dec_center: float = -7.24514722,
    shape: tuple[int, int] = (64, 64),
    with_variance: bool = True,
    shift_star_px: tuple[float, float] = (32.0, 32.0),
) -> bytes:
    w = WCS(naxis=2)
    w.wcs.crpix = [shape[1] / 2.0, shape[0] / 2.0]
    w.wcs.cdelt = [-0.0005, 0.0005]
    w.wcs.crval = [ra_center, dec_center]
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]

    yy, xx = np.mgrid[0 : shape[0], 0 : shape[1]]
    sx, sy = shift_star_px
    sci = 2.0 + 100.0 * np.exp(-((xx - sx) ** 2 + (yy - sy) ** 2) / (2.0 * 1.4 ** 2))
    flg = np.zeros(shape, dtype=np.int32)
    flg[0, 0] = 1

    hdr = w.to_header()
    hdr["BUNIT"] = "MJy/sr"
    hdus = [
        fits.PrimaryHDU(),
        fits.ImageHDU(data=sci.astype(np.float32), header=hdr, name="IMAGE"),
        fits.ImageHDU(data=flg, header=hdr, name="FLAGS"),
    ]
    if with_variance:
        var = np.full(shape, 0.25, dtype=np.float32)
        hdus.append(fits.ImageHDU(data=var, header=hdr, name="VARIANCE"))

    buf = io.BytesIO()
    fits.HDUList(hdus).writeto(buf)
    return buf.getvalue()


def test_health_and_openapi():
    res = client.get("/api/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"
    docs = client.get("/openapi.json")
    assert docs.status_code == 200
    assert "/api/spherex/cube/spectrum" in docs.json()["paths"]


def test_invalid_coordinates_rejected():
    assert client.get("/api/observations", params={"ra": 365, "dec": 0}).status_code == 422
    assert client.get("/api/observations", params={"ra": 10, "dec": -95}).status_code == 422
    assert client.get("/api/observations/preview", params={"access_url": "https://example.com/bad.fits", "ra": 10, "dec": 10}).status_code == 400


def test_wcs_round_trip_and_ra_wraparound():
    # Near RA = 359.99 deg to verify wraparound across 0/360 boundary
    raw = _make_test_fits(ra_center=359.99, dec_center=88.5)
    world = pixel_to_world_from_bytes(raw, 31.0, 31.0)
    assert 0.0 <= world["ra"] < 360.0
    assert 88.0 < world["dec"] < 89.0
    back = world_to_pixel_from_bytes(raw, world["ra"], world["dec"])
    assert abs(back["pixel_x"] - 31.0) < 1e-5
    assert abs(back["pixel_y"] - 31.0) < 1e-5


def test_mef_inspection_variance_vs_no_variance():
    with_var = inspect_mef(_make_test_fits(with_variance=True))
    assert with_var["quality"]["has_variance"] is True
    assert with_var["quality"]["median_snr"] is not None
    assert with_var["quality"]["flagged_pixels"] == 1

    without_var = inspect_mef(_make_test_fits(with_variance=False))
    assert without_var["quality"]["has_variance"] is False
    assert without_var["quality"]["median_snr"] is None


def test_fits_export_preserves_wcs_and_provenance():
    raw = _make_test_fits()
    with fits.open(io.BytesIO(raw)) as hdul:
        img = hdul["IMAGE"].data
        hdr = hdul["IMAGE"].header
    prov = build_provenance(
        data_provider="Test Archive",
        mission_survey="SPHEREx",
        data_release="DR1",
        archive_collection="spherex_dr1",
        source_or_obs_id="test_obs_1",
        archive_url="https://irsa.ipac.caltech.edu/",
        spherex_processing="Unit test",
    )
    exported = build_fits_export(img, hdr, bunit="MJy/sr", provenance=prov)
    with fits.open(io.BytesIO(exported)) as out_hdul:
        assert out_hdul["IMAGE"].header["BUNIT"] == "MJy/sr"
        assert out_hdul["IMAGE"].header["OBSID"] == "test_obs_1"
        assert WCS(out_hdul["IMAGE"].header).has_celestial


def test_healpix_order5_tile_and_blank_channels():
    tile = radec_to_healpix_order5(133.79512917, -7.24514722)
    assert tile["order"] == 5
    assert tile["ordering"] == "NESTED"
    assert 0 <= tile["npix"] < 12288
    assert BLANK_CHANNELS_1BASED == {51, 52}


def test_proper_motion_propagation_barnards_star():
    # Barnard's Star approx Gaia DR3 values (pmra ~ -801.55 mas/yr, pmdec ~ 10362.39 mas/yr)
    res = propagate_gaia_proper_motion(
        source_id="4472832130942575872",
        ra=269.4485025,
        dec=4.7394200,
        pmra=-801.55,
        pmdec=10362.39,
        parallax=546.9759,
        radial_velocity=None,
        ref_epoch=2016.0,
        target_epoch_year=2026.0,
    )
    # 10 years at ~10.39 arcsec/yr -> ~103.9 arcsec total displacement
    assert 100.0 < res["angular_displacement_arcsec"] < 108.0
    assert res["radial_velocity_used_km_s"] is None
    assert len(res["trajectory"]) == 10


def test_difference_imaging_and_source_detection():
    fits_a = _make_test_fits(shift_star_px=(30.0, 30.0), with_variance=True)
    fits_b = _make_test_fits(shift_star_px=(35.0, 32.0), with_variance=True)
    diff = compute_difference_analysis(
        fits_a,
        fits_b,
        meta_a={"id": "obsA", "collection": "spherex_dr1", "mission": "SPHEREx"},
        meta_b={"id": "obsB", "collection": "spherex_dr1", "mission": "SPHEREx"},
    )
    assert diff["registration"]["overlap_fraction"] > 0.9
    assert diff["statistics"]["has_significance_map"] is True
    assert diff["statistics"]["max_abs_significance_sigma"] > 10.0

    det_a = detect_sources_in_fits(fits_a, obs_id="obsA", obs_mjd=60800.0)
    det_b = detect_sources_in_fits(fits_b, obs_id="obsB", obs_mjd=60801.0)
    assert det_a["count"] >= 1
    assert det_b["count"] >= 1

    cand = analyze_moving_object_candidates(
        epoch_detections=[det_a, det_b],
        ra_center=133.79512917,
        dec_center=-7.24514722,
        enable_gaia_crossmatch=False,
    )
    for item in cand["candidates"]:
        assert item["classification"] in ALLOWED_LABELS


def test_png_rendering_stretches_and_palettes():
    arr = np.linspace(0.0, 100.0, 64 * 64).reshape((64, 64)).astype(np.float32)
    for stretch in ("linear", "log", "asinh", "sqrt", "zscale"):
        for palette in ("monochrome", "spherex_ir", "cyan_amber", "plasma", "viridis"):
            png = render_array_to_png(arr, stretch=stretch, palette=palette)
            assert png.startswith(b"\x89PNG")
