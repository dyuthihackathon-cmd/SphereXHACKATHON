"""SphereX Scientific Backend — FastAPI application and modular API routes."""
from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field

from config import DATASET_REGISTRY
from services.difference_imaging_service import compute_difference_analysis, export_difference_fits
from services.gaia_service import query_gaia_sources
from services.hips_proxy_service import HIPS_SURVEYS, fetch_hips_tile
from services.horizons_service import query_horizons_ephemeris
from services.http_utils import ArchiveError, fetch_json
from services.mpc_service import query_mpc_observations, query_mpc_orbit
from services.neowise_service import query_neowise_lightcurve
from services.proper_motion_service import propagate_gaia_proper_motion
from services.reference_catalogs_service import query_panstarrs_dr2, query_twomass_psc
from services.simbad_service import resolve_target
from services.source_detection_service import analyze_moving_object_candidates, detect_sources_in_fits
from services.spherex_cube_service import (
    export_cube_channel_fits,
    extract_cube_spectrum,
    get_official_spectral_channels,
    render_cube_channel_png,
    search_cube_tile,
)
from services.spherex_service import (
    export_spherex_cutout_fits,
    fetch_spherex_cutout_bytes,
    inspect_spherex_cutout,
    render_spherex_preview,
    search_spherex_observations,
)
from services.wcs_service import pixel_to_world_from_bytes, world_to_pixel_from_bytes
from services.wise_service import (
    export_wise_fits,
    fetch_wise_fits_bytes,
    inspect_wise_fits,
    render_wise_preview,
    search_wise_images,
)
from services.ztf_service import query_ztf_dr24_lightcurve, search_ztf_images

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
logger = logging.getLogger("spherex.api")

app = FastAPI(
    title="SphereX Multi-Wavelength Astronomy API",
    version="1.0.0",
    description="Scientific backend connecting NASA SPHEREx, WISE/NEOWISE-R, ESA Gaia DR3, ZTF DR24, JPL Horizons, and MPC.",
)

allowed_origins = os.getenv(
    "SPHEREX_ALLOWED_ORIGINS",
    "http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173,http://127.0.0.1:5173",
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in allowed_origins if o.strip()],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.exception_handler(ArchiveError)
async def archive_error_handler(_request: Any, exc: ArchiveError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"status": exc.error_code, "provider": exc.provider, "detail": str(exc)},
    )


@app.get("/api/health")
def health() -> dict[str, Any]:
    """Application health (separate from external archive connectivity checks)."""
    return {
        "status": "ok",
        "service": "SphereX Scientific FastAPI Bridge",
        "version": "1.0.0",
        "datasets_configured": list(DATASET_REGISTRY.keys()),
    }


@app.get("/api/archive/status")
def archive_status() -> dict[str, Any]:
    """Probe external archive connectivity live without fabricating success."""
    probes = {
        "spherex_s3_cube": f"{DATASET_REGISTRY['spherex']['s3_bucket_url']}/?list-type=2&max-keys=1",
        "spherex_hips": f"{DATASET_REGISTRY['spherex']['hips_cube_url']}/properties",
        "irsa_sia": f"{DATASET_REGISTRY['spherex']['sia_url']}?COLLECTION=spherex_dr1&MAXREC=1",
        "wise_s3": f"{DATASET_REGISTRY['wise']['s3_bucket_url']}/?list-type=2&max-keys=1",
        "ztf_s3": f"{DATASET_REGISTRY['ztf']['s3_bucket_url']}/?list-type=2&max-keys=1",
        "gaia_tap_primary": "https://gea.esac.esa.int/tap-server/tap/availability",
        "gaia_tap_mirror": "https://gaia.ari.uni-heidelberg.de/tap/availability",
        "jpl_horizons": f"{DATASET_REGISTRY['horizons']['api_url']}?format=json&COMMAND='499'&OBJ_DATA=NO&MAKE_EPHEM=NO",
        "panstarrs_mast": f"{DATASET_REGISTRY['reference']['panstarrs_dr2']}?ra=10&dec=10&radius=0.01&pagesize=1",
    }
    import requests

    results: dict[str, Any] = {}
    for name, url in probes.items():
        try:
            r = requests.get(url, timeout=6, headers={"User-Agent": "SphereX-Probe/1.0"})
            results[name] = {"reachable": r.status_code < 400, "http_status": r.status_code}
        except Exception as exc:
            results[name] = {"reachable": False, "error": type(exc).__name__}
    return {"status": "ok", "providers": results}


@app.get("/api/resolve-target")
def api_resolve_target(name: str = Query(..., min_length=1, max_length=120)) -> dict[str, Any]:
    return resolve_target(name)


@app.get("/api/observations")
def api_observations(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
    release: str = Query("both", pattern="^(dr1|qr3|both)$"),
    include_deep: bool = Query(False),
    start_date: str | None = Query(None),
    end_date: str | None = Query(None),
    limit: int = Query(100, ge=1, le=300),
) -> dict[str, Any]:
    return search_spherex_observations(
        ra=ra,
        dec=dec,
        fov_arcmin=fov_arcmin,
        release=release,
        include_deep=include_deep,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )


@app.get("/api/observations/preview")
def api_observation_preview(
    access_url: str = Query(..., min_length=20),
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
    stretch: str = Query("asinh", pattern="^(linear|log|asinh|sqrt|zscale)$"),
    palette: str = Query("monochrome", pattern="^(monochrome|spherex_ir|cyan_amber|plasma|magma|viridis)$"),
    ext_name: str = Query("IMAGE"),
) -> Response:
    png, headers = render_spherex_preview(
        access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin, stretch=stretch, palette=palette, ext_name=ext_name
    )
    return Response(content=png, media_type="image/png", headers=headers)


@app.get("/api/observations/inspect")
def api_observation_inspect(
    access_url: str = Query(..., min_length=20),
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
    ext_name: str = Query("IMAGE"),
) -> dict[str, Any]:
    return inspect_spherex_cutout(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin, ext_name=ext_name)


@app.get("/api/observations/fits")
def api_observation_fits(
    access_url: str = Query(..., min_length=20),
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
) -> Response:
    fits_bytes = export_spherex_cutout_fits(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    return Response(
        content=fits_bytes,
        media_type="application/fits",
        headers={"Content-Disposition": 'attachment; filename="spherex_cutout_wcs.fits"'},
    )


# --- SPHEREx 102-Channel All-Sky Spectral Cube ---

@app.get("/api/spherex/channels")
def api_spherex_channels() -> dict[str, Any]:
    channels = get_official_spectral_channels()
    return {"count": len(channels), "blank_channels": [51, 52], "channels": channels}


@app.get("/api/spherex/cube/search")
def api_spherex_cube_search(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
) -> dict[str, Any]:
    return search_cube_tile(ra, dec)


@app.get("/api/spherex/cube/spectrum")
def api_spherex_cube_spectrum(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    aperture_radius_px: int = Query(0, ge=0, le=3),
    mask_flagged: bool = Query(True),
) -> dict[str, Any]:
    try:
        return extract_cube_spectrum(ra=ra, dec=dec, aperture_radius_px=aperture_radius_px, mask_flagged=mask_flagged)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/spherex/cube/slice.png")
def api_spherex_cube_slice_png(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    channel: int = Query(..., ge=1, le=102),
    stretch: str = Query("asinh", pattern="^(linear|log|asinh|sqrt|zscale)$"),
    palette: str = Query("spherex_ir", pattern="^(monochrome|spherex_ir|cyan_amber|plasma|magma|viridis)$"),
) -> Response:
    try:
        png, headers = render_cube_channel_png(ra=ra, dec=dec, channel=channel, stretch=stretch, palette=palette)
        return Response(content=png, media_type="image/png", headers=headers)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/spherex/cube/slice.fits")
def api_spherex_cube_slice_fits(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    channel: int = Query(..., ge=1, le=102),
) -> Response:
    try:
        data = export_cube_channel_fits(ra=ra, dec=dec, channel=channel)
        return Response(
            content=data,
            media_type="application/fits",
            headers={"Content-Disposition": f'attachment; filename="spherex_dr1_cube_ch{channel:03d}.fits"'},
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


# --- WISE / NEOWISE-R ---

@app.get("/api/wise/images")
def api_wise_images(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcmin: float = Query(3.0, gt=0, le=60),
    collection: str = Query("wise_allwise"),
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, Any]:
    return search_wise_images(ra=ra, dec=dec, radius_arcmin=radius_arcmin, collection=collection, limit=limit)


@app.get("/api/wise/preview")
def api_wise_preview(
    access_url: str = Query(..., min_length=20),
    ra: float | None = Query(None, ge=0, lt=360),
    dec: float | None = Query(None, ge=-90, le=90),
    fov_arcmin: float | None = Query(None, gt=0, le=60),
    stretch: str = Query("asinh", pattern="^(linear|log|asinh|sqrt|zscale)$"),
    palette: str = Query("monochrome", pattern="^(monochrome|spherex_ir|cyan_amber|plasma|magma|viridis)$"),
) -> Response:
    png, headers = render_wise_preview(
        access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin, stretch=stretch, palette=palette
    )
    return Response(content=png, media_type="image/png", headers=headers)


@app.get("/api/wise/inspect")
def api_wise_inspect(
    access_url: str = Query(..., min_length=20),
    ra: float | None = Query(None, ge=0, lt=360),
    dec: float | None = Query(None, ge=-90, le=90),
    fov_arcmin: float | None = Query(None, gt=0, le=60),
) -> dict[str, Any]:
    return inspect_wise_fits(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)


@app.get("/api/wise/fits")
def api_wise_fits(
    access_url: str = Query(..., min_length=20),
    ra: float | None = Query(None, ge=0, lt=360),
    dec: float | None = Query(None, ge=-90, le=90),
    fov_arcmin: float | None = Query(None, gt=0, le=60),
) -> Response:
    data = export_wise_fits(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    return Response(
        content=data,
        media_type="application/fits",
        headers={"Content-Disposition": 'attachment; filename="wise_cutout_wcs.fits"'},
    )


@app.get("/api/neowise/lightcurve")
def api_neowise_lightcurve(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcsec: float = Query(5.0, gt=0.1, le=60),
    association_radius_arcsec: float = Query(2.5, gt=0.1, le=30),
    partitions: str | None = Query(None, description="Comma-separated NEOWISE partitions e.g. year1,year2"),
) -> dict[str, Any]:
    part_list = [p.strip() for p in partitions.split(",") if p.strip()] if partitions else None
    return query_neowise_lightcurve(
        ra=ra,
        dec=dec,
        radius_arcsec=radius_arcsec,
        partitions=part_list,
        association_radius_arcsec=association_radius_arcsec,
    )


# --- ESA Gaia DR3 & Proper Motion ---

@app.get("/api/gaia/sources")
def api_gaia_sources(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcmin: float = Query(3.0, gt=0, le=60),
    limit: int = Query(100, ge=1, le=500),
    max_g_mag: float | None = Query(None),
) -> dict[str, Any]:
    return query_gaia_sources(ra=ra, dec=dec, radius_arcmin=radius_arcmin, limit=limit, max_g_mag=max_g_mag)


class ProperMotionRequest(BaseModel):
    source_id: str | int
    ra: float = Field(..., ge=0, lt=360)
    dec: float = Field(..., ge=-90, le=90)
    pmra: float | None = None
    pmdec: float | None = None
    parallax: float | None = None
    radial_velocity: float | None = None
    ref_epoch: float = 2016.0
    target_epoch_year: float = Field(2026.0, ge=1900.0, le=2100.0)
    ra_error_mas: float | None = None
    dec_error_mas: float | None = None
    pmra_error: float | None = None
    pmdec_error: float | None = None


@app.post("/api/gaia/propagate")
def api_gaia_propagate(body: ProperMotionRequest) -> dict[str, Any]:
    try:
        return propagate_gaia_proper_motion(**body.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


# --- ZTF DR24 & Reference Catalogues ---

@app.get("/api/ztf/images")
def api_ztf_images(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcmin: float = Query(3.0, gt=0, le=30),
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, Any]:
    return search_ztf_images(ra=ra, dec=dec, radius_arcmin=radius_arcmin, limit=limit)


@app.get("/api/ztf/lightcurve")
def api_ztf_lightcurve(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcsec: float = Query(3.0, gt=0.1, le=30),
) -> dict[str, Any]:
    return query_ztf_dr24_lightcurve(ra=ra, dec=dec, radius_arcsec=radius_arcsec)


@app.get("/api/reference/panstarrs")
def api_panstarrs(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcmin: float = Query(1.0, gt=0, le=15),
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, Any]:
    return query_panstarrs_dr2(ra=ra, dec=dec, radius_arcmin=radius_arcmin, limit=limit)


@app.get("/api/reference/twomass")
def api_twomass(
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    radius_arcmin: float = Query(2.0, gt=0, le=15),
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, Any]:
    return query_twomass_psc(ra=ra, dec=dec, radius_arcmin=radius_arcmin, limit=limit)


# --- WCS Coordinate Conversion ---

@app.get("/api/coordinates/pixel-to-world")
def api_pixel_to_world(
    access_url: str = Query(..., min_length=20),
    mission: str = Query("spherex", pattern="^(spherex|wise)$"),
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
    pixel_x: float = Query(..., ge=0),
    pixel_y: float = Query(..., ge=0),
    ext_name: str = Query("IMAGE"),
) -> dict[str, Any]:
    raw = (
        fetch_spherex_cutout_bytes(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
        if mission == "spherex"
        else fetch_wise_fits_bytes(access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    )
    try:
        return pixel_to_world_from_bytes(raw, pixel_x, pixel_y, ext_name=ext_name)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/coordinates/world-to-pixel")
def api_world_to_pixel(
    access_url: str = Query(..., min_length=20),
    mission: str = Query("spherex", pattern="^(spherex|wise)$"),
    ra_center: float = Query(..., ge=0, lt=360),
    dec_center: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=120),
    target_ra: float = Query(..., ge=0, lt=360),
    target_dec: float = Query(..., ge=-90, le=90),
    ext_name: str = Query("IMAGE"),
) -> dict[str, Any]:
    raw = (
        fetch_spherex_cutout_bytes(access_url=access_url, ra=ra_center, dec=dec_center, fov_arcmin=fov_arcmin)
        if mission == "spherex"
        else fetch_wise_fits_bytes(access_url, ra=ra_center, dec=dec_center, fov_arcmin=fov_arcmin)
    )
    return world_to_pixel_from_bytes(raw, target_ra, target_dec, ext_name=ext_name)


# --- Scientific Image Comparison & Difference Imaging ---

class CompareRequest(BaseModel):
    access_url_a: str
    access_url_b: str
    mission_a: str = "spherex"
    mission_b: str = "spherex"
    ra: float = Field(..., ge=0, lt=360)
    dec: float = Field(..., ge=-90, le=90)
    fov_arcmin: float = Field(6.0, gt=0, le=60)
    meta_a: dict[str, Any] = Field(default_factory=dict)
    meta_b: dict[str, Any] = Field(default_factory=dict)
    match_background: bool = True


def _fetch_compare_pair(body: CompareRequest) -> tuple[bytes, bytes]:
    bytes_a = (
        fetch_spherex_cutout_bytes(access_url=body.access_url_a, ra=body.ra, dec=body.dec, fov_arcmin=body.fov_arcmin)
        if body.mission_a == "spherex"
        else fetch_wise_fits_bytes(body.access_url_a, ra=body.ra, dec=body.dec, fov_arcmin=body.fov_arcmin)
    )
    bytes_b = (
        fetch_spherex_cutout_bytes(access_url=body.access_url_b, ra=body.ra, dec=body.dec, fov_arcmin=body.fov_arcmin)
        if body.mission_b == "spherex"
        else fetch_wise_fits_bytes(body.access_url_b, ra=body.ra, dec=body.dec, fov_arcmin=body.fov_arcmin)
    )
    return bytes_a, bytes_b


@app.post("/api/compare/difference")
def api_compare_difference(body: CompareRequest) -> dict[str, Any]:
    bytes_a, bytes_b = _fetch_compare_pair(body)
    try:
        res = compute_difference_analysis(
            bytes_a,
            bytes_b,
            meta_a=body.meta_a,
            meta_b=body.meta_b,
            match_background=body.match_background,
        )
        res.pop("_diff_array", None)
        res.pop("_header", None)
        res.pop("_total_var", None)
        return res
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/compare/difference.fits")
def api_compare_difference_fits(body: CompareRequest) -> Response:
    bytes_a, bytes_b = _fetch_compare_pair(body)
    res = compute_difference_analysis(
        bytes_a,
        bytes_b,
        meta_a=body.meta_a,
        meta_b=body.meta_b,
        match_background=body.match_background,
    )
    fits_data = export_difference_fits(res)
    return Response(
        content=fits_data,
        media_type="application/fits",
        headers={"Content-Disposition": 'attachment; filename="spherex_difference_wcs.fits"'},
    )


# --- Source Detection & Moving-Object Candidates ---

@app.get("/api/sources/detect")
def api_detect_sources(
    access_url: str = Query(..., min_length=20),
    mission: str = Query("spherex", pattern="^(spherex|wise)$"),
    obs_id: str = Query("observation"),
    obs_mjd: float | None = Query(None),
    ra: float = Query(..., ge=0, lt=360),
    dec: float = Query(..., ge=-90, le=90),
    fov_arcmin: float = Query(6.0, gt=0, le=60),
    sigma_threshold: float = Query(5.0, ge=2.5, le=20.0),
) -> dict[str, Any]:
    raw = (
        fetch_spherex_cutout_bytes(access_url=access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
        if mission == "spherex"
        else fetch_wise_fits_bytes(access_url, ra=ra, dec=dec, fov_arcmin=fov_arcmin)
    )
    return detect_sources_in_fits(raw, obs_id=obs_id, obs_mjd=obs_mjd, sigma_threshold=sigma_threshold)


class MovingCandidateRequest(BaseModel):
    ra_center: float = Field(..., ge=0, lt=360)
    dec_center: float = Field(..., ge=-90, le=90)
    observations: list[dict[str, Any]]
    fov_arcmin: float = 6.0
    search_radius_arcsec: float = 15.0
    sigma_threshold: float = 5.0


@app.post("/api/moving-objects/candidates")
def api_moving_candidates(body: MovingCandidateRequest) -> dict[str, Any]:
    epoch_detections: list[dict[str, Any]] = []
    for obs in body.observations[:8]:
        url = obs.get("access_url")
        if not url:
            continue
        mission = "wise" if "wise" in str(obs.get("mission", "")).lower() else "spherex"
        raw = (
            fetch_spherex_cutout_bytes(access_url=url, ra=body.ra_center, dec=body.dec_center, fov_arcmin=body.fov_arcmin)
            if mission == "spherex"
            else fetch_wise_fits_bytes(url, ra=body.ra_center, dec=body.dec_center, fov_arcmin=body.fov_arcmin)
        )
        det = detect_sources_in_fits(
            raw,
            obs_id=str(obs.get("id", "obs")),
            obs_mjd=obs.get("start_mjd"),
            sigma_threshold=body.sigma_threshold,
        )
        epoch_detections.append(det)

    return analyze_moving_object_candidates(
        epoch_detections=epoch_detections,
        ra_center=body.ra_center,
        dec_center=body.dec_center,
        search_radius_arcsec=body.search_radius_arcsec,
    )


# --- JPL Horizons & Minor Planet Center ---

@app.get("/api/horizons/ephemeris")
def api_horizons_ephemeris(
    command: str = Query(..., min_length=1, max_length=80),
    start_time: str = Query(...),
    stop_time: str = Query(...),
    step_size: str = Query("1 d"),
    center: str = Query("500@399"),
) -> dict[str, Any]:
    return query_horizons_ephemeris(
        command=command,
        start_time=start_time,
        stop_time=stop_time,
        step_size=step_size,
        center=center,
    )


@app.get("/api/mpc/observations")
def api_mpc_observations(
    designation: str = Query(..., min_length=1, max_length=60),
    limit: int = Query(100, ge=1, le=500),
) -> dict[str, Any]:
    return query_mpc_observations(designation, limit=limit)


@app.get("/api/mpc/orbit")
def api_mpc_orbit(designation: str = Query(..., min_length=1, max_length=60)) -> dict[str, Any]:
    return query_mpc_orbit(designation)


# --- IRSA HiPS Sky Viewer Proxy ---

@app.get("/api/hips/surveys")
def api_hips_surveys() -> dict[str, Any]:
    return {"surveys": [{"id": k, **v} for k, v in HIPS_SURVEYS.items()]}


@app.get("/api/hips/{survey_id}/tile")
def api_hips_tile(
    survey_id: str,
    order: int = Query(..., ge=0, le=10),
    npix: int = Query(..., ge=0),
    frame: int | None = Query(None, ge=0, le=101),
) -> Response:
    data, media_type = fetch_hips_tile(survey_id, order, npix, frame=frame)
    return Response(
        content=data,
        media_type=media_type,
        headers={"Cache-Control": "public, max-age=86400"},
    )
