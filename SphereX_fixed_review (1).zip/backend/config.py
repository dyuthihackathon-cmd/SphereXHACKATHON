"""Centralized official dataset registry and runtime settings for SphereX."""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CACHE_DIR = Path(os.getenv("SPHEREX_CACHE_DIR", str(BASE_DIR / ".cache"))).resolve()
CACHE_DIR.mkdir(parents=True, exist_ok=True)

ARCHIVE_TIMEOUT_SEC = float(os.getenv("SPHEREX_ARCHIVE_TIMEOUT_SEC", "45"))
MAX_DOWNLOAD_BYTES = int(float(os.getenv("SPHEREX_MAX_DOWNLOAD_MB", "350")) * 1024 * 1024)

# Official Dataset Registry — all external endpoints live here rather than in frontend components.
DATASET_REGISTRY = {
    "spherex": {
        "provider": "NASA/IPAC Infrared Science Archive (IRSA)",
        "mission": "NASA SPHEREx",
        "docs_url": "https://irsa.ipac.caltech.edu/spherex-archive-documentation/",
        "sia_url": "https://irsa.ipac.caltech.edu/SIA",
        "tap_url": "https://irsa.ipac.caltech.edu/TAP/sync",
        "ibe_cutout_prefix": "https://irsa.ipac.caltech.edu/ibe/data/spherex/",
        "s3_bucket_url": "https://nasa-irsa-spherex.s3.amazonaws.com",
        "hips_cube_url": "https://irsa.ipac.caltech.edu/data/hips/SPHEREx/spherex_allsky_cube",
        "s3_cube_prefix": "dr1/hips5_cube/hips_20261026",
        "s3_spectral_channels_key": "dr1/spectral_channels/cal-sch-v2-2026-229/spectral_channels_spx_cal-sch-v2-2026-229.fits",
        "s3_spectral_wcs_prefix": "dr1/spectral_wcs/cal-swcs-v5-2026-191",
        "collections": {
            "dr1": "spherex_dr1",
            "qr3": "spherex_qr3",
            "dr1_deep": "spherex_dr1_deep",
            "qr3_deep": "spherex_qr3_deep",
            "dr1_cube": "spherex_dr1_cube",
        },
        "blank_channels_1based": [51, 52],
    },
    "wise": {
        "provider": "NASA/IPAC Infrared Science Archive (IRSA)",
        "mission": "NASA WISE / NEOWISE-R",
        "docs_url": "https://irsa.ipac.caltech.edu/Missions/wise.html",
        "sia_url": "https://irsa.ipac.caltech.edu/SIA",
        "tap_url": "https://irsa.ipac.caltech.edu/TAP/sync",
        "s3_bucket_url": "https://nasa-irsa-wise.s3.us-west-2.amazonaws.com",
        "s3_allwise_images": "wise/allwise/images/p3am_cdd",
        "s3_allwise_catalog": "wise/allwise/catalogs/p3as_psd/healpix_k5/wise-allwise.parquet",
        "s3_allsky_images": "wise/allsky/images/4band_p1bm_frm",
        "s3_cryo3band_images": "wise/cryo-3band/images/3band_p1bm_frm",
        "s3_postcryo_images": "wise/postcryo/images/2band_p1bm_frm",
        "s3_neowiser_images": "wise/neowiser/images/p1bm_frm",
        "s3_neowiser_catalog": "wise/neowiser/catalogs/p1bs_psd/healpix_k5",
        "neowiser_partitions": [
            "year1", "year2", "year3", "year4", "year5", "year6",
            "year7", "year8", "year9", "year10", "year11", "addendum",
        ],
        "s3_unwise_catalog": "unwise/neo7/catalogs/time_domain/healpix_k5",
        "hips": {
            "allwise_rgb": "https://irsa.ipac.caltech.edu/data/hips/CDS/AllWISE/RGB-W4-W2-W1",
            "allwise_w1": "https://irsa.ipac.caltech.edu/data/hips/CDS/AllWISE/W1",
            "allwise_w2": "https://irsa.ipac.caltech.edu/data/hips/CDS/AllWISE/W2",
        },
    },
    "gaia": {
        "provider": "European Space Agency (ESA) Gaia Archive",
        "mission": "ESA Gaia DR3",
        "docs_url": "https://gea.esac.esa.int/archive/documentation/GDR3/",
        "tap_primary": "https://gea.esac.esa.int/tap-server/tap/sync",
        "tap_mirrors": [
            "https://gaia.ari.uni-heidelberg.de/tap/sync",
        ],
        "table_source": "gaiadr3.gaia_source",
        "table_vari_summary": "gaiadr3.vari_summary",
        "ref_epoch": 2016.0,
    },
    "ztf": {
        "provider": "Caltech/IPAC-IRSA Zwicky Transient Facility (ZTF)",
        "mission": "ZTF Public DR24",
        "docs_url": "https://irsa.ipac.caltech.edu/data/ZTF/docs/",
        "sia_url": "https://irsa.ipac.caltech.edu/ibe/search/ztf/products/sci",
        "tap_url": "https://irsa.ipac.caltech.edu/TAP/sync",
        "s3_bucket_url": "https://ipac-irsa-ztf.s3.us-east-1.amazonaws.com",
        "s3_dr24_objects_prefix": "ztf/enhanced/dr24/objects/hats/ztf_dr24_objects-hats/dataset",
        "s3_dr24_lc_prefix": "ztf/enhanced/dr24/lc/hats/ztf_dr24_lc-hats/dataset",
    },
    "horizons": {
        "provider": "NASA JPL Solar System Dynamics",
        "mission": "JPL Horizons Ephemeris System",
        "docs_url": "https://ssd-api.jpl.nasa.gov/doc/horizons.html",
        "api_url": "https://ssd.jpl.nasa.gov/api/horizons.api",
    },
    "mpc": {
        "provider": "IAU Minor Planet Center (MPC)",
        "mission": "Minor Planet Center",
        "docs_url": "https://docs.minorplanetcenter.net/mpc-ops-docs/",
        "obs_url": "https://data.minorplanetcenter.net/api/get-obs",
        "orb_url": "https://data.minorplanetcenter.net/api/get-orb",
    },
    "reference": {
        "simbad_tap": "https://simbad.cds.unistra.fr/simbad/sim-tap/sync",
        "simbad_sesame": "https://cdsweb.u-strasbg.fr/cgi-bin/nph-sesame/-oxp/SNV",
        "ned_lookup": "https://ned.ipac.caltech.edu/srs/ObjectLookup",
        "panstarrs_dr2": "https://catalogs.mast.stsci.edu/api/v0.1/panstarrs/dr2/mean.json",
        "twomass_tap": "https://irsa.ipac.caltech.edu/TAP/sync",
        "hips": {
            "2mass_color": "https://irsa.ipac.caltech.edu/data/hips/CDS/2MASS/Color",
            "dss2_color": "https://irsa.ipac.caltech.edu/data/hips/CDS/DSS2/color",
            "sdss9_color": "https://irsa.ipac.caltech.edu/data/hips/CDS/SDSS/DR9/color",
        },
    },
}

CHALLENGE_TARGETS = {
    "WISE 0855": {
        "resolved_name": "WISE J085510.83-071442.5",
        "ra": 133.79512917,
        "dec": -7.24514722,
        "coordinate_system": "ICRS",
        "source": "Official Challenge Specification (08h55m10.83s -07d14m42.5s)",
        "notes": "Coldest known brown dwarf (~250 K); high proper motion (~8.1 arcsec/yr).",
    },
}
