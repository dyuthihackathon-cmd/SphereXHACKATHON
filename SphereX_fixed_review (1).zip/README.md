# SphereX — Multi-Wavelength Time-Domain Astronomy Explorer

SphereX is a scientific web application for exploring calibrated multi-wavelength astronomical archives across the sky using **real external observatory data**. Every coordinate transformation, spectral extraction, image subtraction, proper-motion track, and photometric light curve uses genuine astronomical services (NASA/IPAC IRSA, AWS Open Data S3 cubes/Parquet catalogs, ESA/ARI Gaia DR3, ZTF DR24, NASA JPL Horizons, and the IAU Minor Planet Center) with explicit provenance metadata and honest uncertainty handling.

---

## Core Scientific Capabilities

1. **Sky Explorer (TAN Projection & IRSA HiPS)**:
   - Interactive all-sky HiPS tile viewer (`AllWISE Color`, `AllWISE W1/W2`, `SPHEREx DR1 All-Sky HiPS`, `2MASS JHK`, `DSS2`, `SDSS DR9`) backed by verified Górski HEALPix NESTED geometry and Gnomonic TAN graticule + Galactic plane overlays.
   - True server-side WCS cutout overlays with interactive click-to-sky coordinate readout (`/api/coordinates/pixel-to-world`), FITS extension selection (`IMAGE`, `VARIANCE`, `FLAGS`, `ZODI`), percentile/ZScale stretches, and colormaps.
2. **Observations Explorer**:
   - Coordinate + FOV queries across NASA SPHEREx (`spherex_dr1`, `spherex_qr3`, `spherex_deep`), WISE/AllWISE/NEOWISE-R SIA, and ZTF DR24 coverage.
   - Multi-extension FITS quality inspection (missing pixel fraction, flagged pixels, `VARIANCE`/`ZODI` availability, median SNR) and calibrated FITS cutout export.
3. **Spectral Explorer (SPHEREx DR1 102-Channel All-Sky Cube)**:
   - Resolves sky coordinates to HEALPix order-5 (`NSIDE=32`, NESTED) DR1 cube tiles on AWS S3 / IRSA HiPS (`Norder5/Dir*/Npix*_cube.fits`) via HTTP Range requests (downloading only the target spatial column or 2D channel slice rather than full ~320 MB cubes).
   - Explicitly flags intentional blank dichroic channels **51 & 52** (`D3:17` / `D4:01`), extracts `NHITS` exposure depth and `FLAGS` quality bitmasks, and reports missing `VARIANCE` honestly rather than fabricating error bars.
4. **Time Domain**:
   - Multi-epoch image sequence playback & blink comparator.
   - **NEOWISE-R Single-Exposure** W1/W2 S3 Parquet light curves (`year1`–`year11`) with explicit target-association separation filtering (`2.5"` default), quality/flag rejection list (`qual_frame`, `cc_flags`, `moon_masked`, `saa_sep`), and CSV/JSON provenance export.
   - **ZTF Public DR24** HATS Parquet light curves (`zg`, `zr`, `zi`) streamed over S3 HTTP Range using `_healpix_29` row-group statistics pruning.
5. **Compare Images & WCS Difference Imaging**:
   - Visual modes: Side-by-Side, Split-Screen Swipe Slider, Epoch Blink.
   - Scientific pixel subtraction via `astropy` + `reproject.reproject_interp`, optional sigma-clipped background offset matching, strict variance propagation (`diff / sqrt(Var_A + Var_B)` computed only when both FITS files include valid `VARIANCE` extensions), and calibrated WCS difference FITS export.
6. **Sources & Multi-Epoch Astrometry**:
   - Live Gaia DR3 cone search (ESA primary with automatic ARI Heidelberg mirror fallback), Pan-STARRS DR2 optical PSF cross-match (`Dec > -30°`), and 2MASS PSC J/H/Ks NIR cross-match.
   - Relativistic/trig Astropy `SkyCoord.apply_space_motion` proper-motion propagation from J2016.0 to target epoch with covariance-propagated uncertainty estimates and missing-RV disclosure.
7. **Moving Objects, Ephemerides & Verification**:
   - Multi-epoch `photutils.detection.DAOStarFinder` candidate extraction and linear-motion tracklet linking restricted strictly to 6 honest scientific classifications (`Unverified candidate`, `Possible known-object match`, `No known-object match found`, `Insufficient observations`, `Likely artifact or unreliable detection`, `Requires human review`).
   - Live NASA JPL Horizons ICRF/J2000 observer ephemerides and IAU Minor Planet Center (`get-obs` ADES XML & `get-orb`) cross-verification.
8. **Research & Export**:
   - Session research ledger with full provenance capture, Markdown & JSON report exports, live archive connectivity probe (`/api/archive/status`), and upgraded project archive download (`/SphereX-upgraded.zip`).

---

## Quick Start on Windows (PowerShell)

### Prerequisites
- **Node.js** >= 20.19 or >= 22.12 (`node -v`; Node 22 LTS recommended)
- **Python** >= 3.11 (`python --version`)
- **Git** (optional)

### 1. Create Python Virtual Environment & Install Backend Dependencies

```powershell
cd path\to\SphereX
python -m venv backend\.venv
.\backend\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r backend\requirements.txt
```

### 2. Install Frontend Node Dependencies

```powershell
npm install
```

### 3. Run SphereX (Option A — Unified Single Command)

`server.ts` automatically spawns the Python FastAPI Uvicorn server on `127.0.0.1:8000` (using `backend\.venv\Scripts\python.exe` if present), mounts the `/api` reverse proxy, and serves Vite on port `3000`:

```powershell
npm run dev
```
Open: `http://localhost:3000`

### 4. Run SphereX (Option B — Dual Terminal Development Mode)

**Terminal 1 (FastAPI Scientific Backend on port 8000):**
```powershell
.\backend\.venv\Scripts\Activate.ps1
cd backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

**Terminal 2 (Vite frontend on port 5173):**
```powershell
npm run dev:vite
```
The Vite development server proxies `/api` requests to `http://127.0.0.1:8000`. Keep both terminals running. Open `http://localhost:5173`.

### 5. Run Automated Verification Suites (PowerShell / Bash)

```powershell
# TypeScript type-check & production Vite build
npm run lint
npm run build

# Frontend math, HEALPix, WCS, CSV & time unit tests (12 tests)
npm test

# Backend scientific validation and HTTP archive-safety tests (13 tests)
.\backend\.venv\Scripts\python.exe -m pytest -v backend\tests
```

---

## Project Architecture

```text
SphereX/
├── server.ts                       # Node Express server + FastAPI child process + /api reverse proxy (port 3000)
├── src/
│   ├── App.tsx                     # Root workspace orchestrator across all 8 modules & keyboard shortcuts
│   ├── services/spherexApi.ts      # Typed FastAPI client with AbortSignal support
│   ├── types/index.ts              # Strict TypeScript interfaces for observations, spectra, Gaia, NEOWISE, QC
│   ├── utils/
│   │   ├── coordinates.ts          # Gnomonic TAN projection, ICRS<->Galactic, separation, HMS/DMS parsers
│   │   ├── healpix.ts              # Górski HEALPix NESTED pixel & tile locator for IRSA HiPS canvas
│   │   ├── timeControls.ts         # Strict ISO-8601 UTC, JD, and MJD conversions
│   │   ├── spherexData.ts          # Layer metadata, HiPS survey options, benchmark targets
│   │   ├── exportHelpers.ts        # RFC-4180 CSV builder with formula neutralization & provenance header
│   │   └── *.test.ts               # Node unit test suite
│   └── components/
│       ├── IntroAnimation.tsx
│       ├── TopNavigation.tsx
│       ├── SkyViewer.tsx
│       ├── BottomToolbar.tsx
│       ├── LayersPanel.tsx
│       ├── SearchPanel.tsx
│       ├── CoordinateInspector.tsx
│       ├── QualityControlPanel.tsx
│       ├── InfraredAdjustmentPanel.tsx
│       ├── ObservationsExplorer.tsx
│       ├── SpectralExplorer.tsx
│       ├── TimeDomainWorkspace.tsx
│       ├── CompareWorkspace.tsx
│       ├── SourcesWorkspace.tsx
│       ├── MovingObjectsWorkspace.tsx
│       └── ResearchExportWorkspace.tsx
├── backend/
│   ├── main.py                     # FastAPI REST endpoints & CORS / error handlers
│   ├── config.py                   # Official dataset registry (URLs, S3 buckets, collections)
│   ├── requirements.txt            # FastAPI, astropy, reproject, photutils, pyarrow, scipy, astropy-healpix
│   ├── services/                   # Modular scientific services (cube, SIA, WISE, NEOWISE, Gaia, ZTF, Horizons, MPC, WCS, difference)
│   └── tests/                      # Pytest scientific validation suite
└── docs/
    ├── DATA_GUIDE.md
    ├── API.md
    ├── SCIENTIFIC_METHODOLOGY.md
    └── TEST_AND_VERIFICATION_REPORT.md
```
