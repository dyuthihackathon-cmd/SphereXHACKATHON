import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, type ChildProcess } from 'node:child_process';
import fs from 'node:fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const BACKEND_PORT = Number(process.env.SPHEREX_BACKEND_PORT || 8000);
const BACKEND_HOST = '127.0.0.1';
const isProd = process.env.NODE_ENV === 'production' || process.argv.includes('--production');

let backendProcess: ChildProcess | null = null;

function resolvePythonBin(): string {
  if (process.env.SPHEREX_PYTHON_BIN) return process.env.SPHEREX_PYTHON_BIN;
  const venvWin = path.join(__dirname, 'backend', '.venv', 'Scripts', 'python.exe');
  if (fs.existsSync(venvWin)) return venvWin;
  const venvPosix = path.join(__dirname, 'backend', '.venv', 'bin', 'python');
  if (fs.existsSync(venvPosix)) return venvPosix;
  const venvWinLegacy = path.join(__dirname, 'backend', 'venv', 'Scripts', 'python.exe');
  if (fs.existsSync(venvWinLegacy)) return venvWinLegacy;
  const venvPosixLegacy = path.join(__dirname, 'backend', 'venv', 'bin', 'python');
  if (fs.existsSync(venvPosixLegacy)) return venvPosixLegacy;
  return process.platform === 'win32' ? 'python' : 'python3';
}

function isBackendHealthy(): Promise<boolean> {
  return new Promise((resolve) => {
    const req = http.get(
      { host: BACKEND_HOST, port: BACKEND_PORT, path: '/api/health', timeout: 1500 },
      (res) => {
        res.resume();
        resolve(res.statusCode === 200);
      },
    );
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function ensurePythonBackend(): Promise<void> {
  if (await isBackendHealthy()) {
    console.log(`[SphereX] FastAPI backend already running on http://${BACKEND_HOST}:${BACKEND_PORT}`);
    return;
  }

  const pythonBin = resolvePythonBin();
  const backendDir = path.join(__dirname, 'backend');
  console.log(`[SphereX] Starting Python FastAPI backend (${pythonBin}) on port ${BACKEND_PORT}...`);

  backendProcess = spawn(
    pythonBin,
    ['-m', 'uvicorn', 'main:app', '--host', BACKEND_HOST, '--port', String(BACKEND_PORT)],
    {
      cwd: backendDir,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env },
    },
  );

  backendProcess.stdout?.on('data', (chunk) => {
    process.stdout.write(`[FastAPI] ${chunk}`);
  });
  backendProcess.stderr?.on('data', (chunk) => {
    process.stderr.write(`[FastAPI] ${chunk}`);
  });
  backendProcess.on('exit', (code) => {
    console.warn(`[SphereX] FastAPI backend exited with code ${code}`);
    backendProcess = null;
  });

  // Wait briefly for uvicorn readiness without blocking indefinitely.
  for (let i = 0; i < 30; i += 1) {
    if (await isBackendHealthy()) {
      console.log(`[SphereX] FastAPI backend ready on http://${BACKEND_HOST}:${BACKEND_PORT}`);
      return;
    }
    await new Promise((r) => setTimeout(r, 300));
  }
  console.warn('[SphereX] FastAPI backend did not respond within 9s; /api requests will retry on demand.');
}

async function startServer() {
  await ensurePythonBackend();

  const app = express();

  // Reverse proxy all /api requests directly to FastAPI preserving method, headers, query, and streaming body.
  app.use('/api', (req, res) => {
    const targetPath = `/api${req.url}`;
    const proxyReq = http.request(
      {
        host: BACKEND_HOST,
        port: BACKEND_PORT,
        path: targetPath,
        method: req.method,
        headers: {
          ...req.headers,
          host: `${BACKEND_HOST}:${BACKEND_PORT}`,
        },
        timeout: 120000,
      },
      (proxyRes) => {
        res.status(proxyRes.statusCode || 502);
        for (const [key, value] of Object.entries(proxyRes.headers)) {
          if (value !== undefined) res.setHeader(key, value);
        }
        proxyRes.pipe(res);
      },
    );

    proxyReq.on('error', (err) => {
      if (!res.headersSent) {
        res.status(503).json({
          status: 'provider_unavailable',
          detail: `Python FastAPI archive bridge unavailable (${err.message}). Ensure backend dependencies are installed.`,
        });
      }
    });

    req.pipe(proxyReq);
  });

  if (isProd) {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.use(express.static(path.join(__dirname, 'public')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SphereX] Application listening on http://0.0.0.0:${PORT}`);
  });

  const shutdown = () => {
    server.close();
    if (backendProcess && !backendProcess.killed) {
      backendProcess.kill('SIGTERM');
    }
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

startServer().catch((err) => {
  console.error('[SphereX] Server startup error:', err);
  process.exit(1);
});
