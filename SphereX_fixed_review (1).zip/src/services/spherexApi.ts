import {
  ArchiveObservation,
  CubeSpectrumResponse,
  FitsQualityInspection,
  GaiaSourceRecord,
  MovingObjectCandidate,
  NeowisePoint,
  ProperMotionResult,
  ProvenanceRecord,
} from '../types';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(body.detail || body.message || `Archive API error (${response.status})`);
  }
  return body as T;
}

export interface ArchiveStatusResponse {
  status: string;
  providers: Record<string, { reachable: boolean; http_status?: number; error?: string }>;
}

export async function getArchiveStatus(signal?: AbortSignal): Promise<ArchiveStatusResponse> {
  return requestJson<ArchiveStatusResponse>(`${API_BASE}/api/archive/status`, { signal });
}

export async function resolveAstronomicalTarget(
  name: string,
  signal?: AbortSignal,
): Promise<{ query: string; resolved_name: string; ra: number; dec: number; coordinate_system: string; source: string; notes?: string }> {
  const params = new URLSearchParams({ name });
  return requestJson(`${API_BASE}/api/resolve-target?${params}`, { signal });
}

export interface ObservationSearchResponse {
  status: string;
  query: { ra: number; dec: number; fov_arcmin: number; release: string; include_deep: boolean };
  count: number;
  total_matched: number;
  observations: ArchiveObservation[];
  collections_queried: string[];
  collections_succeeded: string[];
  errors: string[];
  archive_note: string;
}

export async function searchSpherexObservations(
  args: {
    ra: number;
    dec: number;
    fovArcmin: number;
    release: 'dr1' | 'qr3' | 'both';
    includeDeep: boolean;
    startDate?: string;
    endDate?: string;
    limit?: number;
  },
  signal?: AbortSignal,
): Promise<ObservationSearchResponse> {
  const params = new URLSearchParams({
    ra: String(args.ra),
    dec: String(args.dec),
    fov_arcmin: String(args.fovArcmin),
    release: args.release,
    include_deep: String(args.includeDeep),
    limit: String(args.limit ?? 100),
  });
  if (args.startDate) params.set('start_date', args.startDate);
  if (args.endDate) params.set('end_date', args.endDate);
  return requestJson(`${API_BASE}/api/observations?${params}`, { signal });
}

export function getObservationPreviewUrl(
  observation: Pick<ArchiveObservation, 'access_url' | 'mission' | 'id'>,
  ra: number,
  dec: number,
  fovArcmin: number,
  opts?: { stretch?: string; palette?: string; extName?: string },
): string {
  const isWise = (observation.mission || '').toLowerCase().includes('wise');
  const params = new URLSearchParams({
    access_url: observation.access_url,
    ra: String(ra),
    dec: String(dec),
    fov_arcmin: String(fovArcmin),
    stretch: opts?.stretch ?? 'asinh',
    palette: opts?.palette ?? 'monochrome',
  });
  if (!isWise && opts?.extName) {
    params.set('ext_name', opts.extName);
  }
  return `${API_BASE}${isWise ? '/api/wise/preview' : '/api/observations/preview'}?${params}`;
}

export function getObservationFitsUrl(
  observation: Pick<ArchiveObservation, 'access_url' | 'mission'>,
  ra: number,
  dec: number,
  fovArcmin: number,
): string {
  const isWise = (observation.mission || '').toLowerCase().includes('wise');
  const params = new URLSearchParams({
    access_url: observation.access_url,
    ra: String(ra),
    dec: String(dec),
    fov_arcmin: String(fovArcmin),
  });
  return `${API_BASE}${isWise ? '/api/wise/fits' : '/api/observations/fits'}?${params}`;
}

export async function inspectObservationFits(
  observation: Pick<ArchiveObservation, 'access_url' | 'mission'>,
  ra: number,
  dec: number,
  fovArcmin: number,
  extName = 'IMAGE',
  signal?: AbortSignal,
): Promise<FitsQualityInspection & { provenance?: ProvenanceRecord }> {
  const isWise = (observation.mission || '').toLowerCase().includes('wise');
  const params = new URLSearchParams({
    access_url: observation.access_url,
    ra: String(ra),
    dec: String(dec),
    fov_arcmin: String(fovArcmin),
  });
  if (!isWise) params.set('ext_name', extName);
  return requestJson(`${API_BASE}${isWise ? '/api/wise/inspect' : '/api/observations/inspect'}?${params}`, { signal });
}

export async function pixelToWorld(
  args: {
    access_url: string;
    mission: 'spherex' | 'wise';
    ra: number;
    dec: number;
    fov_arcmin: number;
    pixel_x: number;
    pixel_y: number;
    ext_name?: string;
  },
  signal?: AbortSignal,
): Promise<{
  ra: number;
  dec: number;
  pixel_x: number;
  pixel_y: number;
  pixel_value: number | null;
  bunit: string;
  ctype: string[];
}> {
  const params = new URLSearchParams({
    access_url: args.access_url,
    mission: args.mission,
    ra: String(args.ra),
    dec: String(args.dec),
    fov_arcmin: String(args.fov_arcmin),
    pixel_x: String(args.pixel_x),
    pixel_y: String(args.pixel_y),
    ext_name: args.ext_name ?? 'IMAGE',
  });
  return requestJson(`${API_BASE}/api/coordinates/pixel-to-world?${params}`, { signal });
}

// --- SPHEREx 102-Channel Spectral Cube ---

export async function fetchCubeTileInfo(ra: number, dec: number, signal?: AbortSignal) {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec) });
  return requestJson<any>(`${API_BASE}/api/spherex/cube/search?${params}`, { signal });
}

export async function fetchCubeSpectrum(
  args: { ra: number; dec: number; apertureRadiusPx?: number; maskFlagged?: boolean },
  signal?: AbortSignal,
): Promise<CubeSpectrumResponse> {
  const params = new URLSearchParams({
    ra: String(args.ra),
    dec: String(args.dec),
    aperture_radius_px: String(args.apertureRadiusPx ?? 0),
    mask_flagged: String(args.maskFlagged ?? true),
  });
  return requestJson<CubeSpectrumResponse>(`${API_BASE}/api/spherex/cube/spectrum?${params}`, { signal });
}

export function getCubeSlicePngUrl(
  ra: number,
  dec: number,
  channel: number,
  stretch = 'asinh',
  palette = 'spherex_ir',
): string {
  const params = new URLSearchParams({
    ra: String(ra),
    dec: String(dec),
    channel: String(channel),
    stretch,
    palette,
  });
  return `${API_BASE}/api/spherex/cube/slice.png?${params}`;
}

export function getCubeSliceFitsUrl(ra: number, dec: number, channel: number): string {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec), channel: String(channel) });
  return `${API_BASE}/api/spherex/cube/slice.fits?${params}`;
}

// --- WISE / NEOWISE-R ---

export async function searchWiseImages(
  args: { ra: number; dec: number; radiusArcmin?: number; collection: string; limit?: number },
  signal?: AbortSignal,
): Promise<{ status: string; count: number; products: ArchiveObservation[]; archive_note: string }> {
  const params = new URLSearchParams({
    ra: String(args.ra),
    dec: String(args.dec),
    radius_arcmin: String(args.radiusArcmin ?? 3),
    collection: args.collection,
    limit: String(args.limit ?? 50),
  });
  return requestJson(`${API_BASE}/api/wise/images?${params}`, { signal });
}

export async function fetchNeowiseLightcurve(
  args: { ra: number; dec: number; radiusArcsec?: number; associationRadiusArcsec?: number; partitions?: string },
  signal?: AbortSignal,
): Promise<{
  status: string;
  query: Record<string, unknown>;
  total_detections: number;
  accepted_count: number;
  rejected_count: number;
  accepted: NeowisePoint[];
  rejected: NeowisePoint[];
  errors: string[];
  association_note: string;
  provenance: ProvenanceRecord;
}> {
  const params = new URLSearchParams({
    ra: String(args.ra),
    dec: String(args.dec),
    radius_arcsec: String(args.radiusArcsec ?? 5),
    association_radius_arcsec: String(args.associationRadiusArcsec ?? 2.5),
  });
  if (args.partitions) params.set('partitions', args.partitions);
  return requestJson(`${API_BASE}/api/neowise/lightcurve?${params}`, { signal });
}

// --- Gaia DR3 & Proper Motion ---

export async function searchGaiaSources(
  args: { ra: number; dec: number; radiusArcmin?: number; limit?: number; maxGMag?: number },
  signal?: AbortSignal,
): Promise<{
  status: string;
  count: number;
  sources: GaiaSourceRecord[];
  tap_endpoint_used: string;
  ref_epoch: number;
  archive_note: string;
  provenance: ProvenanceRecord;
}> {
  const params = new URLSearchParams({
    ra: String(args.ra),
    dec: String(args.dec),
    radius_arcmin: String(args.radiusArcmin ?? 3),
    limit: String(args.limit ?? 100),
  });
  if (args.maxGMag !== undefined) params.set('max_g_mag', String(args.maxGMag));
  return requestJson(`${API_BASE}/api/gaia/sources?${params}`, { signal });
}

export async function propagateProperMotion(
  payload: {
    source_id: string | number;
    ra: number;
    dec: number;
    pmra?: number | null;
    pmdec?: number | null;
    parallax?: number | null;
    radial_velocity?: number | null;
    ref_epoch?: number;
    target_epoch_year: number;
    ra_error_mas?: number | null;
    dec_error_mas?: number | null;
    pmra_error?: number | null;
    pmdec_error?: number | null;
  },
  signal?: AbortSignal,
): Promise<ProperMotionResult> {
  return requestJson<ProperMotionResult>(`${API_BASE}/api/gaia/propagate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal,
  });
}

// --- ZTF & Reference Catalogues ---

export async function fetchZtfImages(ra: number, dec: number, radiusArcmin = 3, signal?: AbortSignal) {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec), radius_arcmin: String(radiusArcmin) });
  return requestJson<any>(`${API_BASE}/api/ztf/images?${params}`, { signal });
}

export async function fetchZtfLightcurve(ra: number, dec: number, radiusArcsec = 3, signal?: AbortSignal) {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec), radius_arcsec: String(radiusArcsec) });
  return requestJson<any>(`${API_BASE}/api/ztf/lightcurve?${params}`, { signal });
}

export async function fetchPanstarrs(ra: number, dec: number, radiusArcmin = 1, signal?: AbortSignal) {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec), radius_arcmin: String(radiusArcmin) });
  return requestJson<any>(`${API_BASE}/api/reference/panstarrs?${params}`, { signal });
}

export async function fetchTwomass(ra: number, dec: number, radiusArcmin = 2, signal?: AbortSignal) {
  const params = new URLSearchParams({ ra: String(ra), dec: String(dec), radius_arcmin: String(radiusArcmin) });
  return requestJson<any>(`${API_BASE}/api/reference/twomass?${params}`, { signal });
}

// --- Image Comparison & Moving Objects ---

export async function runDifferenceAnalysis(
  payload: {
    access_url_a: string;
    access_url_b: string;
    mission_a: string;
    mission_b: string;
    ra: number;
    dec: number;
    fov_arcmin: number;
    meta_a: Record<string, unknown>;
    meta_b: Record<string, unknown>;
    match_background: boolean;
  },
  signal?: AbortSignal,
) {
  return requestJson<any>(`${API_BASE}/api/compare/difference`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal,
  });
}

export async function downloadDifferenceFits(payload: Record<string, unknown>): Promise<Blob> {
  const resp = await fetch(`${API_BASE}/api/compare/difference.fits`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.detail || 'Difference FITS export failed');
  }
  return resp.blob();
}

export async function analyzeMovingCandidates(
  payload: {
    ra_center: number;
    dec_center: number;
    observations: ArchiveObservation[];
    fov_arcmin: number;
    search_radius_arcsec: number;
    sigma_threshold: number;
  },
  signal?: AbortSignal,
): Promise<{
  status: string;
  gaia_note?: string;
  epochs_analyzed: number;
  candidate_count: number;
  candidates: MovingObjectCandidate[];
  provenance?: ProvenanceRecord;
}> {
  return requestJson(`${API_BASE}/api/moving-objects/candidates`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal,
  });
}

// --- JPL Horizons & MPC ---

export async function fetchHorizonsEphemeris(
  args: { command: string; startTime: string; stopTime: string; stepSize: string; center?: string },
  signal?: AbortSignal,
) {
  const params = new URLSearchParams({
    command: args.command,
    start_time: args.startTime,
    stop_time: args.stopTime,
    step_size: args.stepSize,
    center: args.center ?? '500@399',
  });
  return requestJson<any>(`${API_BASE}/api/horizons/ephemeris?${params}`, { signal });
}

export async function fetchMpcObservations(designation: string, limit = 100, signal?: AbortSignal) {
  const params = new URLSearchParams({ designation, limit: String(limit) });
  return requestJson<any>(`${API_BASE}/api/mpc/observations?${params}`, { signal });
}

export async function fetchMpcOrbit(designation: string, signal?: AbortSignal) {
  const params = new URLSearchParams({ designation });
  return requestJson<any>(`${API_BASE}/api/mpc/orbit?${params}`, { signal });
}
