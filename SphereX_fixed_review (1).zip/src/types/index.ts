export interface ProvenanceRecord {
  data_provider: string;
  mission_survey: string;
  data_release: string;
  archive_collection: string;
  source_or_obs_id: string;
  archive_url: string;
  observation_timestamp: string;
  ra: number | null;
  dec: number | null;
  instrument_detector: string;
  wavelength_or_filter: string;
  units: string;
  quality_flags: string;
  uncertainties: string;
  processing_version: string;
  retrieved_at_utc: string;
  spherex_processing: string;
}

export interface SkyCoordinate {
  ra: number; // Right ascension in degrees [0, 360)
  dec: number; // Declination in degrees [-90, 90]
  fov?: number; // Field of view in degrees
  isScientific?: boolean;
  pixelX?: number;
  pixelY?: number;
  coordinateSource?: 'WCS FITS Header' | 'TAN HiPS Sky Projection' | 'Manual Target Entry';
  surfaceBrightness?: number | null;
  units?: string;
}

export interface SPHERExBand {
  id: number; // 1 to 102
  array: 'Array 1' | 'Array 2' | 'Array 3' | 'Array 4' | 'Array 5' | 'Array 6';
  wavelengthMin: number;
  wavelengthMax: number;
  centerWavelength: number;
  resolvingPower: number;
  description: string;
}

export type LayerCategory =
  | 'observations'
  | 'grid'
  | 'galactic'
  | 'known_objects'
  | 'candidates'
  | 'differences';

export type LayerSourceType =
  | 'Actual SPHEREx Observation'
  | 'Reference Catalogue'
  | 'Prediction'
  | 'Unverified Candidate';

export interface LayerItem {
  id: string;
  name: string;
  category: LayerCategory;
  sourceType: LayerSourceType;
  enabled: boolean;
  available: boolean;
  description: string;
}

export interface InfraredAdjustments {
  brightness: number; // -100 to 100
  contrast: number; // 0.5 to 3.0
  intensity: number; // 0.1 to 3.0
  stretch: 'linear' | 'log' | 'asinh' | 'sqrt' | 'zscale';
  palette: 'monochrome' | 'spherex_ir' | 'cyan_amber' | 'plasma' | 'viridis';
  activeBandId: number;
  extName: 'IMAGE' | 'VARIANCE' | 'FLAGS' | 'ZODI';
}

export type ActiveWorkspace =
  | 'sky'
  | 'observations'
  | 'spectral'
  | 'time-domain'
  | 'compare'
  | 'sources'
  | 'moving-objects'
  | 'research';

export interface ArchiveObservation {
  id: string;
  collection: string;
  target: string;
  instrument: string;
  ra: number | null;
  dec: number | null;
  start_mjd: number | null;
  end_mjd: number | null;
  start_time: string | null;
  end_time: string | null;
  wavelength_min_m: number | null;
  wavelength_max_m: number | null;
  data_product_type: string;
  calibration_level: number | null;
  access_url: string;
  access_format: string;
  source: string;
  mission?: string;
  band?: string;
  provenance?: ProvenanceRecord;
}

export interface SpectralChannelPoint {
  channel: number;
  frame_index_0based: number;
  band: number;
  array: string;
  band_channel: number;
  wavelength_um: number;
  is_blank: boolean;
  status: string;
  note: string | null;
  surface_brightness: number | null;
  nhits: number;
  flags: number | null;
  valid: boolean;
  reason: string | null;
}

export interface CubeSpectrumResponse {
  tile: {
    order: number;
    nside: number;
    ordering: string;
    npix: number;
    dir_index: number;
    s3_url: string;
    irsa_hips_cube_url: string;
  };
  position: {
    ra: number;
    dec: number;
    pixel_x: number;
    pixel_y: number;
    subpixel_x: number;
    subpixel_y: number;
    aperture_radius_px: number;
    measurement_type: string;
  };
  units: string;
  uncertainty_note: string;
  blank_channels: number[];
  valid_channels: number;
  total_channels: number;
  mask_flagged: boolean;
  spectrum: SpectralChannelPoint[];
  provenance: ProvenanceRecord;
}

export interface GaiaSourceRecord {
  source_id: string | number;
  ra: number;
  dec: number;
  ref_epoch: number;
  ra_error: number | null;
  dec_error: number | null;
  parallax: number | null;
  parallax_error: number | null;
  pmra: number | null;
  pmra_error: number | null;
  pmdec: number | null;
  pmdec_error: number | null;
  radial_velocity: number | null;
  radial_velocity_error: number | null;
  phot_g_mean_mag: number | null;
  phot_bp_mean_mag: number | null;
  phot_rp_mean_mag: number | null;
  astrometric_excess_noise: number | null;
  ruwe: number | null;
  phot_variable_flag?: string | null;
}

export interface ProperMotionResult {
  source_id: string | number;
  reference_epoch: number;
  target_epoch: number;
  time_interval_years: number;
  original_icrs: { ra: number; dec: number };
  propagated_icrs: { ra: number; dec: number; ra_error_mas: number | null; dec_error_mas: number | null };
  angular_displacement_arcsec: number;
  position_angle_deg: number;
  radial_velocity_used_km_s: number | null;
  radial_velocity_note: string;
  warnings: string[];
  trajectory: Array<{ epoch: number; ra: number; dec: number }>;
  provenance: ProvenanceRecord;
}

export interface NeowisePoint {
  partition: string;
  source_id: string;
  ra: number;
  dec: number;
  sep_arcsec: number;
  mjd: number;
  utc: string;
  w1mpro: number | null;
  w1sigmpro: number | null;
  w2mpro: number | null;
  w2sigmpro: number | null;
  qual_frame: number | null;
  ph_qual: string;
  cc_flags: string;
  moon_masked: string;
  saa_sep: number | null;
  accepted: boolean;
  warnings: string[];
}

export interface MovingObjectCandidate {
  candidate_id: string;
  classification:
    | 'Unverified candidate'
    | 'Possible known-object match'
    | 'No known-object match found'
    | 'Insufficient observations'
    | 'Likely artifact or unreliable detection'
    | 'Requires human review';
  reason: string;
  epochs_linked?: number;
  time_baseline_hours?: number;
  total_displacement_arcsec?: number;
  angular_rate_arcsec_hr?: number;
  mu_ra_cosdec_arcsec_hr?: number;
  mu_dec_arcsec_hr?: number;
  rms_residual_arcsec?: number;
  gaia_crossmatch_id?: string | null;
  detections?: Array<{
    obs_id: string;
    mjd: number;
    obs_time: string;
    xcentroid: number;
    ycentroid: number;
    ra: number;
    dec: number;
    flux: number;
    snr_approx: number;
  }>;
}

export interface FitsQualityInspection {
  selected_extension: string;
  shape: number[];
  bunit: string;
  extensions: Array<{ index: number; name: string; dimensions: number[]; bunit: string | null }>;
  quality: {
    total_pixels: number;
    finite_pixels: number;
    nan_or_missing_pixels: number;
    missing_fraction: number;
    flagged_pixels: number | null;
    has_variance: boolean;
    has_zodi_model: boolean;
    min_value: number | null;
    max_value: number | null;
    median_value: number | null;
    median_snr: number | null;
    snr_note: string;
  };
  provenance_headers: Record<string, string | null>;
}

export interface SavedResearchArtifact {
  id: string;
  createdAtUtc: string;
  kind: 'spectrum' | 'lightcurve' | 'comparison' | 'moving-candidate' | 'ephemeris' | 'observation';
  title: string;
  ra: number;
  dec: number;
  summary: string;
  provenance?: ProvenanceRecord;
  payload: unknown;
}
