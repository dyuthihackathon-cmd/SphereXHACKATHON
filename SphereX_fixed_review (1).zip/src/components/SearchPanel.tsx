import React, { useState } from 'react';
import { Search, X, Compass, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { SkyCoordinate } from '../types';
import { parseRA, parseDec, formatRA, formatDec } from '../utils/coordinates';
import { BENCHMARK_TARGETS } from '../utils/spherexData';
import { resolveAstronomicalTarget } from '../services/spherexApi';

interface SearchPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToCoord: (coord: SkyCoordinate, label?: string) => void;
}

export const SearchPanel: React.FC<SearchPanelProps> = ({
  isOpen,
  onClose,
  onNavigateToCoord,
}) => {
  const [query, setQuery] = useState('');
  const [resolving, setResolving] = useState(false);
  const [resolveError, setResolveError] = useState<string | null>(null);
  const [resolvedResult, setResolvedResult] = useState<{
    resolved_name: string;
    ra: number;
    dec: number;
    source: string;
    notes?: string;
  } | null>(null);

  if (!isOpen) return null;

  const parseCoordinateQuery = (): { ra: number; dec: number } | null => {
    const clean = query.trim().replace(/ra[:=]?\s*/gi, '').replace(/dec[:=]?\s*/gi, '');
    const parts = clean.includes(',') ? clean.split(',') : clean.split(/\s+/);
    if (parts.length === 2) {
      const ra = parseRA(parts[0]);
      const dec = parseDec(parts[1]);
      if (ra !== null && dec !== null) {
        return { ra, dec };
      }
    }
    return null;
  };

  const parsedCoord = parseCoordinateQuery();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setResolveError(null);
    setResolvedResult(null);

    if (parsedCoord) {
      onNavigateToCoord({
        ra: parsedCoord.ra,
        dec: parsedCoord.dec,
        isScientific: true,
        coordinateSource: 'Manual Target Entry',
      });
      onClose();
      return;
    }

    const name = query.trim();
    if (!name) return;

    setResolving(true);
    try {
      const res = await resolveAstronomicalTarget(name);
      setResolvedResult(res);
    } catch (err) {
      setResolveError(err instanceof Error ? err.message : 'Target name resolution failed.');
    } finally {
      setResolving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-start justify-center pt-16 px-4">
      <div className="w-full max-w-xl bg-[#0b101b] border border-slate-800 rounded flex flex-col overflow-hidden text-xs">
        <form onSubmit={handleSubmit} className="p-3 border-b border-slate-800 flex items-center gap-2.5 bg-[#090d16]">
          <Search className="w-4 h-4 text-cyan-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setResolveError(null);
              setResolvedResult(null);
            }}
            placeholder="Enter RA, Dec (decimal or sexagesimal) or object name (e.g. M31, WISE 0855)..."
            className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 font-mono text-xs focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setResolvedResult(null);
                setResolveError(null);
              }}
              aria-label="Clear query"
              className="text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            type="submit"
            disabled={!query.trim() || resolving}
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-medium rounded cursor-pointer whitespace-nowrap shrink-0"
          >
            {parsedCoord ? 'Go to Coord' : resolving ? 'Resolving...' : 'Resolve Name'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white border border-slate-700 rounded px-2 py-1 text-[11px] cursor-pointer"
          >
            Esc
          </button>
        </form>

        <div className="p-3 space-y-3 max-h-96 overflow-y-auto">
          {parsedCoord && (
            <button
              type="button"
              onClick={() => {
                onNavigateToCoord({
                  ra: parsedCoord.ra,
                  dec: parsedCoord.dec,
                  isScientific: true,
                  coordinateSource: 'Manual Target Entry',
                });
                onClose();
              }}
              className="w-full p-2.5 rounded bg-slate-900 border border-cyan-500/60 hover:bg-slate-800 text-left flex items-center justify-between cursor-pointer"
            >
              <div>
                <div className="font-mono text-slate-100">
                  {formatRA(parsedCoord.ra)} · {formatDec(parsedCoord.dec)}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                  ICRS {parsedCoord.ra.toFixed(6)}°, {parsedCoord.dec.toFixed(6)}°
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-cyan-400 shrink-0" />
            </button>
          )}

          {resolving && (
            <div className="flex items-center gap-2 text-cyan-300 py-3">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Querying SIMBAD / NED astronomical name resolver...</span>
            </div>
          )}

          {resolveError && (
            <div className="p-2.5 border border-rose-800 bg-rose-950/30 text-rose-200 rounded flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{resolveError}</span>
            </div>
          )}

          {resolvedResult && (
            <button
              type="button"
              onClick={() => {
                onNavigateToCoord(
                  {
                    ra: resolvedResult.ra,
                    dec: resolvedResult.dec,
                    isScientific: true,
                    coordinateSource: 'Manual Target Entry',
                  },
                  resolvedResult.resolved_name,
                );
                onClose();
              }}
              className="w-full p-3 rounded bg-slate-900 border border-cyan-500/60 hover:bg-slate-800 text-left flex items-center justify-between cursor-pointer"
            >
              <div>
                <div className="font-medium text-slate-100">{resolvedResult.resolved_name}</div>
                <div className="font-mono text-cyan-300 mt-0.5">
                  RA {resolvedResult.ra.toFixed(6)}° · Dec {resolvedResult.dec.toFixed(6)}°
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Resolved via {resolvedResult.source}</div>
              </div>
              <ArrowRight className="w-4 h-4 text-cyan-400 shrink-0" />
            </button>
          )}

          <div>
            <div className="text-[11px] font-medium text-slate-400 mb-1.5">Verified Benchmark Targets</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {BENCHMARK_TARGETS.map((target) => (
                <button
                  key={target.label}
                  type="button"
                  onClick={() => {
                    onNavigateToCoord(
                      {
                        ra: target.ra,
                        dec: target.dec,
                        isScientific: true,
                        coordinateSource: 'Manual Target Entry',
                      },
                      target.label,
                    );
                    onClose();
                  }}
                  className="p-2 rounded border border-slate-800 bg-slate-950/60 hover:border-cyan-500/50 hover:bg-slate-900 text-left cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1.5 font-medium text-slate-100">
                    <Compass className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{target.label}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{target.subtitle}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
