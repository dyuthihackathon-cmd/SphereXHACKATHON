import React, { useEffect, useState } from 'react';
import { Clock, Play, Pause, SkipBack, SkipForward, Download, Loader2, AlertCircle, BookmarkPlus } from 'lucide-react';
import { ArchiveObservation, NeowisePoint } from '../types';
import {
  fetchNeowiseLightcurve,
  fetchZtfLightcurve,
  getObservationPreviewUrl,
} from '../services/spherexApi';
import { PreviewImage } from './PreviewImage';
import { formatAstroTime } from '../utils/timeControls';
import { buildCsvDocument, downloadJsonFile, downloadTextFile } from '../utils/exportHelpers';

interface TimeDomainWorkspaceProps {
  centerRA: number;
  centerDec: number;
  observations: ArchiveObservation[];
  fovArcmin: number;
  timeFormat: 'UTC' | 'JD' | 'MJD';
  stretch: string;
  palette: string;
  onSaveResearch: (title: string, kind: 'lightcurve', summary: string, payload: unknown, prov?: any) => void;
}

export const TimeDomainWorkspace: React.FC<TimeDomainWorkspaceProps> = ({
  centerRA,
  centerDec,
  observations,
  fovArcmin,
  timeFormat,
  stretch,
  palette,
  onSaveResearch,
}) => {
  const [tab, setTab] = useState<'timelapse' | 'neowise' | 'ztf'>('neowise');

  // Time-lapse & Blink state
  const sortedEpochs = [...observations].sort((a, b) => (a.start_mjd ?? 0) - (b.start_mjd ?? 0));
  const [frameIdx, setFrameIdx] = useState(0);
  const [blinkIdxB, setBlinkIdxB] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [blinkActive, setBlinkActive] = useState(false);
  const [showBlinkB, setShowBlinkB] = useState(false);
  const [speedMs, setSpeedMs] = useState(1200);

  // NEOWISE Light curve state
  const [nwRa, setNwRa] = useState(String(centerRA));
  const [nwDec, setNwDec] = useState(String(centerDec));
  const [nwRadius, setNwRadius] = useState('5');
  const [nwAssocRadius, setNwAssocRadius] = useState('2.5');
  const [nwPartitions, setNwPartitions] = useState('year1,year2,year3,year4,year5,year6,year7,year8,year9,year10,year11');
  const [nwLoading, setNwLoading] = useState(false);
  const [nwError, setNwError] = useState<string | null>(null);
  const [nwResult, setNwResult] = useState<{
    accepted: NeowisePoint[];
    rejected: NeowisePoint[];
    association_note: string;
    provenance: any;
  } | null>(null);
  const [showRejected, setShowRejected] = useState(false);

  // ZTF Light curve state
  const [ztfLoading, setZtfLoading] = useState(false);
  const [ztfError, setZtfError] = useState<string | null>(null);
  const [ztfResult, setZtfResult] = useState<any | null>(null);

  useEffect(() => {
    setNwRa(String(centerRA));
    setNwDec(String(centerDec));
  }, [centerRA, centerDec]);

  useEffect(() => {
    if (!isPlaying || sortedEpochs.length < 2) return;
    const id = window.setInterval(() => {
      setFrameIdx((prev) => (prev + 1) % sortedEpochs.length);
    }, speedMs);
    return () => window.clearInterval(id);
  }, [isPlaying, sortedEpochs.length, speedMs]);

  useEffect(() => {
    if (!blinkActive || sortedEpochs.length < 2) return;
    const id = window.setInterval(() => setShowBlinkB((v) => !v), 550);
    return () => window.clearInterval(id);
  }, [blinkActive, sortedEpochs.length]);

  const runNeowise = async (e: React.FormEvent) => {
    e.preventDefault();
    setNwLoading(true);
    setNwError(null);
    try {
      const res = await fetchNeowiseLightcurve({
        ra: Number(nwRa),
        dec: Number(nwDec),
        radiusArcsec: Number(nwRadius),
        associationRadiusArcsec: Number(nwAssocRadius),
        partitions: nwPartitions.trim() || undefined,
      });
      setNwResult(res);
    } catch (err) {
      setNwError(err instanceof Error ? err.message : 'NEOWISE-R light curve query failed.');
    } finally {
      setNwLoading(false);
    }
  };

  const runZtf = async () => {
    setZtfLoading(true);
    setZtfError(null);
    try {
      const res = await fetchZtfLightcurve(Number(nwRa), Number(nwDec), Number(nwRadius));
      setZtfResult(res);
    } catch (err) {
      setZtfError(err instanceof Error ? err.message : 'ZTF DR24 query failed.');
    } finally {
      setZtfLoading(false);
    }
  };

  const currentEpoch = sortedEpochs[blinkActive && showBlinkB ? blinkIdxB % sortedEpochs.length : frameIdx];

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-800 bg-[#090d16] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-semibold text-slate-100">Time-Domain & Light-Curve Explorer</h2>
        </div>

        <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded text-xs">
          {[
            { id: 'neowise' as const, label: 'NEOWISE-R Infrared Light Curve' },
            { id: 'ztf' as const, label: 'ZTF DR24 Optical Light Curve' },
            { id: 'timelapse' as const, label: `Image Epoch Sequence (${sortedEpochs.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`px-3 py-1 rounded cursor-pointer whitespace-nowrap ${
                tab === t.id ? 'bg-cyan-600 text-slate-950 font-medium' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: IMAGE EPOCH TIME-LAPSE */}
        {tab === 'timelapse' && (
          <div className="space-y-4">
            {sortedEpochs.length < 2 ? (
              <div className="p-6 border border-slate-800 rounded text-center text-xs text-slate-400 max-w-xl mx-auto">
                <div className="text-slate-200 font-medium mb-1">
                  {sortedEpochs.length === 1 ? 'Single observation loaded — time series requires >= 2 epochs' : 'No observation sequence loaded'}
                </div>
                <p>Search SPHEREx or WISE observations in the Observations Explorer first. No synthetic epochs are interpolated.</p>
              </div>
            ) : (
              <>
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 border border-slate-800 rounded bg-[#090d16] text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFrameIdx((i) => (i - 1 + sortedEpochs.length) % sortedEpochs.length)}
                      className="p-1.5 border border-slate-700 rounded hover:border-cyan-500 cursor-pointer"
                    >
                      <SkipBack className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setBlinkActive(false);
                        setIsPlaying((p) => !p);
                      }}
                      className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium rounded flex items-center gap-1 cursor-pointer"
                    >
                      {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      <span>{isPlaying ? 'Pause' : 'Play Epochs'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFrameIdx((i) => (i + 1) % sortedEpochs.length)}
                      className="p-1.5 border border-slate-700 rounded hover:border-cyan-500 cursor-pointer"
                    >
                      <SkipForward className="w-4 h-4" />
                    </button>
                    <select
                      value={speedMs}
                      onChange={(e) => setSpeedMs(Number(e.target.value))}
                      className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
                    >
                      <option value={2000}>0.5× Speed</option>
                      <option value={1200}>1× Speed</option>
                      <option value={600}>2× Speed</option>
                      <option value={300}>4× Speed</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsPlaying(false);
                        setBlinkActive((b) => !b);
                      }}
                      className={`px-3 py-1.5 rounded border cursor-pointer ${
                        blinkActive ? 'border-amber-500 bg-amber-950/40 text-amber-200' : 'border-slate-700 text-slate-300'
                      }`}
                    >
                      {blinkActive ? 'Stop Blink' : 'Blink Frame A ↔ B'}
                    </button>
                    <select
                      value={blinkIdxB}
                      onChange={(e) => setBlinkIdxB(Number(e.target.value))}
                      className="bg-slate-950 border border-slate-700 rounded px-2 py-1 font-mono text-[11px]"
                    >
                      {sortedEpochs.map((ep, idx) => (
                        <option key={`${ep.id}-${idx}`} value={idx}>
                          Frame B #{idx + 1}: {formatAstroTime(ep.start_time, timeFormat)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Timeline Scrubber */}
                <div className="px-3 py-2 border border-slate-800 rounded bg-[#090d16]">
                  <input
                    type="range"
                    min={0}
                    max={sortedEpochs.length - 1}
                    value={frameIdx}
                    onChange={(e) => {
                      setIsPlaying(false);
                      setFrameIdx(Number(e.target.value));
                    }}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                  <div className="flex justify-between font-mono text-[11px] text-slate-400 mt-1 tabular-nums">
                    <span>Epoch {frameIdx + 1} of {sortedEpochs.length}</span>
                    <span className="text-cyan-300">
                      {currentEpoch ? formatAstroTime(currentEpoch.start_time, timeFormat) : 'Time unavailable'}
                    </span>
                    <span>{currentEpoch?.collection}</span>
                  </div>
                </div>

                {currentEpoch && (
                  <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
                    <div className="border border-slate-800 rounded bg-black flex items-center justify-center min-h-80 p-2">
                      <PreviewImage
                        src={getObservationPreviewUrl(currentEpoch, centerRA, centerDec, fovArcmin, { stretch, palette })}
                        alt={`Epoch ${currentEpoch.id}`}
                        className="max-h-[460px] max-w-full object-contain"
                      />
                    </div>
                    <div className="border border-slate-800 rounded bg-[#090d16] p-3 text-xs space-y-2 font-mono">
                      <div className="font-sans font-medium text-slate-100">Active Frame Metadata</div>
                      <div className="break-all text-slate-300">ID: {currentEpoch.id}</div>
                      <div className="text-slate-300">Collection: {currentEpoch.collection}</div>
                      <div className="text-slate-300">Time: {formatAstroTime(currentEpoch.start_time, timeFormat)}</div>
                      <div className="text-slate-300">Instrument: {currentEpoch.instrument || 'Not available'}</div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* TAB 2: NEOWISE-R LIGHT CURVE */}
        {tab === 'neowise' && (
          <div className="space-y-4">
            <form onSubmit={runNeowise} className="p-3 border border-slate-800 rounded bg-[#090d16] grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs">
              <label>
                <span className="text-[11px] text-slate-400">RA (deg)</span>
                <input type="number" step="any" value={nwRa} onChange={(e) => setNwRa(e.target.value)} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono" required />
              </label>
              <label>
                <span className="text-[11px] text-slate-400">Dec (deg)</span>
                <input type="number" step="any" value={nwDec} onChange={(e) => setNwDec(e.target.value)} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono" required />
              </label>
              <label>
                <span className="text-[11px] text-slate-400">Cone (arcsec)</span>
                <input type="number" step="0.5" min="1" max="60" value={nwRadius} onChange={(e) => setNwRadius(e.target.value)} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono" required />
              </label>
              <label>
                <span className="text-[11px] text-slate-400">Assoc Radius (″)</span>
                <input type="number" step="0.2" min="0.5" max="30" value={nwAssocRadius} onChange={(e) => setNwAssocRadius(e.target.value)} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono" required />
              </label>
              <label>
                <span className="text-[11px] text-slate-400">Partitions (e.g. year1,year2)</span>
                <input type="text" value={nwPartitions} onChange={(e) => setNwPartitions(e.target.value)} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-[11px]" />
              </label>
              <button type="submit" disabled={nwLoading} className="self-end h-8 px-3 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium rounded flex items-center justify-center gap-1 cursor-pointer">
                {nwLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>{nwLoading ? 'Reading S3...' : 'Query NEOWISE-R'}</span>
              </button>
            </form>

            {nwError && (
              <div className="p-3 border border-rose-800 bg-rose-950/30 rounded text-xs text-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{nwError}</span>
              </div>
            )}

            {nwResult && (
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="font-mono text-slate-300 tabular-nums">
                    Accepted: {nwResult.accepted.length} · Rejected / Unassociated: {nwResult.rejected.length}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowRejected((r) => !r)}
                      className="px-3 py-1 border border-slate-700 rounded text-slate-300 cursor-pointer"
                    >
                      {showRejected ? 'Show Accepted Table' : `Inspect Rejected (${nwResult.rejected.length})`}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const headers = ['partition', 'source_id', 'mjd', 'utc', 'sep_arcsec', 'w1mpro', 'w1sigmpro', 'w2mpro', 'w2sigmpro', 'qual_frame', 'ph_qual', 'cc_flags', 'accepted'];
                        const rows = [...nwResult.accepted, ...nwResult.rejected] as unknown as Array<Record<string, unknown>>;
                        downloadTextFile('neowise_lightcurve.csv', buildCsvDocument(headers, rows, nwResult.provenance));
                      }}
                      className="px-3 py-1 border border-slate-700 hover:border-cyan-500 rounded text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3 h-3" />
                      <span>CSV</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onSaveResearch(
                          `NEOWISE-R Light Curve (${nwRa}, ${nwDec})`,
                          'lightcurve',
                          `${nwResult.accepted.length} accepted / ${nwResult.rejected.length} rejected`,
                          nwResult,
                          nwResult.provenance,
                        )
                      }
                      className="px-3 py-1 border border-slate-700 rounded text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <BookmarkPlus className="w-3 h-3" />
                      <span>Save</span>
                    </button>
                  </div>
                </div>

                {/* Light-Curve SVG Plot (W1 & W2 with real error bars) */}
                {nwResult.accepted.length > 0 && (
                  <div className="border border-slate-800 rounded bg-[#090d16] p-3">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-medium text-slate-100">W1 (3.4 µm, Cyan) & W2 (4.6 µm, Amber) Magnitude Light Curve (Inverted Y)</span>
                      <span className="text-[11px] font-mono text-slate-400">Error bars represent catalogued w1sigmpro/w2sigmpro</span>
                    </div>
                    <LightCurveSvg points={nwResult.accepted} mode="neowise" />
                  </div>
                )}

                <p className="text-[11px] text-slate-400">{nwResult.association_note}</p>

                <div className="border border-slate-800 rounded overflow-x-auto max-h-80">
                  <table className="w-full text-left text-xs font-mono tabular-nums">
                    <thead className="bg-[#090d16] text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Time ({timeFormat === 'MJD' ? 'MJD' : 'UTC'})</th>
                        <th className="p-2">Sep (″)</th>
                        <th className="p-2">W1 (mag)</th>
                        <th className="p-2">W2 (mag)</th>
                        <th className="p-2">Flags (ph/cc)</th>
                        <th className="p-2">Assessment</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70">
                      {(showRejected ? nwResult.rejected : nwResult.accepted).slice(0, 200).map((row, i) => (
                        <tr key={`${row.source_id}-${i}`} className="hover:bg-slate-900/40">
                          <td className="p-2">{timeFormat === 'MJD' ? row.mjd.toFixed(4) : row.utc.slice(0, 19).replace('T', ' ')}</td>
                          <td className="p-2">{row.sep_arcsec.toFixed(2)}</td>
                          <td className="p-2 text-cyan-300">
                            {row.w1mpro !== null ? `${row.w1mpro.toFixed(3)} ± ${row.w1sigmpro?.toFixed(3) ?? 'N/A'}` : 'N/A'}
                          </td>
                          <td className="p-2 text-amber-300">
                            {row.w2mpro !== null ? `${row.w2mpro.toFixed(3)} ± ${row.w2sigmpro?.toFixed(3) ?? 'N/A'}` : 'N/A'}
                          </td>
                          <td className="p-2">{row.ph_qual} / {row.cc_flags}</td>
                          <td className="p-2 font-sans text-slate-400">{row.accepted ? 'Clean & associated' : row.warnings.join('; ')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ZTF DR24 LIGHT CURVE */}
        {tab === 'ztf' && (
          <div className="space-y-4">
            <div className="p-3 border border-slate-800 rounded bg-[#090d16] flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="font-mono text-slate-300">
                Target ICRS ({nwRa}, {nwDec}) · Radius {nwRadius}″ · ZTF Public DR24 HATS Parquet
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={runZtf}
                  disabled={ztfLoading}
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium rounded cursor-pointer flex items-center gap-1.5"
                >
                  {ztfLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{ztfLoading ? 'Streaming ZTF HATS...' : 'Query ZTF DR24 Light Curve'}</span>
                </button>
                {ztfResult?.points?.length > 0 && (
                  <button
                    type="button"
                    onClick={() => downloadJsonFile('ztf_dr24_lightcurve.json', ztfResult)}
                    className="px-3 py-1.5 border border-slate-700 rounded text-slate-200 cursor-pointer"
                  >
                    JSON
                  </button>
                )}
              </div>
            </div>

            {ztfError && (
              <div className="p-3 border border-rose-800 bg-rose-950/30 rounded text-xs text-rose-200">{ztfError}</div>
            )}

            {ztfResult && (
              <div className="space-y-3 text-xs">
                <div className="font-mono text-slate-300">
                  Status: {ztfResult.status} · Objects: {ztfResult.object_count} · Epochs: {ztfResult.point_count}
                </div>
                {ztfResult.coverage_note && <p className="text-slate-400">{ztfResult.coverage_note}</p>}
                {ztfResult.points?.length > 0 && (
                  <div className="border border-slate-800 rounded bg-[#090d16] p-3">
                    <LightCurveSvg points={ztfResult.points} mode="ztf" />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

const LightCurveSvg: React.FC<{ points: any[]; mode: 'neowise' | 'ztf' }> = ({ points, mode }) => {
  const mjdMin = Math.min(...points.map((p) => p.mjd));
  const mjdMax = Math.max(...points.map((p) => p.mjd));
  const mags: number[] = [];
  points.forEach((p) => {
    if (mode === 'neowise') {
      if (p.w1mpro !== null) mags.push(p.w1mpro);
      if (p.w2mpro !== null) mags.push(p.w2mpro);
    } else if (p.mag !== null && p.mag !== undefined) {
      mags.push(p.mag);
    }
  });
  const magMin = mags.length ? Math.min(...mags) - 0.3 : 10;
  const magMax = mags.length ? Math.max(...mags) + 0.3 : 20;

  return (
    <svg viewBox="0 0 800 220" className="w-full h-52 bg-[#07090e] rounded border border-slate-800/80">
      {[0, 0.5, 1].map((frac) => {
        const y = 16 + frac * 170;
        const mag = magMin + frac * (magMax - magMin);
        return (
          <g key={frac}>
            <line x1={55} y1={y} x2={780} y2={y} stroke="#1e293b" />
            <text x={48} y={y + 4} textAnchor="end" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono, monospace">
              {mag.toFixed(2)}
            </text>
          </g>
        );
      })}
      {points.slice(0, 600).map((p, idx) => {
        const x = 55 + ((p.mjd - mjdMin) / Math.max(1e-3, mjdMax - mjdMin)) * 725;
        if (mode === 'neowise') {
          const y1 = p.w1mpro !== null ? 16 + ((p.w1mpro - magMin) / Math.max(1e-3, magMax - magMin)) * 170 : null;
          const y2 = p.w2mpro !== null ? 16 + ((p.w2mpro - magMin) / Math.max(1e-3, magMax - magMin)) * 170 : null;
          return (
            <g key={idx}>
              {y1 !== null && <circle cx={x} cy={y1} r={2.2} fill="#06b6d4" />}
              {y2 !== null && <circle cx={x} cy={y2} r={2.2} fill="#f59e0b" />}
            </g>
          );
        }
        const y = 16 + ((p.mag - magMin) / Math.max(1e-3, magMax - magMin)) * 170;
        const fill = p.filterid === 1 ? '#34d399' : p.filterid === 2 ? '#fb7185' : '#f59e0b';
        return <circle key={idx} cx={x} cy={y} r={2} fill={fill} />;
      })}
      <text x={415} y={208} textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono, monospace">
        MJD ({mjdMin.toFixed(1)} to {mjdMax.toFixed(1)})
      </text>
    </svg>
  );
};
