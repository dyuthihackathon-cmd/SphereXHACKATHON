import React, { useEffect, useState } from 'react';
import { FileText, Download, RefreshCw, Bookmark, Trash2, Settings, Package } from 'lucide-react';
import { SavedResearchArtifact } from '../types';
import { ArchiveStatusResponse, getArchiveStatus } from '../services/spherexApi';
import { downloadJsonFile, downloadTextFile } from '../utils/exportHelpers';

interface ResearchExportWorkspaceProps {
  artifacts: SavedResearchArtifact[];
  onRemoveArtifact: (id: string) => void;
  timeFormat: 'UTC' | 'JD' | 'MJD';
  onChangeTimeFormat: (fmt: 'UTC' | 'JD' | 'MJD') => void;
  coordFormat: 'sexagesimal' | 'decimal';
  onChangeCoordFormat: (fmt: 'sexagesimal' | 'decimal') => void;
  stepSeconds: number;
  onChangeStepSeconds: (sec: number) => void;
}

export const ResearchExportWorkspace: React.FC<ResearchExportWorkspaceProps> = ({
  artifacts,
  onRemoveArtifact,
  timeFormat,
  onChangeTimeFormat,
  coordFormat,
  onChangeCoordFormat,
  stepSeconds,
  onChangeStepSeconds,
}) => {
  const [statusData, setStatusData] = useState<ArchiveStatusResponse | null>(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);

  const probeArchives = async () => {
    setStatusLoading(true);
    setStatusError(null);
    try {
      const res = await getArchiveStatus();
      setStatusData(res);
    } catch (err) {
      setStatusError(err instanceof Error ? err.message : 'Archive connectivity probe failed.');
    } finally {
      setStatusLoading(false);
    }
  };

  useEffect(() => {
    probeArchives();
  }, []);

  const handleExportMarkdownReport = () => {
    const lines = [
      '# SphereX Multi-Wavelength Time-Domain Research Ledger',
      `Exported UTC: ${new Date().toISOString()}`,
      `Artifacts recorded: ${artifacts.length}`,
      '',
    ];
    for (const art of artifacts) {
      lines.push(`## ${art.title}`);
      lines.push(`- Kind: ${art.kind}`);
      lines.push(`- Coordinate (ICRS): RA=${art.ra.toFixed(6)} deg, Dec=${art.dec.toFixed(6)} deg`);
      lines.push(`- Recorded UTC: ${art.createdAtUtc}`);
      lines.push(`- Summary: ${art.summary}`);
      if (art.provenance) {
        lines.push(`- Provider / Survey: ${art.provenance.data_provider} / ${art.provenance.mission_survey}`);
        lines.push(`- Archive URL: ${art.provenance.archive_url}`);
      }
      lines.push('');
    }
    downloadTextFile(`spherex_research_ledger_${new Date().toISOString().slice(0, 10)}.md`, lines.join('\n'), 'text/markdown;charset=utf-8;');
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-800 bg-[#0b101b] flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            Research Ledger, Provenance, Preferences & Package Export
          </h2>
          <p className="text-[11px] text-slate-400">
            Session research ledger with source provenance, live external archive connectivity check, observatory preferences, and upgraded project download.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/SphereX-upgraded.zip"
            download="SphereX-upgraded.zip"
            className="px-3 py-1.5 rounded bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-medium flex items-center gap-1.5"
          >
            <Package className="w-3.5 h-3.5" /> Download SphereX-upgraded.zip
          </a>
          <button
            type="button"
            disabled={artifacts.length === 0}
            onClick={handleExportMarkdownReport}
            className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs disabled:opacity-40 flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Export Markdown
          </button>
          <button
            type="button"
            disabled={artifacts.length === 0}
            onClick={() => downloadJsonFile(`spherex_research_bundle_${new Date().toISOString().slice(0, 10)}.json`, artifacts)}
            className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs disabled:opacity-40 flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Export JSON Bundle
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-5 grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Saved Research Artifacts */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
            <span className="flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-cyan-400" /> Saved Research Snapshots ({artifacts.length})
            </span>
          </div>

          {artifacts.length === 0 ? (
            <div className="rounded border border-slate-800 bg-[#0b101b] p-6 text-center text-xs text-slate-400">
              No saved artifacts yet. Use <strong>Save to Research</strong> inside Observations, Spectral Explorer, Time Domain, Compare Images, or Moving Objects to collect reproducible records here.
            </div>
          ) : (
            <div className="space-y-2.5">
              {artifacts.map((art) => (
                <div key={art.id} className="rounded border border-slate-800 bg-[#0b101b] p-3.5 text-xs space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-cyan-400 font-mono">{art.kind}</span>
                      <h3 className="font-semibold text-white">{art.title}</h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => onRemoveArtifact(art.id)}
                      aria-label="Delete research artifact"
                      className="text-slate-500 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-slate-300">{art.summary}</p>
                  <div className="text-[11px] font-mono text-slate-400 flex flex-wrap gap-x-4 gap-y-1">
                    <span>RA/Dec: {art.ra.toFixed(5)}°, {art.dec.toFixed(5)}°</span>
                    <span>UTC: {art.createdAtUtc}</span>
                    {art.provenance && <span>Source: {art.provenance.data_provider}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right column: Observatory Preferences + Live External Provider Probe */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-3 text-xs">
            <div className="font-semibold text-white flex items-center gap-1.5">
              <Settings className="w-3.5 h-3.5 text-cyan-400" /> Observatory Preferences
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Time Standard</label>
                <select
                  value={timeFormat}
                  onChange={(e) => onChangeTimeFormat(e.target.value as 'UTC' | 'JD' | 'MJD')}
                  className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono"
                >
                  <option value="UTC">UTC (ISO-8601)</option>
                  <option value="MJD">MJD</option>
                  <option value="JD">JD</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Coordinate Format</label>
                <select
                  value={coordFormat}
                  onChange={(e) => onChangeCoordFormat(e.target.value as 'sexagesimal' | 'decimal')}
                  className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono"
                >
                  <option value="sexagesimal">Sexagesimal (HMS/DMS)</option>
                  <option value="decimal">Decimal Degrees</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-[10px] uppercase text-slate-500 mb-1">Epoch Step Interval (seconds)</label>
              <select
                value={stepSeconds}
                onChange={(e) => onChangeStepSeconds(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono"
              >
                <option value={900}>15 minutes (900 s)</option>
                <option value={1800}>30 minutes (1800 s)</option>
                <option value={3600}>1 hour (3600 s)</option>
                <option value={86400}>1 day (86400 s)</option>
              </select>
            </div>
          </div>

          <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">Live External Archive Status</span>
              <button
                type="button"
                onClick={probeArchives}
                disabled={statusLoading}
                className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200 hover:bg-slate-800 flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${statusLoading ? 'animate-spin' : ''}`} /> Probe
              </button>
            </div>
            {statusError && <p className="text-rose-300">{statusError}</p>}
            {statusData && (
              <div className="divide-y divide-slate-800/70 font-mono text-[11px]">
                {Object.entries(statusData.providers).map(([name, info]) => (
                  <div key={name} className="py-1.5 flex items-center justify-between">
                    <span className="text-slate-300">{name}</span>
                    <span className={info.reachable ? 'text-emerald-400' : 'text-rose-400'}>
                      {info.reachable ? `HTTP ${info.http_status}` : info.error || `HTTP ${info.http_status ?? 'ERR'}`}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
