import React from 'react';
import { X, Layers, Check, RotateCcw } from 'lucide-react';
import { LayerItem, LayerCategory } from '../types';

interface LayersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  layers: LayerItem[];
  onToggleLayer: (layerId: string) => void;
  onResetLayers: () => void;
  onSetAllLayers: (enabled: boolean) => void;
}

const CATEGORY_ORDER: Array<{ key: LayerCategory; label: string }> = [
  { key: 'grid', label: 'Coordinate Reference' },
  { key: 'galactic', label: 'Galactic Geometry' },
  { key: 'observations', label: 'Observations & Cutouts' },
  { key: 'known_objects', label: 'Reference Catalogues' },
  { key: 'differences', label: 'Proper Motion Tracks' },
  { key: 'candidates', label: 'Moving Objects & Ephemerides' },
];

export const LayersPanel: React.FC<LayersPanelProps> = ({
  isOpen,
  onClose,
  layers,
  onToggleLayer,
  onResetLayers,
  onSetAllLayers,
}) => {
  if (!isOpen) return null;

  return (
    <aside
      className="fixed top-12 bottom-12 left-0 z-40 w-80 bg-[#090d16] border-r border-slate-800 flex flex-col text-xs select-none"
      aria-label="Sky Overlay Layers"
    >
      <div className="h-10 px-3 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1.5 font-medium text-slate-100">
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          <span>Sky Layers</span>
        </div>
        <div className="flex items-center gap-2.5">
          <button type="button" onClick={() => onSetAllLayers(true)} className="text-[11px] text-slate-400 hover:text-white cursor-pointer">
            All
          </button>
          <button type="button" onClick={() => onSetAllLayers(false)} className="text-[11px] text-slate-400 hover:text-white cursor-pointer">
            None
          </button>
          <button
            type="button"
            onClick={onResetLayers}
            className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close layers panel"
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {CATEGORY_ORDER.map((cat) => {
          const items = layers.filter((l) => l.category === cat.key);
          if (!items.length) return null;
          return (
            <div key={cat.key} className="space-y-1.5">
              <div className="text-[11px] font-medium text-slate-400 border-b border-slate-800/80 pb-1">
                {cat.label}
              </div>
              {items.map((layer) => (
                <button
                  key={layer.id}
                  type="button"
                  disabled={!layer.available}
                  onClick={() => onToggleLayer(layer.id)}
                  className={`w-full p-2.5 rounded border text-left transition-colors ${
                    layer.available
                      ? layer.enabled
                        ? 'bg-slate-900 border-cyan-500/60 cursor-pointer'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 cursor-pointer'
                      : 'bg-slate-950/30 border-slate-800/60 opacity-55 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`w-3.5 h-3.5 rounded flex items-center justify-center border shrink-0 ${
                          layer.enabled && layer.available
                            ? 'bg-cyan-500 border-cyan-400 text-slate-950'
                            : 'bg-slate-900 border-slate-700 text-transparent'
                        }`}
                      >
                        <Check className="w-2.5 h-2.5" />
                      </span>
                      <span className="font-medium text-slate-100 truncate">{layer.name}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 shrink-0">
                      {layer.available ? (layer.enabled ? 'Visible' : 'Hidden') : 'No data yet'}
                    </span>
                  </div>
                  <p className="mt-1 pl-5 text-[11px] text-slate-400 leading-snug">{layer.description}</p>
                </button>
              ))}
            </div>
          );
        })}
      </div>
    </aside>
  );
};
