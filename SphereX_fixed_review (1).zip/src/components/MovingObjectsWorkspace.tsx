import React, { useEffect, useState } from 'react';
import { Orbit, Search, Radar, Loader2, AlertCircle, BookmarkPlus, ExternalLink } from 'lucide-react';
import { ArchiveObservation, MovingObjectCandidate } from '../types';
import {
  analyzeMovingCandidates,
  fetchHorizonsEphemeris,
  fetchMpcObservations,
  fetchMpcOrbit,
} from '../services/spherexApi';
import { buildCsvDocument, downloadTextFile } from '../utils/exportHelpers';

interface MovingObjectsWorkspaceProps {
  centerRA: number;
  centerDec: number;
  fovArcmin: number;
  observations: ArchiveObservation[];
  candidates: MovingObjectCandidate[];
  onCandidatesChange: (items: MovingObjectCandidate[]) => void;
  onNavigateToCoord: (ra: number, dec: number) => void;
  onSaveResearch: (title: string, kind: 'moving-candidate' | 'ephemeris', summary: string, payload: unknown, prov?: any) => void;
}

const CLASSIFICATION_STYLES: Record<string, string> = {
  'Unverified candidate': 'border-amber-500/40 bg-amber-950/30 text-amber-200',
  'Possible known-object match': 'border-cyan-500/40 bg-cyan-950/30 text-cyan-200',
  'No known-object match found': 'border-indigo-500/40 bg-indigo-950/30 text-indigo-200',
  'Insufficient observations': 'border-slate-700 bg-slate-900/60 text-slate-300',
  'Likely artifact or unreliable detection': 'border-rose-500/40 bg-rose-950/30 text-rose-200',
  'Requires human review': 'border-amber-500/40 bg-amber-950/30 text-amber-300',
};

export const MovingObjectsWorkspace: React.FC<MovingObjectsWorkspaceProps> = ({
  centerRA,
  centerDec,
  fovArcmin,
  observations,
  candidates,
  onCandidatesChange,
  onNavigateToCoord,
  onSaveResearch,
}) => {
  const [tab, setTab] = useState<'candidates' | 'horizons' | 'mpc'>('horizons');

  // Photutils multi-epoch detector params
  const [radiusArcsec, setRadiusArcsec] = useState('15');
  const [sigmaThreshold, setSigmaThreshold] = useState('5.0');
  const [detLoading, setDetLoading] = useState(false);
  const [detError, setDetError] = useState<string | null>(null);
  const [gaiaNote, setGaiaNote] = useState<string>('');

  // JPL Horizons params
  const [hzCommand, setHzCommand] = useState('C/2025 N1');
  const [hzStart, setHzStart] = useState('2025-07-01');
  const [hzStop, setHzStop] = useState('2025-07-10');
  const [hzStep, setHzStep] = useState('1 d');
  const [hzCenter, setHzCenter] = useState('500@399');
  const [hzLoading, setHzLoading] = useState(false);
  const [hzError, setHzError] = useState<string | null>(null);
  const [hzResult, setHzResult] = useState<any | null>(null);

  // MPC params
  const [mpcDesig, setMpcDesig] = useState('C/2025 N1');
  const [mpcLoading, setMpcLoading] = useState(false);
  const [mpcError, setMpcError] = useState<string | null>(null);
  const [mpcObs, setMpcObs] = useState<any | null>(null);
  const [mpcOrbit, setMpcOrbit] = useState<any | null>(null);

  useEffect(() => {
    setHzCommand((prev) => prev || 'C/2025 N1');
  }, []);

  const handleDetectCandidates = async () => {
    if (observations.length < 2) {
      setDetError('Load at least 2 multi-epoch FITS observations in the Observations tab first.');
      return;
    }
    setDetLoading(true);
    setDetError(null);
    try {
      const res = await analyzeMovingCandidates({
        ra_center: centerRA,
        dec_center: centerDec,
        observations,
        fov_arcmin: fovArcmin,
        search_radius_arcsec: Number(radiusArcsec),
        sigma_threshold: Number(sigmaThreshold),
      });
      setGaiaNote(res.gaia_note || '');
      onCandidatesChange(res.candidates);
    } catch (err) {
      setDetError(err instanceof Error ? err.message : 'Moving-object detection failed.');
    } finally {
      setDetLoading(false);
    }
  };

  const handleHorizons = async (e: React.FormEvent) => {
    e.preventDefault();
    setHzLoading(true);
    setHzError(null);
    try {
      const res = await fetchHorizonsEphemeris({
        command: hzCommand,
        startTime: hzStart,
        stopTime: hzStop,
        stepSize: hzStep,
        center: hzCenter,
      });
      setHzResult(res);
    } catch (err) {
      setHzError(err instanceof Error ? err.message : 'JPL Horizons query failed.');
    } finally {
      setHzLoading(false);
    }
  };

  const handleMpcQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    setMpcLoading(true);
    setMpcError(null);
    try {
      const [obsRes, orbRes] = await Promise.all([
        fetchMpcObservations(mpcDesig, 80),
        fetchMpcOrbit(mpcDesig),
      ]);
      setMpcObs(obsRes);
      setMpcOrbit(orbRes);
    } catch (err) {
      setMpcError(err instanceof Error ? err.message : 'IAU MPC verification failed.');
    } finally {
      setMpcLoading(false);
    }
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-800 bg-[#0b101b] flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Orbit className="w-4 h-4 text-cyan-400" />
            Moving Objects, JPL Horizons & Minor Planet Center
          </h2>
          <p className="text-[11px] text-slate-400">
            Photutils multi-epoch candidate linking (strict 6-label verification status), live NASA JPL Horizons ICRF ephemerides, and IAU MPC astrometric records.
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {[
            { id: 'horizons', label: 'JPL Horizons Ephemeris' },
            { id: 'mpc', label: 'IAU MPC Verification' },
            { id: 'candidates', label: 'Multi-Epoch Candidates' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as any)}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                tab === t.id
                  ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40'
                  : 'bg-[#090d16] text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-5 space-y-4">
        {tab === 'horizons' && (
          <>
            <form
              onSubmit={handleHorizons}
              className="rounded border border-slate-800 bg-[#0b101b] p-3.5 grid grid-cols-1 md:grid-cols-6 gap-2.5 items-end text-xs"
            >
              <div className="md:col-span-2">
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Horizons Designation / SPK-ID</label>
                <input
                  value={hzCommand}
                  onChange={(e) => setHzCommand(e.target.value)}
                  placeholder="e.g. C/2025 N1, 1I, 99942, 1"
                  className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Start UTC</label>
                <input value={hzStart} onChange={(e) => setHzStart(e.target.value)} className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Stop UTC</label>
                <input value={hzStop} onChange={(e) => setHzStop(e.target.value)} className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Step & Center</label>
                <div className="flex gap-1.5">
                  <input value={hzStep} onChange={(e) => setHzStep(e.target.value)} className="w-16 px-2 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
                  <input value={hzCenter} onChange={(e) => setHzCenter(e.target.value)} title="Observer code e.g. 500@399" className="w-full px-2 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
                </div>
              </div>
              <button
                type="submit"
                disabled={hzLoading}
                className="px-3.5 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center justify-center gap-1.5"
              >
                {hzLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                Query Horizons
              </button>
            </form>

            {hzError && (
              <div className="p-3 rounded bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{hzError}</span>
              </div>
            )}

            {hzResult && (
              <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div>
                    <div className="font-semibold text-white">{hzResult.target_body}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {hzResult.coordinate_system} • Center: {hzResult.observer_center} • {hzResult.count} ephemeris rows
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const csv = buildCsvDocument(
                          ['utc', 'jd_utc', 'ra_deg', 'dec_deg', 'dra_cosd_arcsec_hr', 'ddec_arcsec_hr', 'ap_mag', 'delta_au'],
                          (hzResult.ephemeris || []).map((r: any) => ({
                            utc: r.utc,
                            jd_utc: r.jd_utc,
                            ra_deg: r.ra_deg,
                            dec_deg: r.dec_deg,
                            dra_cosd_arcsec_hr: r.dra_cosd_arcsec_hr,
                            ddec_arcsec_hr: r.ddec_arcsec_hr,
                            ap_mag: r.ap_mag,
                            delta_au: r.delta_au,
                          })),
                          hzResult.provenance,
                          [`NASA JPL Horizons ${hzResult.target_body}`],
                        );
                        downloadTextFile(`horizons_${hzResult.command.replace(/[^a-z0-9]/gi, '_')}.csv`, csv, 'text/csv;charset=utf-8;');
                      }}
                      className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200 text-xs"
                    >
                      Export CSV
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onSaveResearch(
                          `Horizons ${hzResult.target_body}`,
                          'ephemeris',
                          `${hzResult.count} rows (${hzStart} to ${hzStop})`,
                          hzResult,
                          hzResult.provenance,
                        )
                      }
                      className="px-2.5 py-1 rounded bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs flex items-center gap-1"
                    >
                      <BookmarkPlus className="w-3.5 h-3.5" /> Save
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto max-h-96 overflow-y-auto border border-slate-800 rounded">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead className="bg-[#090d16] text-slate-400 text-[10px] sticky top-0">
                      <tr>
                        <th className="px-3 py-2 border-b border-slate-800">UTC</th>
                        <th className="px-3 py-2 border-b border-slate-800">ICRF RA (deg)</th>
                        <th className="px-3 py-2 border-b border-slate-800">ICRF Dec (deg)</th>
                        <th className="px-3 py-2 border-b border-slate-800">dRA*cosD ("/hr)</th>
                        <th className="px-3 py-2 border-b border-slate-800">dDec ("/hr)</th>
                        <th className="px-3 py-2 border-b border-slate-800">APmag</th>
                        <th className="px-3 py-2 border-b border-slate-800">Delta (AU)</th>
                        <th className="px-3 py-2 border-b border-slate-800 text-right">View</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70">
                      {(hzResult.ephemeris || []).map((row: any, i: number) => (
                        <tr key={i} className="hover:bg-slate-900/50">
                          <td className="px-3 py-1.5 text-slate-300">{row.utc}</td>
                          <td className="px-3 py-1.5 text-cyan-300">{row.ra_deg?.toFixed(6) ?? 'N/A'}</td>
                          <td className="px-3 py-1.5 text-cyan-300">{row.dec_deg?.toFixed(6) ?? 'N/A'}</td>
                          <td className="px-3 py-1.5">{row.dra_cosd_arcsec_hr?.toFixed(2) ?? 'N/A'}</td>
                          <td className="px-3 py-1.5">{row.ddec_arcsec_hr?.toFixed(2) ?? 'N/A'}</td>
                          <td className="px-3 py-1.5">{row.ap_mag ?? 'N/A'}</td>
                          <td className="px-3 py-1.5">{row.delta_au?.toFixed(4) ?? 'N/A'}</td>
                          <td className="px-3 py-1.5 text-right">
                            {row.ra_deg !== null && row.dec_deg !== null && (
                              <button
                                type="button"
                                onClick={() => onNavigateToCoord(row.ra_deg, row.dec_deg)}
                                className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-amber-300 hover:bg-slate-800"
                              >
                                Slew Sky
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

        {tab === 'mpc' && (
          <>
            <form onSubmit={handleMpcQuery} className="rounded border border-slate-800 bg-[#0b101b] p-3.5 flex flex-wrap items-end gap-3 text-xs">
              <div className="min-w-64 flex-1">
                <label className="block text-[10px] uppercase text-slate-500 mb-1">MPC Designation or Number (e.g. 1, 433, C/2025 N1)</label>
                <input
                  value={mpcDesig}
                  onChange={(e) => setMpcDesig(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono"
                />
              </div>
              <button
                type="submit"
                disabled={mpcLoading}
                className="px-4 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5"
              >
                {mpcLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                Verify in IAU MPC
              </button>
            </form>

            {mpcError && (
              <div className="p-3 rounded bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{mpcError}</span>
              </div>
            )}

            {(mpcObs || mpcOrbit) && (
              <div className="space-y-4">
                {mpcOrbit?.orbit && (
                  <div className="rounded border border-slate-800 bg-[#0b101b] p-4 text-xs">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-white">MPC Orbital Elements: {mpcOrbit.designation}</span>
                      <a href={mpcOrbit.mpc_url} target="_blank" rel="noreferrer" className="text-cyan-400 hover:underline flex items-center gap-1">
                        MPC Record <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <pre className="text-[11px] font-mono text-slate-300 bg-[#090d16] p-3 rounded border border-slate-800 overflow-x-auto max-h-48">
                      {JSON.stringify(mpcOrbit.orbit, null, 2)}
                    </pre>
                  </div>
                )}

                {mpcObs && (
                  <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white">
                        ADES Astrometric Observations ({mpcObs.count} shown of {mpcObs.total_returned ?? 0})
                      </span>
                    </div>
                    <div className="overflow-x-auto max-h-80 overflow-y-auto border border-slate-800 rounded">
                      <table className="w-full text-left text-xs font-mono border-collapse">
                        <thead className="bg-[#090d16] text-slate-400 text-[10px] sticky top-0">
                          <tr>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">Obs Time (UTC)</th>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">Stn</th>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">RA (deg)</th>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">Dec (deg)</th>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">Mag (Band)</th>
                            <th className="px-2.5 py-1.5 border-b border-slate-800">Catalog</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/70">
                          {(mpcObs.observations || []).map((o: any, i: number) => (
                            <tr key={i} className="hover:bg-slate-900/50">
                              <td className="px-2.5 py-1.5">{o.obsTime || 'N/A'}</td>
                              <td className="px-2.5 py-1.5 text-amber-300">{o.stn || 'N/A'}</td>
                              <td className="px-2.5 py-1.5 text-cyan-300">{o.ra?.toFixed(6) ?? 'N/A'}</td>
                              <td className="px-2.5 py-1.5 text-cyan-300">{o.dec?.toFixed(6) ?? 'N/A'}</td>
                              <td className="px-2.5 py-1.5">{o.mag !== null ? `${o.mag} (${o.band || ''})` : 'N/A'}</td>
                              <td className="px-2.5 py-1.5">{o.astCat || 'N/A'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {tab === 'candidates' && (
          <div className="space-y-4">
            <div className="rounded border border-slate-800 bg-[#0b101b] p-3.5 flex flex-wrap items-end gap-3 text-xs">
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Max Link Radius (arcsec)</label>
                <input value={radiusArcsec} onChange={(e) => setRadiusArcsec(e.target.value)} className="w-28 px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-slate-500 mb-1">Photutils DAO Sigma</label>
                <input value={sigmaThreshold} onChange={(e) => setSigmaThreshold(e.target.value)} className="w-24 px-2.5 py-1.5 rounded bg-[#090d16] border border-slate-800 font-mono" />
              </div>
              <button
                type="button"
                disabled={detLoading}
                onClick={handleDetectCandidates}
                className="px-4 py-1.5 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 font-medium flex items-center gap-1.5"
              >
                {detLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Radar className="w-3.5 h-3.5" />}
                Run Multi-Epoch Candidate Detector ({Math.min(observations.length, 8)} epochs)
              </button>
              {gaiaNote && <span className="text-[11px] text-slate-400">{gaiaNote}</span>}
            </div>

            {detError && (
              <div className="p-3 rounded bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{detError}</span>
              </div>
            )}

            <div className="space-y-2.5">
              {candidates.map((c) => (
                <div
                  key={c.candidate_id}
                  className={`rounded border p-3.5 text-xs space-y-2 ${CLASSIFICATION_STYLES[c.classification] || 'border-slate-800 bg-[#0b101b]'}`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-mono font-semibold">
                      {c.candidate_id} — {c.classification}
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        onSaveResearch(
                          `Candidate ${c.candidate_id}`,
                          'moving-candidate',
                          `${c.classification}: ${c.reason}`,
                          c,
                        )
                      }
                      className="px-2 py-1 rounded bg-black/30 border border-current/30 text-[11px] flex items-center gap-1"
                    >
                      <BookmarkPlus className="w-3 h-3" /> Save Candidate
                    </button>
                  </div>
                  <p className="text-[11px] opacity-90">{c.reason}</p>
                  {c.epochs_linked && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-[11px] bg-black/25 p-2 rounded">
                      <span>Epochs: {c.epochs_linked}</span>
                      <span>Baseline: {c.time_baseline_hours?.toFixed(2)} hr</span>
                      <span>Displacement: {c.total_displacement_arcsec?.toFixed(2)}"</span>
                      <span>Rate: {c.angular_rate_arcsec_hr?.toFixed(3)} "/hr</span>
                    </div>
                  )}
                </div>
              ))}
              {candidates.length === 0 && (
                <div className="rounded border border-slate-800 bg-[#0b101b] p-6 text-center text-xs text-slate-400">
                  No moving-object candidates evaluated yet. Query multi-epoch images in <strong>Observations</strong> and click <strong>Run Multi-Epoch Candidate Detector</strong>. Unverified tracklets are explicitly labeled &ldquo;Unverified candidate&rdquo; and never claimed as discoveries.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
