import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Layers, Download, Loader2, AlertCircle, BookmarkPlus, Search } from 'lucide-react';
import { CubeSpectrumResponse, SpectralChannelPoint } from '../types';
import {
  fetchCubeSpectrum,
  getCubeSliceFitsUrl,
  getCubeSlicePngUrl,
} from '../services/spherexApi';
import { buildCsvDocument, downloadJsonFile, downloadTextFile } from '../utils/exportHelpers';

interface SpectralExplorerProps {
  centerRA: number;
  centerDec: number;
  onUpdateCenter: (ra: number, dec: number) => void;
  stretch: string;
  palette: string;
  onSaveResearch: (title: string, kind: 'spectrum', summary: string, payload: unknown, prov?: any) => void;
}

export const SpectralExplorer: React.FC<SpectralExplorerProps> = ({
  centerRA,
  centerDec,
  onUpdateCenter,
  stretch,
  palette,
  onSaveResearch,
}) => {
  const [ra, setRa] = useState(String(centerRA));
  const [dec, setDec] = useState(String(centerDec));
  const [aperturePx, setAperturePx] = useState<number>(0);
  const [maskFlagged, setMaskFlagged] = useState<boolean>(true);
  const [selectedChannel, setSelectedChannel] = useState<number>(1);
  const [wlMin, setWlMin] = useState<number>(0.75);
  const [wlMax, setWlMax] = useState<number>(5.05);
  const [hoverPoint, setHoverPoint] = useState<SpectralChannelPoint | null>(null);

  const [data, setData] = useState<CubeSpectrumResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sliceLoading, setSliceLoading] = useState(false);
  const [sliceError, setSliceError] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    setRa(String(centerRA));
    setDec(String(centerDec));
  }, [centerRA, centerDec]);

  const loadSpectrum = async (targetRa: number, targetDec: number, ap = aperturePx, mask = maskFlagged) => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    setLoading(true);
    setError(null);
    onUpdateCenter(targetRa, targetDec);
    try {
      const res = await fetchCubeSpectrum(
        { ra: targetRa, dec: targetDec, apertureRadiusPx: ap, maskFlagged: mask },
        ctrl.signal,
      );
      setData(res);
    } catch (err) {
      if ((err as Error).name === 'AbortError') return;
      setError(err instanceof Error ? err.message : 'Failed to extract SPHEREx 102-channel spectrum.');
    } finally {
      setLoading(false);
    }
  };

  const handleExtractSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = Number(ra);
    const d = Number(dec);
    if (!Number.isFinite(r) || r < 0 || r >= 360 || !Number.isFinite(d) || d < -90 || d > 90) {
      setError('Enter valid RA [0, 360) and Dec [-90, 90].');
      return;
    }
    loadSpectrum(r, d);
  };

  const activePoint = useMemo(() => {
    if (!data) return null;
    return hoverPoint || data.spectrum.find((s) => s.channel === selectedChannel) || null;
  }, [data, hoverPoint, selectedChannel]);

  const visiblePoints = useMemo(() => {
    if (!data) return [];
    return data.spectrum.filter((p) => p.wavelength_um >= wlMin && p.wavelength_um <= wlMax);
  }, [data, wlMin, wlMax]);

  const plotStats = useMemo(() => {
    const valid = visiblePoints.filter((p) => p.valid && p.surface_brightness !== null);
    if (!valid.length) return { minY: 0, maxY: 1, maxNhits: 1 };
    const ys = valid.map((p) => p.surface_brightness as number);
    let minY = Math.min(...ys);
    let maxY = Math.max(...ys);
    if (Math.abs(maxY - minY) < 1e-6) {
      minY -= 0.5;
      maxY += 0.5;
    } else {
      const pad = (maxY - minY) * 0.12;
      minY -= pad;
      maxY += pad;
    }
    const maxNhits = Math.max(1, ...visiblePoints.map((p) => p.nhits || 0));
    return { minY, maxY, maxNhits };
  }, [visiblePoints]);

  const isBlankSelected = selectedChannel === 51 || selectedChannel === 52;
  const slicePngUrl = !isBlankSelected && data
    ? getCubeSlicePngUrl(data.position.ra, data.position.dec, selectedChannel, stretch, palette)
    : null;

  useEffect(() => {
    if (!slicePngUrl) {
      setSliceLoading(false);
      setSliceError(false);
      return;
    }
    setSliceLoading(true);
    setSliceError(false);
  }, [slicePngUrl]);

  const exportCsv = () => {
    if (!data) return;
    const headers = ['channel', 'array', 'wavelength_um', 'surface_brightness', 'nhits', 'flags', 'is_blank', 'valid', 'reason'];
    const csv = buildCsvDocument(
      headers,
      data.spectrum as unknown as Array<Record<string, unknown>>,
      data.provenance,
      [
        `Measurement type: ${data.position.measurement_type}`,
        `Blank channels: ${data.blank_channels.join(', ')}`,
        data.uncertainty_note,
      ],
    );
    downloadTextFile(`spherex_spectrum_npix${data.tile.npix}.csv`, csv);
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      {/* Header & Extraction Controls */}
      <form
        onSubmit={handleExtractSubmit}
        className="p-4 border-b border-slate-800 bg-[#090d16] flex flex-wrap items-end gap-3 text-xs"
      >
        <label className="w-32">
          <span className="text-[11px] text-slate-400">RA (deg)</span>
          <input
            type="number"
            step="any"
            value={ra}
            onChange={(e) => setRa(e.target.value)}
            className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
            required
          />
        </label>
        <label className="w-32">
          <span className="text-[11px] text-slate-400">Dec (deg)</span>
          <input
            type="number"
            step="any"
            value={dec}
            onChange={(e) => setDec(e.target.value)}
            className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
            required
          />
        </label>
        <label className="w-40">
          <span className="text-[11px] text-slate-400">Spatial Extraction</span>
          <select
            value={aperturePx}
            onChange={(e) => setAperturePx(Number(e.target.value))}
            className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-100"
          >
            <option value={0}>Single Pixel (1×1)</option>
            <option value={1}>3×3 px Aperture Mean</option>
            <option value={2}>5×5 px Aperture Mean</option>
          </select>
        </label>
        <label className="flex items-center gap-2 pb-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={maskFlagged}
            onChange={(e) => setMaskFlagged(e.target.checked)}
            className="accent-cyan-500"
          />
          <span className="text-slate-300">Mask Flagged Pixels (FLAGS≠0)</span>
        </label>
        <button
          type="submit"
          disabled={loading}
          className="h-8 px-4 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-medium rounded flex items-center gap-1.5 cursor-pointer"
        >
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
          <span>{loading ? 'Extracting 102 Ch...' : 'Extract DR1 Cube Spectrum'}</span>
        </button>

        {data && (
          <div className="ml-auto flex items-center gap-2">
            <button
              type="button"
              onClick={exportCsv}
              className="h-8 px-3 border border-slate-700 hover:border-cyan-500 rounded text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Spectrum CSV</span>
            </button>
            <button
              type="button"
              onClick={() => downloadJsonFile(`spherex_spectrum_npix${data.tile.npix}.json`, data)}
              className="h-8 px-3 border border-slate-700 hover:border-slate-500 rounded text-slate-200 cursor-pointer"
            >
              JSON
            </button>
            <button
              type="button"
              onClick={() =>
                onSaveResearch(
                  `SPHEREx 102-Ch Spectrum (Npix ${data.tile.npix})`,
                  'spectrum',
                  `${data.valid_channels}/102 valid channels (${data.position.measurement_type})`,
                  data,
                  data.provenance,
                )
              }
              className="h-8 px-3 border border-slate-700 hover:border-cyan-500 rounded text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <BookmarkPlus className="w-3.5 h-3.5" />
              <span>Save</span>
            </button>
          </div>
        )}
      </form>

      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-4">
        {error && (
          <div className="p-3 border border-rose-800 bg-rose-950/30 rounded text-xs text-rose-200 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {!data && !loading && !error && (
          <div className="border border-slate-800 rounded p-8 text-center max-w-2xl mx-auto mt-6">
            <Layers className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <h3 className="text-sm font-medium text-slate-100">SPHEREx DR1 All-Sky Spectral Cube Explorer</h3>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Resolves the exact HEALPix order-5 NESTED FITS cube on NASA/IPAC AWS Open Data, inspects IMAGE, NHITS, and FLAGS extensions via HTTP Range, and extracts real 102-channel surface brightness measurements (0.753–4.988 µm) with dichroic gap masking at Channels 51 & 52.
            </p>
          </div>
        )}

        {data && (
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4">
            {/* Left: Interactive 102-Channel Scientific Spectrum Graph */}
            <div className="border border-slate-800 rounded bg-[#090d16] p-4 flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div>
                  <div className="font-medium text-slate-100">
                    {data.position.measurement_type} ({data.units})
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5 tabular-nums">
                    HEALPix Npix {data.tile.npix} · Pixel ({data.position.pixel_x}, {data.position.pixel_y}) · Valid {data.valid_channels}/{data.total_channels}
                  </div>
                </div>
                <div className="flex items-center gap-2 font-mono text-[11px]">
                  <span>λ Range:</span>
                  <input
                    type="number"
                    step="0.1"
                    min="0.7"
                    max="5.0"
                    value={wlMin}
                    onChange={(e) => setWlMin(Math.min(wlMax - 0.2, Number(e.target.value)))}
                    className="w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5"
                  />
                  <span>–</span>
                  <input
                    type="number"
                    step="0.1"
                    min="0.8"
                    max="5.1"
                    value={wlMax}
                    onChange={(e) => setWlMax(Math.max(wlMin + 0.2, Number(e.target.value)))}
                    className="w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setWlMin(0.75);
                      setWlMax(5.05);
                    }}
                    className="px-2 py-0.5 border border-slate-700 rounded text-slate-300 hover:text-white cursor-pointer"
                  >
                    Full
                  </button>
                </div>
              </div>

              {/* SVG Scientific Plot */}
              <div className="w-full overflow-hidden border border-slate-800 rounded bg-[#07090e] p-2">
                <svg viewBox="0 0 800 320" className="w-full h-72 select-none">
                  {/* Grid & Axes */}
                  {[0, 0.25, 0.5, 0.75, 1].map((frac) => {
                    const y = 20 + frac * 220;
                    const val = plotStats.maxY - frac * (plotStats.maxY - plotStats.minY);
                    return (
                      <g key={frac}>
                        <line x1={65} y1={y} x2={780} y2={y} stroke="#1e293b" strokeWidth={1} />
                        <text x={58} y={y + 4} textAnchor="end" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono, monospace">
                          {val.toFixed(2)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Blank Dichroic Channels 51 & 52 Shading */}
                  {visiblePoints
                    .filter((p) => p.is_blank)
                    .map((p) => {
                      const x = 65 + ((p.wavelength_um - wlMin) / Math.max(0.1, wlMax - wlMin)) * 715;
                      return (
                        <g key={p.channel}>
                          <line x1={x} y1={20} x2={x} y2={240} stroke="#f59e0b" strokeDasharray="3 3" strokeOpacity={0.65} />
                        </g>
                      );
                    })}

                  {/* Contiguous Valid Spectral Line Segments (never bridges over blank/invalid gaps) */}
                  {(() => {
                    const segments: string[] = [];
                    let current = '';
                    for (const pt of visiblePoints) {
                      if (!pt.valid || pt.surface_brightness === null) {
                        if (current) segments.push(current);
                        current = '';
                        continue;
                      }
                      const x = 65 + ((pt.wavelength_um - wlMin) / Math.max(0.1, wlMax - wlMin)) * 715;
                      const y = 20 + ((plotStats.maxY - pt.surface_brightness) / Math.max(1e-9, plotStats.maxY - plotStats.minY)) * 220;
                      current += `${current ? ' L ' : 'M '}${x.toFixed(1)} ${y.toFixed(1)}`;
                    }
                    if (current) segments.push(current);
                    return segments.map((d, i) => (
                      <path key={i} d={d} fill="none" stroke="#06b6d4" strokeWidth={1.6} />
                    ));
                  })()}

                  {/* Data Points & NHITS Sub-Panel */}
                  {visiblePoints.map((pt) => {
                    const x = 65 + ((pt.wavelength_um - wlMin) / Math.max(0.1, wlMax - wlMin)) * 715;
                    const nhHeight = ((pt.nhits || 0) / plotStats.maxNhits) * 38;
                    const isSel = pt.channel === selectedChannel;
                    const valid = pt.valid && pt.surface_brightness !== null;
                    const y = valid
                      ? 20 + ((plotStats.maxY - (pt.surface_brightness as number)) / Math.max(1e-9, plotStats.maxY - plotStats.minY)) * 220
                      : 235;
                    return (
                      <g
                        key={pt.channel}
                        onMouseEnter={() => setHoverPoint(pt)}
                        onMouseLeave={() => setHoverPoint(null)}
                        onClick={() => setSelectedChannel(pt.channel)}
                        className="cursor-pointer"
                      >
                        <rect
                          x={x - 2}
                          y={292 - nhHeight}
                          width={4}
                          height={Math.max(1, nhHeight)}
                          fill={pt.is_blank ? '#f59e0b' : '#334155'}
                        />
                        {valid ? (
                          <circle
                            cx={x}
                            cy={y}
                            r={isSel ? 4.5 : 2.5}
                            fill={isSel ? '#f59e0b' : '#22d3ee'}
                          />
                        ) : (
                          <rect x={x - 2} y={232} width={4} height={4} fill={pt.is_blank ? '#f59e0b' : '#ef4444'} />
                        )}
                      </g>
                    );
                  })}

                  <text x={420} y={314} textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="JetBrains Mono, monospace">
                    Wavelength (µm) · Bottom bars: NHITS exposure count
                  </text>
                </svg>
              </div>

              {/* Hover / Active Channel Telemetry */}
              {activePoint && (
                <div className="p-2.5 border border-slate-800 rounded bg-slate-950/80 grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono text-[11px] tabular-nums">
                  <div>
                    <span className="text-slate-400">Channel: </span>
                    <span className="text-slate-100">#{activePoint.channel} ({activePoint.array})</span>
                  </div>
                  <div>
                    <span className="text-slate-400">λ: </span>
                    <span className="text-cyan-300">{activePoint.wavelength_um.toFixed(4)} µm</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Intensity: </span>
                    <span className={activePoint.is_blank ? 'text-amber-300' : 'text-slate-100'}>
                      {activePoint.valid && activePoint.surface_brightness !== null
                        ? `${activePoint.surface_brightness.toFixed(4)} ${data.units}`
                        : activePoint.reason || 'Not available'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">NHITS: </span>
                    <span className="text-slate-100">{activePoint.nhits}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">FLAGS: </span>
                    <span className="text-slate-100">{activePoint.flags ?? 'None'}</span>
                  </div>
                </div>
              )}

              <p className="text-[11px] text-slate-400">{data.uncertainty_note}</p>
            </div>

            {/* Right: Channel 2D Image Slice Inspector */}
            <div className="border border-slate-800 rounded bg-[#090d16] p-4 flex flex-col gap-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-100">2D Tile Channel Slice</span>
                {!isBlankSelected && (
                  <a
                    href={getCubeSliceFitsUrl(data.position.ra, data.position.dec, selectedChannel)}
                    download
                    className="px-2.5 py-1 border border-slate-700 hover:border-cyan-500 rounded text-[11px] text-cyan-300"
                  >
                    Download Slice FITS
                  </a>
                )}
              </div>

              <div>
                <div className="flex justify-between font-mono text-[11px] text-slate-300 mb-1">
                  <span>Channel {selectedChannel} / 102</span>
                  <span>
                    {data.spectrum[selectedChannel - 1]?.wavelength_um.toFixed(4)} µm
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={102}
                  value={selectedChannel}
                  onChange={(e) => {
                    setSelectedChannel(Number(e.target.value));
                  }}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="aspect-square w-full border border-slate-800 rounded bg-black flex items-center justify-center overflow-hidden relative">
                {isBlankSelected ? (
                  <div className="p-4 text-center text-amber-300 text-xs">
                    Channel {selectedChannel} is an intentional blank dichroic channel (D3:17 / D4:01) in SPHEREx DR1. No image plane exists.
                  </div>
                ) : slicePngUrl ? (
                  <>
                    {sliceError ? (
                      <div role="status" className="p-4 text-center text-xs text-rose-200">
                        Channel preview unavailable. Check the backend and archive connection.
                      </div>
                    ) : (
                      <img
                        src={slicePngUrl}
                        alt={`SPHEREx cube channel ${selectedChannel}`}
                        referrerPolicy="no-referrer"
                        onLoad={() => setSliceLoading(false)}
                        onError={() => {
                          setSliceLoading(false);
                          setSliceError(true);
                        }}
                        className="w-full h-full object-contain"
                      />
                    )}
                    {sliceLoading && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-cyan-300 text-xs">
                        Loading channel plane...
                      </div>
                    )}
                  </>
                ) : null}
              </div>

              <div className="text-[11px] text-slate-400 space-y-1 font-mono">
                <div>Provenance: {data.provenance.source_or_obs_id}</div>
                <div className="truncate">Archive: {data.provenance.archive_collection}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
