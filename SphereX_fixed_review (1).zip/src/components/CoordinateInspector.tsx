import React, { useState } from 'react';
import { Crosshair, Copy, Check, X, Sparkles } from 'lucide-react';
import { SkyCoordinate } from '../types';
import { equatorialToGalactic, formatDec, formatRA } from '../utils/coordinates';

interface CoordinateInspectorProps {
  coordinate: SkyCoordinate;
  onClear: () => void;
  onInspectSpectrum?: (ra: number, dec: number) => void;
  onSearchArchives?: (ra: number, dec: number) => void;
}

export const CoordinateInspector: React.FC<CoordinateInspectorProps> = ({
  coordinate,
  onClear,
  onInspectSpectrum,
  onSearchArchives,
}) => {
  const [copied, setCopied] = useState(false);
  const gal = equatorialToGalactic(coordinate.ra, coordinate.dec);

  const handleCopy = async () => {
    const text = `${coordinate.ra.toFixed(6)}, ${coordinate.dec.toFixed(6)} (${formatRA(coordinate.ra)} ${formatDec(coordinate.dec)})`;
    await navigator.clipboard?.writeText(text);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="absolute top-3 right-3 z-30 w-76 bg-[#0b101b] border border-slate-800 rounded p-3 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2.5">
        <div className="flex items-center gap-2 font-medium text-slate-100">
          <Crosshair className="w-3.5 h-3.5 text-cyan-400" />
          <span>Selected Position</span>
        </div>
        <button
          type="button"
          onClick={onClear}
          aria-label="Clear coordinate selection"
          className="text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-1.5 font-mono tabular-nums">
        <div className="flex justify-between">
          <span className="text-slate-400">ICRS RA</span>
          <span className="text-slate-100">{formatRA(coordinate.ra)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">ICRS Dec</span>
          <span className="text-slate-100">{formatDec(coordinate.dec)}</span>
        </div>
        <div className="flex justify-between text-[11px] text-slate-400">
          <span>Decimal Deg</span>
          <span>{coordinate.ra.toFixed(5)}°, {coordinate.dec.toFixed(5)}°</span>
        </div>
        <div className="flex justify-between text-[11px] text-slate-400">
          <span>Galactic (l, b)</span>
          <span>{gal.l.toFixed(3)}°, {gal.b.toFixed(3)}°</span>
        </div>
        {coordinate.pixelX !== undefined && coordinate.pixelY !== undefined && (
          <div className="flex justify-between text-[11px] text-slate-400">
            <span>Image Pixel</span>
            <span>({coordinate.pixelX.toFixed(1)}, {coordinate.pixelY.toFixed(1)})</span>
          </div>
        )}
        {coordinate.surfaceBrightness !== undefined && coordinate.surfaceBrightness !== null && (
          <div className="flex justify-between text-[11px] text-cyan-300">
            <span>Pixel Intensity</span>
            <span>{coordinate.surfaceBrightness.toFixed(4)} {coordinate.units || ''}</span>
          </div>
        )}
      </div>

      <div className="mt-2.5 pt-2 border-t border-slate-800 text-[11px] text-slate-400">
        Source: {coordinate.coordinateSource || 'TAN HiPS Sky Projection'}
      </div>

      <div className="grid grid-cols-2 gap-1.5 mt-3">
        {onSearchArchives && (
          <button
            type="button"
            onClick={() => onSearchArchives(coordinate.ra, coordinate.dec)}
            className="px-2.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium rounded text-[11px] cursor-pointer"
          >
            Search Archives
          </button>
        )}
        {onInspectSpectrum && (
          <button
            type="button"
            onClick={() => onInspectSpectrum(coordinate.ra, coordinate.dec)}
            className="px-2.5 py-1.5 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded text-[11px] flex items-center justify-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>102-Ch Spec</span>
          </button>
        )}
        <button
          type="button"
          onClick={handleCopy}
          className="col-span-2 px-2.5 py-1.5 border border-slate-800 hover:border-slate-600 text-slate-300 rounded text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
        >
          {copied ? <Check className="w-3 h-3 text-cyan-400" /> : <Copy className="w-3 h-3" />}
          <span>{copied ? 'Copied Coordinates' : 'Copy ICRS Position'}</span>
        </button>
      </div>
    </div>
  );
};
