import React from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  ZoomIn,
  ZoomOut,
  Maximize,
  RotateCcw,
  Layers,
  SlidersHorizontal,
  ShieldCheck,
  Minimize,
  Download,
} from 'lucide-react';
import { HIPS_SURVEY_OPTIONS } from '../utils/spherexData';

interface BottomToolbarProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepBackward: () => void;
  onStepForward: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitSky: () => void;
  onResetView: () => void;
  zoomFactor: number;
  hipsSurvey: string;
  onChangeHipsSurvey: (surveyId: string) => void;
  isLayersOpen: boolean;
  onToggleLayers: () => void;
  activeLayerCount: number;
  isInfraredAdjustOpen: boolean;
  onToggleInfraredAdjust: () => void;
  isQualityOpen: boolean;
  onToggleQuality: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  canNavigateObservations: boolean;
  canPlayObservations: boolean;
  onDownloadPngSnapshot: () => void;
  hasCutoutLoaded: boolean;
  fitsDownloadUrl: string | null;
}

const btn =
  'inline-flex items-center justify-center gap-1.5 h-8 px-2.5 rounded border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-500/70 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap shrink-0 cursor-pointer text-xs';
const activeBtn = 'border-cyan-500 bg-cyan-950/60 text-cyan-200';

export const BottomToolbar: React.FC<BottomToolbarProps> = (p) => (
  <footer
    aria-label="Sky viewer toolbar"
    className="relative z-40 shrink-0 w-full border-t border-slate-800 bg-[#090d16] px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
  >
    {/* Left: Real Archive Epoch Playback + HiPS Survey */}
    <div className="flex items-center gap-1.5">
      <button
        type="button"
        className={btn}
        disabled={!p.canNavigateObservations}
        onClick={p.onStepBackward}
        aria-label="Previous observation epoch"
        title="Previous observation epoch ([)"
      >
        <SkipBack size={14} />
        <span className="hidden sm:inline">Prev</span>
      </button>
      <button
        type="button"
        className={`${btn} ${p.isPlaying ? activeBtn : ''}`}
        disabled={!p.canPlayObservations}
        onClick={p.onTogglePlay}
        aria-label={p.isPlaying ? 'Pause observation playback' : 'Play observation playback'}
        title="Play / Pause epoch sequence (Space)"
      >
        {p.isPlaying ? <Pause size={14} /> : <Play size={14} />}
        <span>{p.isPlaying ? 'Pause' : 'Play'}</span>
      </button>
      <button
        type="button"
        className={btn}
        disabled={!p.canNavigateObservations}
        onClick={p.onStepForward}
        aria-label="Next observation epoch"
        title="Next observation epoch (])"
      >
        <SkipForward size={14} />
        <span className="hidden sm:inline">Next</span>
      </button>

      <select
        aria-label="Background HiPS survey"
        value={p.hipsSurvey}
        onChange={(e) => p.onChangeHipsSurvey(e.target.value)}
        className="h-8 ml-1 px-2 rounded border border-slate-700 bg-slate-900 text-slate-200 text-xs focus:outline-none focus:border-cyan-500 cursor-pointer"
      >
        {HIPS_SURVEY_OPTIONS.map((opt) => (
          <option key={opt.id} value={opt.id}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>

    {/* Center: Zoom & Projection Controls */}
    <div className="flex items-center gap-1.5">
      <button type="button" className={btn} onClick={p.onZoomOut} aria-label="Zoom out" title="Zoom out (-)">
        <ZoomOut size={14} />
      </button>
      <span className="min-w-12 text-center font-mono text-[11px] text-slate-300 tabular-nums">
        {Math.round(p.zoomFactor * 100)}%
      </span>
      <button type="button" className={btn} onClick={p.onZoomIn} aria-label="Zoom in" title="Zoom in (+)">
        <ZoomIn size={14} />
      </button>
      <button type="button" className={btn} onClick={p.onFitSky} aria-label="Center on target" title="Center on target (F)">
        <Maximize size={14} />
        <span className="hidden md:inline">Center</span>
      </button>
      <button type="button" className={btn} onClick={p.onResetView} aria-label="Reset zoom and clear selection" title="Reset zoom and clear selection">
        <RotateCcw size={14} />
        <span className="hidden md:inline">Reset</span>
      </button>
    </div>

    {/* Right: Overlays, FITS Display, Quality, Export */}
    <div className="flex items-center gap-1.5">
      <button
        type="button"
        className={`${btn} ${p.isLayersOpen ? activeBtn : ''}`}
        onClick={p.onToggleLayers}
      >
        <Layers size={14} />
        <span>Layers ({p.activeLayerCount})</span>
      </button>
      <button
        type="button"
        className={`${btn} ${p.isInfraredAdjustOpen ? activeBtn : ''}`}
        onClick={p.onToggleInfraredAdjust}
        aria-label="Adjust infrared image stretch"
      >
        <SlidersHorizontal size={14} />
        <span>Stretch</span>
      </button>
      <button
        type="button"
        className={`${btn} ${p.isQualityOpen ? activeBtn : ''}`}
        onClick={p.onToggleQuality}
        aria-label="Open scientific quality inspection"
      >
        <ShieldCheck size={14} />
        <span className="hidden sm:inline">Quality</span>
      </button>
      <button
        type="button"
        className={btn}
        onClick={p.onDownloadPngSnapshot}
        aria-label="Export sky view as PNG"
        title="Export PNG sky view"
      >
        <Download size={14} />
        <span className="hidden lg:inline">PNG</span>
      </button>
      {p.hasCutoutLoaded && p.fitsDownloadUrl && (
        <a
          href={p.fitsDownloadUrl}
          download="spherex_cutout_wcs.fits"
          className={btn}
          title="Export calibrated FITS cutout with WCS and provenance"
        >
          <Download size={14} />
          <span>FITS</span>
        </a>
      )}
      <button
        type="button"
        className={btn}
        onClick={p.onToggleFullscreen}
        aria-label={p.isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
      >
        {p.isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
      </button>
    </div>
  </footer>
);
