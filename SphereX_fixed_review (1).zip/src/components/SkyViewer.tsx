import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArchiveObservation,
  GaiaSourceRecord,
  LayerItem,
  MovingObjectCandidate,
  ProperMotionResult,
  SkyCoordinate,
} from '../types';
import {
  equatorialToGalactic,
  formatDec,
  formatRA,
  galacticToEquatorial,
  gnomonicProject,
  gnomonicUnproject,
} from '../utils/coordinates';
import { radecToHealpixTileAndUV } from '../utils/healpix';

interface SkyViewerProps {
  layers: LayerItem[];
  zoomFactor: number;
  panOffset: { x: number; y: number };
  onPanChange: (offset: { x: number; y: number } | ((prev: { x: number; y: number }) => { x: number; y: number })) => void;
  centerRA: number;
  centerDec: number;
  fovDeg: number;
  onRecenter?: (ra: number, dec: number) => void;
  selectedCoordinate: SkyCoordinate | null;
  onSelectCoordinate: (coord: SkyCoordinate | null) => void;
  onZoomChange?: (zoom: number) => void;
  hipsSurvey: string;
  imageSrc?: string | null;
  onImageLoaded?: () => void;
  onImageError?: () => void;
  imageError?: string | null;
  isImageLoading?: boolean;
  imageFilter?: string;
  observations?: ArchiveObservation[];
  gaiaSources?: GaiaSourceRecord[];
  properMotion?: ProperMotionResult | null;
  candidates?: MovingObjectCandidate[];
  onCanvasPixelClick?: (normX: number, normY: number, naturalWidth: number, naturalHeight: number) => void;
  activeObservationLabel?: string | null;
}

const tileCache = new Map<string, ImageData | 'loading' | 'error'>();

export const SkyViewer: React.FC<SkyViewerProps> = ({
  layers,
  zoomFactor,
  panOffset,
  onPanChange,
  centerRA,
  centerDec,
  fovDeg,
  selectedCoordinate,
  onSelectCoordinate,
  onZoomChange,
  hipsSurvey,
  imageSrc,
  onImageLoaded,
  onImageError,
  imageError,
  isImageLoading,
  imageFilter,
  observations = [],
  gaiaSources = [],
  properMotion = null,
  candidates = [],
  onCanvasPixelClick,
  activeObservationLabel,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const cutoutImgRef = useRef<HTMLImageElement>(null);
  const dragRef = useRef<{ x: number; y: number; panX: number; panY: number; moved: boolean } | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [viewportSize, setViewportSize] = useState({ width: 960, height: 600 });
  const [hoverSky, setHoverSky] = useState<{ ra: number; dec: number; l: number; b: number } | null>(null);
  const [tileVersion, setTileVersion] = useState(0);

  const effectiveFovDeg = useMemo(() => Math.max(0.15, Math.min(45, fovDeg / Math.max(0.25, zoomFactor))), [fovDeg, zoomFactor]);
  const layerMap = useMemo(() => new Map(layers.map((l) => [l.id, l])), [layers]);

  // Adjust effective sky center when user pans without losing TAN geometry
  const effectiveCenter = useMemo(() => {
    if (Math.abs(panOffset.x) < 1 && Math.abs(panOffset.y) < 1) {
      return { ra: centerRA, dec: centerDec };
    }
    const { width, height } = viewportSize;
    return gnomonicUnproject(
      width / 2 - panOffset.x,
      height / 2 - panOffset.y,
      centerRA,
      centerDec,
      effectiveFovDeg,
      width,
      height,
    );
  }, [centerRA, centerDec, panOffset, effectiveFovDeg, viewportSize]);

  // Track container dimensions
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new ResizeObserver(() => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) {
        setViewportSize({ width: Math.round(r.width), height: Math.round(r.height) });
      }
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Load visible IRSA HiPS background tiles and reproject onto bgCanvas
  useEffect(() => {
    const canvas = bgCanvasRef.current;
    if (!canvas) return;
    const { width, height } = viewportSize;
    // Render crisp downsampled raster (max ~480px) then upscale smoothly for instant fluid pan/zoom
    const step = width > 900 ? 3 : 2;
    const rw = Math.max(64, Math.floor(width / step));
    const rh = Math.max(64, Math.floor(height / step));
    canvas.width = rw;
    canvas.height = rh;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const maxOrder = hipsSurvey === 'spherex_cube' ? 5 : 6;
    const targetOrder = effectiveFovDeg > 14 ? 3 : effectiveFovDeg > 5 ? 4 : Math.min(maxOrder, 5);

    const neededTiles = new Set<number>();
    const imgData = ctx.createImageData(rw, rh);
    const out = imgData.data;

    let anyMissing = false;
    for (let py = 0; py < rh; py++) {
      for (let px = 0; px < rw; px++) {
        const sx = (px + 0.5) * step;
        const sy = (py + 0.5) * step;
        const { ra, dec } = gnomonicUnproject(sx, sy, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        const { npix, u, v } = radecToHealpixTileAndUV(ra, dec, targetOrder);
        const key = `${hipsSurvey}:${targetOrder}:${npix}`;
        const cached = tileCache.get(key);
        const idx = (py * rw + px) * 4;

        if (!cached) {
          neededTiles.add(npix);
          anyMissing = true;
          out[idx] = 8;
          out[idx + 1] = 12;
          out[idx + 2] = 20;
          out[idx + 3] = 255;
        } else if (cached === 'loading' || cached === 'error') {
          out[idx] = 8;
          out[idx + 1] = 12;
          out[idx + 2] = 20;
          out[idx + 3] = 255;
        } else {
          const srcIdx = (v * 512 + u) * 4;
          out[idx] = cached.data[srcIdx];
          out[idx + 1] = cached.data[srcIdx + 1];
          out[idx + 2] = cached.data[srcIdx + 2];
          out[idx + 3] = 255;
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);

    if (anyMissing) {
      neededTiles.forEach((npix) => {
        const key = `${hipsSurvey}:${targetOrder}:${npix}`;
        if (tileCache.has(key)) return;
        tileCache.set(key, 'loading');
        const img = new Image();
        img.crossOrigin = 'anonymous';
        const frameParam = hipsSurvey === 'spherex_cube' ? '&frame=0' : '';
        img.src = `/api/hips/${encodeURIComponent(hipsSurvey)}/tile?order=${targetOrder}&npix=${npix}${frameParam}`;
        img.onload = () => {
          const off = document.createElement('canvas');
          off.width = 512;
          off.height = 512;
          const octx = off.getContext('2d');
          if (octx) {
            octx.drawImage(img, 0, 0, 512, 512);
            tileCache.set(key, octx.getImageData(0, 0, 512, 512));
            setTileVersion((v) => v + 1);
          }
        };
        img.onerror = () => {
          tileCache.set(key, 'error');
        };
      });
    }
  }, [viewportSize, effectiveCenter, effectiveFovDeg, hipsSurvey, tileVersion]);

  // Draw calibrated TAN overlays (graticule, galactic plane, Gaia DR3, observations, proper motion, candidates)
  useEffect(() => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    const { width, height } = viewportSize;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const gridLayer = layerMap.get('coord_grid');
    if (gridLayer?.enabled && gridLayer?.available) {
      const stepDeg = effectiveFovDeg > 12 ? 5 : effectiveFovDeg > 4 ? 1 : effectiveFovDeg > 1 ? 0.5 : 0.1;
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.18)';
      ctx.lineWidth = 1;
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillStyle = 'rgba(148, 163, 184, 0.65)';

      const decMin = Math.max(-89, Math.floor((effectiveCenter.dec - effectiveFovDeg) / stepDeg) * stepDeg);
      const decMax = Math.min(89, Math.ceil((effectiveCenter.dec + effectiveFovDeg) / stepDeg) * stepDeg);
      const cosD = Math.max(0.2, Math.cos((effectiveCenter.dec * Math.PI) / 180));
      const raSpan = Math.min(60, effectiveFovDeg / cosD);
      const raStart = Math.floor((effectiveCenter.ra - raSpan) / stepDeg) * stepDeg;
      const raEnd = Math.ceil((effectiveCenter.ra + raSpan) / stepDeg) * stepDeg;

      // Dec parallels
      for (let dec = decMin; dec <= decMax + 1e-6; dec += stepDeg) {
        ctx.beginPath();
        let started = false;
        for (let ra = raStart; ra <= raEnd; ra += stepDeg / 4) {
          const pt = gnomonicProject(ra, dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
          if (!pt.visible) continue;
          if (!started) {
            ctx.moveTo(pt.x, pt.y);
            started = true;
          } else {
            ctx.lineTo(pt.x, pt.y);
          }
        }
        ctx.stroke();
        const labelPt = gnomonicProject(effectiveCenter.ra, dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (labelPt.visible && labelPt.y > 14 && labelPt.y < height - 14) {
          ctx.fillText(`${dec.toFixed(stepDeg < 1 ? 1 : 0)}°`, 8, labelPt.y - 3);
        }
      }

      // RA meridians
      for (let ra = raStart; ra <= raEnd + 1e-6; ra += stepDeg) {
        ctx.beginPath();
        let started = false;
        for (let dec = decMin; dec <= decMax; dec += stepDeg / 4) {
          const pt = gnomonicProject(ra, dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
          if (!pt.visible) continue;
          if (!started) {
            ctx.moveTo(pt.x, pt.y);
            started = true;
          } else {
            ctx.lineTo(pt.x, pt.y);
          }
        }
        ctx.stroke();
        const labelPt = gnomonicProject(ra, effectiveCenter.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (labelPt.visible && labelPt.x > 20 && labelPt.x < width - 40) {
          const norm = ((ra % 360) + 360) % 360;
          ctx.fillText(`${norm.toFixed(stepDeg < 1 ? 1 : 0)}°`, labelPt.x + 3, 14);
        }
      }
    }

    // Galactic plane (b = 0°)
    const galLayer = layerMap.get('galactic_plane');
    if (galLayer?.enabled && galLayer?.available) {
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
      ctx.setLineDash([5, 4]);
      ctx.lineWidth = 1.25;
      ctx.beginPath();
      let started = false;
      for (let l = 0; l <= 360; l += 2) {
        const eq = galacticToEquatorial(l, 0);
        const pt = gnomonicProject(eq.ra, eq.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (pt.visible && pt.x >= -100 && pt.x <= width + 100 && pt.y >= -100 && pt.y <= height + 100) {
          if (!started) {
            ctx.moveTo(pt.x, pt.y);
            started = true;
          } else {
            ctx.lineTo(pt.x, pt.y);
          }
        } else {
          started = false;
        }
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Observation search footprints
    const obsLayer = layerMap.get('spx_coverage_map');
    if (obsLayer?.enabled && observations.length > 0) {
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.7)';
      ctx.lineWidth = 1.2;
      observations.slice(0, 60).forEach((ob) => {
        if (ob.ra === null || ob.dec === null) return;
        const pt = gnomonicProject(ob.ra, ob.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (!pt.visible) return;
        ctx.strokeRect(pt.x - 8, pt.y - 8, 16, 16);
      });
    }

    // Gaia DR3 sources
    const gaiaLayer = layerMap.get('known_objects');
    if (gaiaLayer?.enabled && gaiaSources.length > 0) {
      gaiaSources.forEach((src) => {
        const pt = gnomonicProject(src.ra, src.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (!pt.visible || pt.x < 0 || pt.x > width || pt.y < 0 || pt.y > height) return;
        const gmag = src.phot_g_mean_mag ?? 18;
        const r = Math.max(2.5, Math.min(7, (22 - gmag) * 0.45));
        ctx.strokeStyle = '#22d3ee';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
        ctx.stroke();
      });
    }

    // Proper-motion trajectory
    const pmLayer = layerMap.get('observation_differences');
    if (pmLayer?.enabled && properMotion && properMotion.trajectory.length >= 2) {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      properMotion.trajectory.forEach((wp, i) => {
        const pt = gnomonicProject(wp.ra, wp.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
        if (!pt.visible) return;
        if (i === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      });
      ctx.stroke();
      const endPt = properMotion.trajectory[properMotion.trajectory.length - 1];
      const ep = gnomonicProject(endPt.ra, endPt.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
      if (ep.visible) {
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(ep.x, ep.y, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Moving object candidates
    const candLayer = layerMap.get('moving_candidates');
    if (candLayer?.enabled && candidates.length > 0) {
      candidates.forEach((cand) => {
        const dets = cand.detections || [];
        if (!dets.length) return;
        ctx.strokeStyle = '#fb7185';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        dets.forEach((d, idx) => {
          const pt = gnomonicProject(d.ra, d.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
          if (idx === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        });
        ctx.stroke();
      });
    }

    // Center reticle
    const cx = width / 2;
    const cy = height / 2;
    ctx.strokeStyle = 'rgba(226, 232, 240, 0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 10, cy);
    ctx.lineTo(cx - 3, cy);
    ctx.moveTo(cx + 3, cy);
    ctx.lineTo(cx + 10, cy);
    ctx.moveTo(cx, cy - 10);
    ctx.lineTo(cx, cy - 3);
    ctx.moveTo(cx, cy + 3);
    ctx.lineTo(cx, cy + 10);
    ctx.stroke();

    // Selected coordinate marker
    if (selectedCoordinate && !imageSrc) {
      const sel = gnomonicProject(selectedCoordinate.ra, selectedCoordinate.dec, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, width, height);
      if (sel.visible) {
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(sel.x, sel.y, 8, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }, [
    viewportSize,
    effectiveCenter,
    effectiveFovDeg,
    layerMap,
    observations,
    gaiaSources,
    properMotion,
    candidates,
    selectedCoordinate,
    imageSrc,
  ]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    dragRef.current = { x: e.clientX, y: e.clientY, panX: panOffset.x, panY: panOffset.y, moved: false };
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsPanning(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      const sky = gnomonicUnproject(px, py, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, rect.width, rect.height);
      const gal = equatorialToGalactic(sky.ra, sky.dec);
      setHoverSky({ ...sky, ...gal });
    }
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.x;
    const dy = e.clientY - dragRef.current.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) dragRef.current.moved = true;
    if (dragRef.current.moved) {
      onPanChange({ x: dragRef.current.panX + dx, y: dragRef.current.panY + dy });
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    dragRef.current = null;
    setIsPanning(false);
    if (!drag || drag.moved || !containerRef.current) return;

    const imgEl = cutoutImgRef.current;
    if (imageSrc && imgEl && imgEl.naturalWidth > 0 && onCanvasPixelClick) {
      const imgRect = imgEl.getBoundingClientRect();
      if (
        e.clientX >= imgRect.left &&
        e.clientX <= imgRect.right &&
        e.clientY >= imgRect.top &&
        e.clientY <= imgRect.bottom
      ) {
        const normX = (e.clientX - imgRect.left) / imgRect.width;
        const normY = (e.clientY - imgRect.top) / imgRect.height;
        onCanvasPixelClick(normX, normY, imgEl.naturalWidth, imgEl.naturalHeight);
        return;
      }
    }

    const rect = containerRef.current.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    const sky = gnomonicUnproject(px, py, effectiveCenter.ra, effectiveCenter.dec, effectiveFovDeg, rect.width, rect.height);
    onSelectCoordinate({
      ra: sky.ra,
      dec: sky.dec,
      isScientific: true,
      coordinateSource: 'TAN HiPS Sky Projection',
    });
  };

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (!onZoomChange) return;
    e.preventDefault();
    const next = e.deltaY < 0 ? zoomFactor * 1.15 : zoomFactor / 1.15;
    onZoomChange(Math.max(0.25, Math.min(8, Number(next.toFixed(2)))));
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => {
        dragRef.current = null;
        setIsPanning(false);
      }}
      onPointerLeave={() => setHoverSky(null)}
      className={`relative flex-1 min-w-0 h-full overflow-hidden bg-[#07090e] touch-none select-none ${
        isPanning ? 'cursor-grabbing' : 'cursor-crosshair'
      }`}
      aria-label="SphereX Interactive HiPS and FITS Sky Viewer"
    >
      {/* Real IRSA HiPS Sky Background Canvas */}
      <canvas
        id="spherex-viewer-canvas"
        ref={bgCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ imageRendering: 'auto', opacity: imageSrc ? 0.18 : 1 }}
      />

      {/* Loaded Calibrated FITS Cutout (Rendered Server-Side by Astropy) */}
      {imageSrc && (
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{
            transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomFactor})`,
            transformOrigin: '50% 50%',
          }}
        >
          <img
            ref={cutoutImgRef}
            id="spherex-viewer-image"
            src={imageSrc}
            onLoad={onImageLoaded}
            onError={onImageError}
            alt="Calibrated astronomical FITS cutout"
            referrerPolicy="no-referrer"
            className={`max-w-[92%] max-h-[92%] object-contain border border-cyan-500/40 ${imageError ? 'hidden' : ''}`}
            style={{ filter: imageFilter }}
          />
        </div>
      )}

      {/* Calibrated WCS TAN Overlays Canvas */}
      <canvas
        ref={overlayCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
      />

      {isImageLoading && !imageError && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/45 pointer-events-none">
          <div className="px-3 py-2 bg-[#0b101b] border border-slate-700 rounded text-xs text-cyan-200">
            Rendering real FITS cutout via Astropy WCS...
          </div>
        </div>
      )}
      {imageError && (
        <div role="status" className="absolute inset-0 z-10 flex items-center justify-center bg-black/60 pointer-events-none">
          <div className="max-w-sm px-4 py-3 bg-[#0b101b] border border-rose-900 rounded text-center text-xs text-rose-200">
            {imageError}
          </div>
        </div>
      )}

      {/* Quiet Sky HUD: Live Coordinate Readout */}
      <div className="absolute left-3 top-3 px-2.5 py-1.5 bg-[#090d16]/90 border border-slate-800 rounded text-[11px] pointer-events-none">
        <div className="font-mono text-slate-200 tabular-nums">
          Center: {formatRA(effectiveCenter.ra)} · {formatDec(effectiveCenter.dec)}
        </div>
        <div className="text-[10px] text-slate-400 mt-0.5 font-mono tabular-nums">
          FOV {effectiveFovDeg.toFixed(2)}° · {activeObservationLabel || `HiPS: ${hipsSurvey}`}
        </div>
      </div>

      {hoverSky && (
        <div className="absolute bottom-3 left-3 px-2.5 py-1 bg-[#090d16]/90 border border-slate-800 rounded font-mono text-[11px] text-cyan-300 tabular-nums pointer-events-none">
          Cursor RA {hoverSky.ra.toFixed(5)}° · Dec {hoverSky.dec.toFixed(5)}° (l {hoverSky.l.toFixed(2)}°, b {hoverSky.b.toFixed(2)}°)
        </div>
      )}
    </div>
  );
};
