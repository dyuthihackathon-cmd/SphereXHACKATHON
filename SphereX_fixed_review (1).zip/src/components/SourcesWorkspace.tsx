import React, { useEffect, useState } from 'react';
import { Star, Search, ArrowUpRight, Download, Loader2, AlertCircle, Crosshair } from 'lucide-react';
import { GaiaSourceRecord, ProperMotionResult } from '../types';
import { fetchPanstarrs, fetchTwomass, propagateProperMotion, searchGaiaSources } from '../services/spherexApi';
import { buildCsvDocument, downloadTextFile } from '../utils/exportHelpers';

interface SourcesWorkspaceProps {
  centerRA: number;
  centerDec: number;
  gaiaSources: GaiaSourceRecord[];
  onGaiaSourcesLoaded: (sources: GaiaSourceRecord[], pmResult?: ProperMotionResult | null) => void;
  onNavigateToCoord: (ra: number, dec: number) => void;
}

export const SourcesWorkspace: React.FC<SourcesWorkspaceProps> = ({
  centerRA,
  centerDec,
  gaiaSources,
  onGaiaSourcesLoaded,
  onNavigateToCoord,
}) => {
  const [tab, setTab] = useState<'gaia' | 'panstarrs' | 'twomass'>('gaia');
  const [ra, setRa] = useState(String(centerRA));
  const [dec, setDec] = useState(String(centerDec));
  const [radiusArcmin, setRadiusArcmin] = useState('2.0');
  const [maxGMag, setMaxGMag] = useState('');
  const [targetEpoch, setTargetEpoch] = useState('2026.0');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [endpointNote, setEndpointNote] = useState('');
  const [selectedSource, setSelectedSource] = useState<GaiaSourceRecord | null>(null);
  const [pmResult, setPmResult] = useState<ProperMotionResult | null>(null);
  const [pmLoading, setPmLoading] = useState(false);

  const [psResult, setPsResult] = useState<any | null>(null);
  const [tmResult, setTmResult] = useState<any | null>(null);

  useEffect(() => {
    setRa(String(centerRA));
    setDec(String(centerDec));
  }, [centerRA, centerDec]);

  const handleGaiaSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await searchGaiaSources({
        ra: Number(ra),
        dec: Number(dec),
        radiusArcmin: Number(radiusArcmin),
        limit: 150,
        maxGMag: maxGMag ? Number(maxGMag) : undefined,
      });
      setEndpointNote(`${res.tap_endpoint_used} • Reference Epoch J${res.ref_epoch}`);
      onGaiaSourcesLoaded(res.sources, pmResult);
      if (res.sources.length > 0) setSelectedSource(res.sources[0]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gaia DR3 cone search failed.');
    } finally {
      setLoading(false);
    }
  };

  const handlePropagate = async (src: GaiaSourceRecord) => {
    setSelectedSource(src);
    setPmLoading(true);
    setError(null);
    try {
      const res = await propagateProperMotion({
        source_id: src.source_id,
        ra: src.ra,
        dec: src.dec,
        pmra: src.pmra,
        pmdec: src.pmdec,
        parallax: src.parallax,
        radial_velocity: src.radial_velocity,
        ref_epoch: src.ref_epoch || 2016.0,
        target_epoch_year: Number(targetEpoch),
        ra_error_mas: src.ra_error,
        dec_error_mas: src.dec_error,
        pmra_error: src.pmra_error,
        pmdec_error: src.pmdec_error,
      });
      setPmResult(res);
      onGaiaSourcesLoaded(gaiaSources, res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Proper motion propagation failed.');
    } finally {
      setPmLoading(false);
    }
  };

  const runPanstarrs = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchPanstarrs(Number(ra), Number(dec), Number(radiusArcmin));
      setPsResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Pan-STARRS DR2 query failed.');
    } finally {
      setLoading(false);
    }
  };

  const runTwomass = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchTwomass(Number(ra), Number(dec), Number(radiusArcmin));
      setTmResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : '2MASS PSC query failed.');
    } finally {
      setLoading(false);
    }
  };

  const exportGaiaCsv = () => {
    const csv = buildCsvDocument(
      ['source_id', 'ra', 'dec', 'ref_epoch', 'parallax', 'pmra', 'pmdec', 'phot_g_mean_mag', 'phot_bp_mean_mag', 'phot_rp_mean_mag', 'ruwe'],
      gaiaSources.map((s) => ({
        source_id: s.source_id,
        ra: s.ra,
        dec: s.dec,
        ref_epoch: s.ref_epoch,
        parallax: s.parallax ?? '',
        pmra: s.pmra ?? '',
        pmdec: s.pmdec ?? '',
        phot_g_mean_mag: s.phot_g_mean_mag ?? '',
        phot_bp_mean_mag: s.phot_bp_mean_mag ?? '',
        phot_rp_mean_mag: s.phot_rp_mean_mag ?? '',
        ruwe: s.ruwe ?? '',
      })),
      undefined,
      ['ESA Gaia DR3 ICRS sources', endpointNote],
    );
    downloadTextFile(`gaia_dr3_${Number(ra).toFixed(3)}_${Number(dec).toFixed(3)}.csv`, csv, 'text/csv;charset=utf-8;');
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-800 bg-[#0b101b] flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Star className="w-4 h-4 text-cyan-400" />
            Sources, Gaia DR3 Astrometry & Multi-Epoch Proper Motion
          </h2>
          <p className="text-[11px] text-slate-400">
            Live ESA/ARI Gaia DR3 TAP cone search with rigorous Astropy `apply_space_motion` propagation plus Pan-STARRS DR2 & 2MASS PSC cross-matches.
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          {(['gaia', 'panstarrs', 'twomass'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                tab === t
                  ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40'
                  : 'bg-[#090d16] text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {t === 'gaia' ? 'Gaia DR3 + PM' : t === 'panstarrs' ? 'Pan-STARRS DR2' : '2MASS PSC'}
            </button>
          ))}
        </div>
      </div>

      {/* Cone query bar */}
      <form
        onSubmit={handleGaiaSearch}
        className="px-5 py-2.5 border-b border-slate-800 bg-[#090d16] flex flex-wrap items-end gap-2.5 text-xs"
      >
        <div>
          <label className="block text-[10px] text-slate-500 uppercase">RA (deg)</label>
          <input value={ra} onChange={(e) => setRa(e.target.value)} className="w-28 px-2 py-1 rounded bg-[#0b101b] border border-slate-800 font-mono" />
        </div>
        <div>
          <label className="block text-[10px] text-slate-500 uppercase">Dec (deg)</label>
          <input value={dec} onChange={(e) => setDec(e.target.value)} className="w-28 px-2 py-1 rounded bg-[#0b101b] border border-slate-800 font-mono" />
        </div>
        <div>
          <label className="block text-[10px] text-slate-500 uppercase">Radius (arcmin)</label>
          <input value={radiusArcmin} onChange={(e) => setRadiusArcmin(e.target.value)} className="w-24 px-2 py-1 rounded bg-[#0b101b] border border-slate-800 font-mono" />
        </div>
        <div>
          <label className="block text-[10px] text-slate-500 uppercase">Max G mag</label>
          <input
            value={maxGMag}
            onChange={(e) => setMaxGMag(e.target.value)}
            placeholder="All"
            className="w-20 px-2 py-1 rounded bg-[#0b101b] border border-slate-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-[10px] text-slate-500 uppercase">Target Epoch</label>
          <input value={targetEpoch} onChange={(e) => setTargetEpoch(e.target.value)} className="w-24 px-2 py-1 rounded bg-[#0b101b] border border-slate-800 font-mono" />
        </div>

        {tab === 'gaia' ? (
          <button
            type="submit"
            disabled={loading}
            className="px-3.5 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            Query Gaia DR3
          </button>
        ) : tab === 'panstarrs' ? (
          <button
            type="button"
            disabled={loading}
            onClick={runPanstarrs}
            className="px-3.5 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            Query MAST Pan-STARRS DR2
          </button>
        ) : (
          <button
            type="button"
            disabled={loading}
            onClick={runTwomass}
            className="px-3.5 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            Query IRSA 2MASS PSC
          </button>
        )}

        {tab === 'gaia' && gaiaSources.length > 0 && (
          <button
            type="button"
            onClick={exportGaiaCsv}
            className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 hover:bg-slate-800 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5" /> CSV
          </button>
        )}
      </form>

      {error && (
        <div className="mx-5 mt-3 p-3 rounded bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto p-5 space-y-4">
        {tab === 'gaia' && (
          <>
            {pmResult && (
              <div className="rounded border border-amber-500/40 bg-amber-950/20 p-4 text-xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-amber-400">
                      Proper Motion Propagation (Astropy SkyCoord.apply_space_motion)
                    </div>
                    <div className="text-sm font-semibold text-white font-mono mt-0.5">
                      Gaia DR3 {pmResult.source_id} : J{pmResult.reference_epoch} → J{pmResult.target_epoch} (Δt = {pmResult.time_interval_years.toFixed(2)} yr)
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateToCoord(pmResult.propagated_icrs.ra, pmResult.propagated_icrs.dec)}
                    className="px-3 py-1.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-200 hover:bg-amber-500/30 flex items-center gap-1"
                  >
                    <Crosshair className="w-3.5 h-3.5" /> Center Sky Viewer on Propagated Epoch
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono">
                  <div className="bg-[#090d16] border border-slate-800 rounded p-2">
                    <div className="text-[10px] text-slate-500">Origin J{pmResult.reference_epoch}</div>
                    <div>{pmResult.original_icrs.ra.toFixed(6)}°, {pmResult.original_icrs.dec.toFixed(6)}°</div>
                  </div>
                  <div className="bg-[#090d16] border border-slate-800 rounded p-2">
                    <div className="text-[10px] text-slate-500">Propagated J{pmResult.target_epoch}</div>
                    <div className="text-amber-300">{pmResult.propagated_icrs.ra.toFixed(6)}°, {pmResult.propagated_icrs.dec.toFixed(6)}°</div>
                  </div>
                  <div className="bg-[#090d16] border border-slate-800 rounded p-2">
                    <div className="text-[10px] text-slate-500">Total Sky Motion</div>
                    <div className="text-cyan-300">{pmResult.angular_displacement_arcsec.toFixed(3)}" @ PA {pmResult.position_angle_deg.toFixed(1)}°</div>
                  </div>
                  <div className="bg-[#090d16] border border-slate-800 rounded p-2">
                    <div className="text-[10px] text-slate-500">1σ Position Error</div>
                    <div>
                      {pmResult.propagated_icrs.ra_error_mas !== null
                        ? `${pmResult.propagated_icrs.ra_error_mas.toFixed(2)} / ${pmResult.propagated_icrs.dec_error_mas?.toFixed(2)} mas`
                        : 'Not available'}
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-300">
                  {pmResult.radial_velocity_note}
                  {pmResult.warnings?.map((w, i) => (
                    <span key={i} className="block text-amber-300 mt-1">• {w}</span>
                  ))}
                </div>
              </div>
            )}

            <div className="rounded border border-slate-800 bg-[#0b101b] overflow-x-auto">
              <div className="px-4 py-2 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>{gaiaSources.length} Gaia DR3 sources {endpointNote ? `(${endpointNote})` : ''}</span>
                {pmLoading && <span className="text-cyan-300 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Propagating epoch...</span>}
              </div>
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead className="bg-[#090d16] text-slate-400 text-[10px] uppercase">
                  <tr>
                    <th className="px-3 py-2 border-b border-slate-800">Gaia DR3 ID</th>
                    <th className="px-3 py-2 border-b border-slate-800">RA / Dec (J2016.0)</th>
                    <th className="px-3 py-2 border-b border-slate-800">G mag</th>
                    <th className="px-3 py-2 border-b border-slate-800">Parallax (mas)</th>
                    <th className="px-3 py-2 border-b border-slate-800">pmRA / pmDec (mas/yr)</th>
                    <th className="px-3 py-2 border-b border-slate-800">RUWE</th>
                    <th className="px-3 py-2 border-b border-slate-800 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {gaiaSources.map((s) => (
                    <tr
                      key={String(s.source_id)}
                      className={`hover:bg-slate-900/50 ${selectedSource?.source_id === s.source_id ? 'bg-cyan-950/20' : ''}`}
                    >
                      <td className="px-3 py-2 text-cyan-300">{s.source_id}</td>
                      <td className="px-3 py-2">{s.ra.toFixed(6)}, {s.dec.toFixed(6)}</td>
                      <td className="px-3 py-2">{s.phot_g_mean_mag !== null ? s.phot_g_mean_mag.toFixed(2) : 'N/A'}</td>
                      <td className="px-3 py-2">{s.parallax !== null ? s.parallax.toFixed(2) : 'N/A'}</td>
                      <td className="px-3 py-2">
                        {s.pmra !== null && s.pmdec !== null ? `${s.pmra.toFixed(1)} / ${s.pmdec.toFixed(1)}` : 'N/A'}
                      </td>
                      <td className="px-3 py-2">{s.ruwe !== null ? s.ruwe.toFixed(2) : 'N/A'}</td>
                      <td className="px-3 py-2 text-right">
                        <button
                          type="button"
                          onClick={() => handlePropagate(s)}
                          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-300 inline-flex items-center gap-1"
                        >
                          Propagate <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {gaiaSources.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-4 py-8 text-center text-slate-500 font-sans">
                        Run <strong>Query Gaia DR3</strong> above (try Barnard&apos;s Star RA=269.452, Dec=+4.693 to see &gt;10"/yr proper motion!).
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}

        {tab === 'panstarrs' && (
          <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-3">
            {psResult ? (
              <>
                <div className="text-xs text-slate-300">
                  {psResult.coverage_note} — <strong>{psResult.count}</strong> sources returned.
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead className="bg-[#090d16] text-slate-400 text-[10px]">
                      <tr>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">objID</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">RA</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">Dec</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">g</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">r</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">i</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">z</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">y</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70">
                      {(psResult.sources || []).map((row: any, i: number) => (
                        <tr key={i}>
                          <td className="px-2.5 py-1.5 text-cyan-300">{row.objID}</td>
                          <td className="px-2.5 py-1.5">{Number(row.raMean).toFixed(6)}</td>
                          <td className="px-2.5 py-1.5">{Number(row.decMean).toFixed(6)}</td>
                          <td className="px-2.5 py-1.5">{row.gMeanPSFMag > -90 ? Number(row.gMeanPSFMag).toFixed(2) : 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.rMeanPSFMag > -90 ? Number(row.rMeanPSFMag).toFixed(2) : 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.iMeanPSFMag > -90 ? Number(row.iMeanPSFMag).toFixed(2) : 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.zMeanPSFMag > -90 ? Number(row.zMeanPSFMag).toFixed(2) : 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.yMeanPSFMag > -90 ? Number(row.yMeanPSFMag).toFixed(2) : 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <p className="text-xs text-slate-400">Click <strong>Query MAST Pan-STARRS DR2</strong> (Dec &gt; −30° only) to load optical PSF magnitudes.</p>
            )}
          </div>
        )}

        {tab === 'twomass' && (
          <div className="rounded border border-slate-800 bg-[#0b101b] p-4 space-y-3">
            {tmResult ? (
              <>
                <div className="text-xs text-slate-300">2MASS All-Sky PSC — <strong>{tmResult.count}</strong> infrared sources returned.</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead className="bg-[#090d16] text-slate-400 text-[10px]">
                      <tr>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">2MASS Designation</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">RA / Dec</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">J mag</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">H mag</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">Ks mag</th>
                        <th className="px-2.5 py-1.5 border-b border-slate-800">ph_qual</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70">
                      {(tmResult.sources || []).map((row: any, i: number) => (
                        <tr key={i}>
                          <td className="px-2.5 py-1.5 text-amber-300">{row.designation}</td>
                          <td className="px-2.5 py-1.5">{Number(row.ra).toFixed(5)}, {Number(row.dec).toFixed(5)}</td>
                          <td className="px-2.5 py-1.5">{row.j_m ?? 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.h_m ?? 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.k_m ?? 'N/A'}</td>
                          <td className="px-2.5 py-1.5">{row.ph_qual ?? 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <p className="text-xs text-slate-400">Click <strong>Query IRSA 2MASS PSC</strong> for J/H/Ks NIR point-source magnitudes.</p>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
