import React, { useEffect, useState } from 'react';
import { Columns, Layers, Download, Loader2, AlertCircle, BookmarkPlus, SlidersHorizontal } from 'lucide-react';
import { ArchiveObservation } from '../types';
import { downloadDifferenceFits, getObservationPreviewUrl, runDifferenceAnalysis } from '../services/spherexApi';
import { PreviewImage } from './PreviewImage';

interface CompareWorkspaceProps {
  centerRA: number;
  centerDec: number;
  fovArcmin: number;
  observations: ArchiveObservation[];
  initialObsA?: ArchiveObservation | null;
  initialObsB?: ArchiveObservation | null;
  stretch: string;
  palette: string;
  onSaveResearch: (title: string, kind: 'comparison', summary: string, payload: unknown, prov?: any) => void;
}

export const CompareWorkspace: React.FC<CompareWorkspaceProps> = ({
  centerRA,
  centerDec,
  fovArcmin,
  observations,
  initialObsA,
  initialObsB,
  stretch,
  palette,
  onSaveResearch,
}) => {
  const [mode, setMode] = useState<'side-by-side' | 'swipe' | 'blink' | 'difference'>('side-by-side');
  const [obsAId, setObsAId] = useState<string>(initialObsA?.id || observations[0]?.id || '');
  const [obsBId, setObsBId] = useState<string>(initialObsB?.id || observations[1]?.id || observations[0]?.id || '');
  const [swipePct, setSwipePct] = useState(50);
  const [blinkShowB, setBlinkShowB] = useState(false);
  const [blinkPlaying, setBlinkPlaying] = useState(true);
  const [matchBackground, setMatchBackground] = useState(true);

  const [diffLoading, setDiffLoading] = useState(false);
  const [diffError, setDiffError] = useState<string | null>(null);
  const [diffResult, setDiffResult] = useState<any | null>(null);

  useEffect(() => {
    if (initialObsA) setObsAId(initialObsA.id);
    if (initialObsB) setObsBId(initialObsB.id);
  }, [initialObsA, initialObsB]);

  useEffect(() => {
    if (!obsAId && observations.length > 0) setObsAId(observations[0].id);
    if (!obsBId && observations.length > 1) setObsBId(observations[1].id);
  }, [observations, obsAId, obsBId]);

  useEffect(() => {
    if (mode !== 'blink' || !blinkPlaying) return;
    const id = window.setInterval(() => setBlinkShowB((v) => !v), 650);
    return () => window.clearInterval(id);
  }, [mode, blinkPlaying]);

  const obsA = observations.find((o) => o.id === obsAId) || observations[0] || null;
  const obsB = observations.find((o) => o.id === obsBId) || observations[1] || observations[0] || null;

  const urlA = obsA ? getObservationPreviewUrl(obsA, centerRA, centerDec, fovArcmin, { stretch, palette }) : '';
  const urlB = obsB ? getObservationPreviewUrl(obsB, centerRA, centerDec, fovArcmin, { stretch, palette }) : '';

  const buildComparePayload = () => {
    if (!obsA || !obsB) return null;
    const missionA = (obsA.mission || obsA.source || '').toLowerCase().includes('wise') ? 'wise' : 'spherex';
    const missionB = (obsB.mission || obsB.source || '').toLowerCase().includes('wise') ? 'wise' : 'spherex';
    return {
      access_url_a: obsA.access_url,
      access_url_b: obsB.access_url,
      mission_a: missionA,
      mission_b: missionB,
      ra: centerRA,
      dec: centerDec,
      fov_arcmin: fovArcmin,
      meta_a: {
        id: obsA.id,
        collection: obsA.collection,
        mission: obsA.mission || obsA.source,
        start_time: obsA.start_time,
        wavelength_min_m: obsA.wavelength_min_m,
        access_url: obsA.access_url,
      },
      meta_b: {
        id: obsB.id,
        collection: obsB.collection,
        mission: obsB.mission || obsB.source,
        start_time: obsB.start_time,
        wavelength_min_m: obsB.wavelength_min_m,
        access_url: obsB.access_url,
      },
      match_background: matchBackground,
    };
  };

  const handleRunDifference = async () => {
    const payload = buildComparePayload();
    if (!payload) return;
    setDiffLoading(true);
    setDiffError(null);
    try {
      const res = await runDifferenceAnalysis(payload);
      setDiffResult(res);
      setMode('difference');
    } catch (err) {
      setDiffError(err instanceof Error ? err.message : 'WCS difference analysis failed.');
    } finally {
      setDiffLoading(false);
    }
  };

  const handleDownloadFits = async () => {
    const payload = buildComparePayload();
    if (!payload) return;
    try {
      const blob = await downloadDifferenceFits(payload);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `spherex_diff_${obsA?.id || 'A'}_minus_${obsB?.id || 'B'}.fits`;
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      setDiffError(err instanceof Error ? err.message : 'Could not export difference FITS.');
    }
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-800 bg-[#0b101b] flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Columns className="w-4 h-4 text-cyan-400" />
            Compare Images & WCS Difference Imaging
          </h2>
          <p className="text-[11px] text-slate-400">
            Visual comparison (Side-by-Side, Swipe, Blink) & Astropy/Reproject WCS pixel-aligned difference (A − B) with variance propagation.
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {(['side-by-side', 'swipe', 'blink', 'difference'] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className={`px-3 py-1.5 rounded text-xs font-medium capitalize border transition-colors ${
                mode === m
                  ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40'
                  : 'bg-[#090d16] text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {m.replace(/-/g, ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Observation Selectors */}
      <div className="px-5 py-2.5 border-b border-slate-800 bg-[#090d16] grid grid-cols-1 lg:grid-cols-12 gap-2.5 items-end text-xs">
        <div className="lg:col-span-4">
          <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1">Observation A (Reference / Epoch A)</label>
          <select
            value={obsAId}
            onChange={(e) => setObsAId(e.target.value)}
            className="w-full px-2.5 py-1.5 rounded bg-[#0b101b] border border-slate-800 text-slate-200 font-mono"
          >
            {observations.length === 0 && <option value="">No loaded observations — search Observations tab first</option>}
            {observations.map((o) => (
              <option key={o.id} value={o.id}>
                {o.id} | {o.collection} | {o.band || 'N/A'} | {o.start_time?.slice(0, 16) || 'Unknown'}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-4">
          <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1">Observation B (Target / Epoch B)</label>
          <select
            value={obsBId}
            onChange={(e) => setObsBId(e.target.value)}
            className="w-full px-2.5 py-1.5 rounded bg-[#0b101b] border border-slate-800 text-slate-200 font-mono"
          >
            {observations.length === 0 && <option value="">No loaded observations — search Observations tab first</option>}
            {observations.map((o) => (
              <option key={o.id} value={o.id}>
                {o.id} | {o.collection} | {o.band || 'N/A'} | {o.start_time?.slice(0, 16) || 'Unknown'}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-4 flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer mr-2">
            <input
              type="checkbox"
              checked={matchBackground}
              onChange={(e) => setMatchBackground(e.target.checked)}
              className="accent-cyan-500"
            />
            Sigma-clipped bg match
          </label>
          <button
            type="button"
            disabled={!obsA || !obsB || diffLoading}
            onClick={handleRunDifference}
            className="px-3 py-1.5 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 font-medium disabled:opacity-40 flex items-center gap-1.5"
          >
            {diffLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Layers className="w-3.5 h-3.5" />}
            Compute A − B
          </button>
          <button
            type="button"
            disabled={!diffResult}
            onClick={handleDownloadFits}
            className="px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 disabled:opacity-40 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5" />
            FITS
          </button>
        </div>
      </div>

      {diffError && (
        <div className="mx-5 mt-3 p-3 rounded bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{diffError}</span>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto p-5">
        {observations.length === 0 ? (
          <div className="max-w-xl mx-auto mt-10 p-6 rounded border border-slate-800 bg-[#0b101b] text-center space-y-2 text-xs text-slate-400">
            <p className="text-slate-200 font-medium">No observations currently queued for comparison</p>
            <p>
              Query NASA/IPAC IRSA SPHEREx DR1/QR3 or WISE/AllWISE images in the <strong>Observations</strong> section first, then compare any two epochs or bands here.
            </p>
          </div>
        ) : mode === 'side-by-side' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[{ label: 'Observation A', obs: obsA, url: urlA }, { label: 'Observation B', obs: obsB, url: urlB }].map(({ label, obs, url }) => (
              <div key={label} className="rounded border border-slate-800 bg-[#0b101b] p-3 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">{label}: <span className="font-mono text-cyan-300">{obs?.id}</span></span>
                  <span className="font-mono text-[11px] text-slate-400">{obs?.collection} • {obs?.band || 'Band N/A'}</span>
                </div>
                <div className="aspect-square bg-black rounded border border-slate-900 overflow-hidden flex items-center justify-center">
                  {url ? (
                    <PreviewImage src={url} alt={label} className="w-full h-full object-contain" />
                  ) : (
                    <span className="text-xs text-slate-500">No FITS preview URL</span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 font-mono flex justify-between">
                  <span>Obs time: {obs?.start_time || 'Unknown'}</span>
                  <span>FOV: {fovArcmin}'</span>
                </div>
              </div>
            ))}
          </div>
        ) : mode === 'swipe' ? (
          <div className="max-w-2xl mx-auto space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center gap-1.5"><SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" /> Left: <span className="font-mono text-cyan-300">{obsA?.id}</span></span>
              <span className="font-mono text-slate-400">{swipePct}%</span>
              <span>Right: <span className="font-mono text-amber-300">{obsB?.id}</span></span>
            </div>
            <div className="relative aspect-square bg-black rounded border border-slate-800 overflow-hidden">
              {urlB && <PreviewImage src={urlB} alt="Observation B" className="absolute inset-0 w-full h-full object-contain" />}
              {urlA && (
                <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - swipePct}% 0 0)` }}>
                  <PreviewImage src={urlA} alt="Observation A" className="w-full h-full object-contain" />
                </div>
              )}
              <div className="absolute top-0 bottom-0 w-0.5 bg-cyan-400 pointer-events-none" style={{ left: `${swipePct}%` }} />
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={swipePct}
              onChange={(e) => setSwipePct(Number(e.target.value))}
              aria-label="Swipe split percentage"
              className="w-full accent-cyan-400"
            />
          </div>
        ) : mode === 'blink' ? (
          <div className="max-w-2xl mx-auto space-y-3">
            <div className="flex items-center justify-between text-xs bg-[#0b101b] border border-slate-800 rounded px-3 py-2">
              <div className="font-mono">
                Showing: <span className={blinkShowB ? 'text-amber-300' : 'text-cyan-300'}>{blinkShowB ? `B (${obsB?.id})` : `A (${obsA?.id})`}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setBlinkPlaying((p) => !p)}
                  className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200 hover:bg-slate-800"
                >
                  {blinkPlaying ? 'Pause Blink' : 'Resume Blink'}
                </button>
                <button
                  type="button"
                  onClick={() => setBlinkShowB((v) => !v)}
                  className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200 hover:bg-slate-800"
                >
                  Step A/B
                </button>
              </div>
            </div>
            <div className="aspect-square bg-black rounded border border-slate-800 overflow-hidden flex items-center justify-center">
              <PreviewImage src={blinkShowB ? urlB : urlA} alt="Blink frame" className="w-full h-full object-contain" />
            </div>
          </div>
        ) : diffResult ? (
          <div className="space-y-4">
            {diffResult.warnings?.length > 0 && (
              <div className="p-3 rounded bg-amber-950/35 border border-amber-500/35 text-xs text-amber-200 space-y-1">
                {diffResult.warnings.map((w: string, idx: number) => (
                  <p key={idx}>• {w}</p>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="rounded border border-slate-800 bg-[#0b101b] p-3">
                <div className="text-xs font-semibold text-white mb-2">
                  WCS-Aligned Difference (A − B) [{diffResult.statistics?.bunit || 'MJy/sr'}]
                </div>
                <div className="aspect-square bg-black rounded border border-slate-900 overflow-hidden flex items-center justify-center">
                  <img
                    src={`data:image/png;base64,${diffResult.difference_png_base64}`}
                    alt="Difference image"
                    className="w-full h-full object-contain"
                  />
                </div>
              </div>

              <div className="rounded border border-slate-800 bg-[#0b101b] p-3 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-semibold text-white mb-2">
                    Propagated Significance Map (ΔFlux / √(Var_A + Var_B))
                  </div>
                  {diffResult.significance_png_base64 ? (
                    <div className="aspect-square bg-black rounded border border-slate-900 overflow-hidden flex items-center justify-center">
                      <img
                        src={`data:image/png;base64,${diffResult.significance_png_base64}`}
                        alt="Significance map"
                        className="w-full h-full object-contain"
                      />
                    </div>
                  ) : (
                    <div className="aspect-square bg-[#060911] rounded border border-slate-800 flex items-center justify-center p-6 text-center text-xs text-slate-400">
                      Not available — one or both input FITS files lack a calibrated VARIANCE extension, so significance is never fabricated.
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="rounded border border-slate-800 bg-[#0b101b] p-3 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
              <div>
                <div className="text-[10px] text-slate-500">WCS Overlap</div>
                <div className="text-slate-100">{(diffResult.registration.overlap_fraction * 100).toFixed(1)}%</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">Bg Offset Applied</div>
                <div className="text-slate-100">{diffResult.registration.background_offset_applied.toExponential(3)}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">Diff RMS</div>
                <div className="text-slate-100">{diffResult.statistics.diff_rms?.toExponential(3) ?? 'N/A'}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">Max |σ|</div>
                <div className="text-cyan-300">{diffResult.statistics.max_abs_significance_sigma?.toFixed(2) ?? 'Not available'}</div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() =>
                  onSaveResearch(
                    `Difference ${obsA?.id} - ${obsB?.id}`,
                    'comparison',
                    `Overlap ${(diffResult.registration.overlap_fraction * 100).toFixed(1)}%, RMS=${diffResult.statistics.diff_rms?.toExponential(2)}`,
                    diffResult,
                    diffResult.provenance,
                  )
                }
                className="px-3 py-1.5 rounded bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs flex items-center gap-1.5"
              >
                <BookmarkPlus className="w-3.5 h-3.5" /> Save Comparison to Research Ledger
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-lg mx-auto mt-10 p-6 rounded border border-slate-800 bg-[#0b101b] text-center text-xs text-slate-400">
            Click <strong>Compute A − B</strong> above to run WCS reprojection (`reproject_interp`), background matching, and variance-propagated subtraction on Observation A and B.
          </div>
        )}
      </div>
    </section>
  );
};
