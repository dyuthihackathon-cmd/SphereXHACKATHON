import React, { useEffect, useState } from 'react';

interface PreviewImageProps {
  src: string;
  alt: string;
  className?: string;
}

export const PreviewImage: React.FC<PreviewImageProps> = ({ src, alt, className = '' }) => {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);

  useEffect(() => {
    setFailedSrc(null);
  }, [src]);

  if (failedSrc === src) {
    return (
      <div
        role="status"
        className={`flex items-center justify-center bg-[#07090e] p-4 text-center text-xs text-slate-400 ${className}`}
      >
        Preview unavailable. Check the backend and archive connection.
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailedSrc(src)}
      className={className}
    />
  );
};
