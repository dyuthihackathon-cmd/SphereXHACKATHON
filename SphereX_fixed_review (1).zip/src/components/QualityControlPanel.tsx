import React from 'react';
import { ShieldCheck, X } from 'lucide-react';
import { FitsQualityInspection, ProvenanceRecord } from '../types';

interface QualityControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  inspection: FitsQualityInspection | null;
  provenance: ProvenanceRecord | null;
  loading: boolean;
  error: string | null;
}

export const QualityControlPanel: React.FC<QualityControlPanelProps> = ({
  isOpen,
  onClose,
  inspection,
  provenance,
  loading,
  error,
}) => {
  if (!isOpen) return null;

  return (
    <aside
      aria-label="Scientific Quality Control"
      className="fixed top-12 bottom-12 right-0 z-40 w-84 bg-[#090d16] border-l border-slate-800 flex flex-col text-xs"
    >
      <div className="h-10 px-3 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-1.5 font-medium text-slate-100">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>Scientific Quality Control</span>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close quality panel"
          className="text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {loading && (
          <div className="text-cyan-300 text-xs py-4">Inspecting real FITS headers, extensions, and variance map...</div>
        )}
        {error && (
          <div className="p-2.5 border border-rose-800 bg-rose-950/30 text-rose-200 rounded">{error}</div>
        )}
        {!loading && !error && !inspection && (
          <div className="text-slate-400 leading-relaxed">
            Load any SPHEREx or WISE FITS observation cutout to inspect MEF extensions, missing/NaN pixel fraction, quality flags, VARIANCE availability, and justified SNR.
          </div>
        )}

        {inspection && (
          <>
            <div className="space-y-1.5 font-mono tabular-nums">
              <div className="text-[11px] font-sans font-medium text-slate-300 pb-1 border-b border-slate-800">
                Pixel & Variance Statistics ({inspection.selected_extension})
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Dimensions</span>
                <span className="text-slate-100">{inspection.shape.join(' × ')} px</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Physical Units</span>
                <span className="text-slate-100">{inspection.bunit || 'Not specified'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Missing / NaN Pixels</span>
                <span className="text-slate-100">
                  {inspection.quality.nan_or_missing_pixels} ({(inspection.quality.missing_fraction * 100).toFixed(2)}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Non-zero FLAGS Pixels</span>
                <span className="text-slate-100">
                  {inspection.quality.flagged_pixels !== null ? inspection.quality.flagged_pixels : 'No FLAGS ext'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">VARIANCE Extension</span>
                <span className={inspection.quality.has_variance ? 'text-cyan-300' : 'text-amber-300'}>
                  {inspection.quality.has_variance ? 'Present' : 'Not available'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ZODI Model Extension</span>
                <span className="text-slate-200">{inspection.quality.has_zodi_model ? 'Present' : 'No'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Median Pixel SNR</span>
                <span className="text-slate-100">
                  {inspection.quality.median_snr !== null ? inspection.quality.median_snr.toFixed(2) : 'Not available'}
                </span>
              </div>
              <p className="font-sans text-[11px] text-slate-400 pt-1">{inspection.quality.snr_note}</p>
            </div>

            <div>
              <div className="text-[11px] font-medium text-slate-300 pb-1 border-b border-slate-800 mb-1.5">
                FITS MEF Extensions
              </div>
              <div className="space-y-1 font-mono text-[11px]">
                {inspection.extensions.map((ext) => (
                  <div key={ext.index} className="flex justify-between text-slate-300">
                    <span>#{ext.index} {ext.name}</span>
                    <span className="text-slate-400">{ext.dimensions.join('×')}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {provenance && (
          <div className="space-y-1 pt-2 border-t border-slate-800 text-[11px]">
            <div className="font-medium text-slate-300 mb-1">Active Product Provenance</div>
            <div className="text-slate-400">Provider: <span className="text-slate-200">{provenance.data_provider}</span></div>
            <div className="text-slate-400">Collection: <span className="text-slate-200 font-mono">{provenance.archive_collection}</span></div>
            <div className="text-slate-400 break-all">Obs ID: <span className="text-slate-200 font-mono">{provenance.source_or_obs_id}</span></div>
            <div className="text-slate-400">Wavelength: <span className="text-slate-200">{provenance.wavelength_or_filter}</span></div>
            <div className="text-slate-400">Retrieved: <span className="text-slate-200 font-mono">{provenance.retrieved_at_utc}</span></div>
          </div>
        )}
      </div>
    </aside>
  );
};
