import React from 'react';
import { SlidersHorizontal, RotateCcw, X } from 'lucide-react';
import { InfraredAdjustments } from '../types';

interface InfraredAdjustmentPanelProps {
  adjustments: InfraredAdjustments;
  onChangeAdjustments: React.Dispatch<React.SetStateAction<InfraredAdjustments>>;
  onReset: () => void;
  onClose: () => void;
  hasActiveCutout: boolean;
}

const STRETCHES: Array<InfraredAdjustments['stretch']> = ['linear', 'log', 'asinh', 'sqrt', 'zscale'];
const PALETTES: Array<{ id: InfraredAdjustments['palette']; label: string }> = [
  { id: 'monochrome', label: 'Greyscale' },
  { id: 'spherex_ir', label: 'SPHEREx False IR' },
  { id: 'cyan_amber', label: 'Cyan / Amber' },
  { id: 'plasma', label: 'Plasma' },
  { id: 'viridis', label: 'Viridis' },
];
const EXTENSIONS: Array<InfraredAdjustments['extName']> = ['IMAGE', 'VARIANCE', 'FLAGS', 'ZODI'];

export const InfraredAdjustmentPanel: React.FC<InfraredAdjustmentPanelProps> = ({
  adjustments,
  onChangeAdjustments,
  onReset,
  onClose,
  hasActiveCutout,
}) => {
  const update = <K extends keyof InfraredAdjustments>(key: K, val: InfraredAdjustments[K]) => {
    onChangeAdjustments((prev) => ({ ...prev, [key]: val }));
  };

  return (
    <div className="absolute bottom-14 right-3 z-40 w-80 bg-[#0b101b] border border-slate-800 rounded p-3 text-xs select-none max-h-[80vh] overflow-y-auto">
      <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-slate-800">
        <div className="flex items-center gap-1.5 font-medium text-slate-100">
          <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
          <span>FITS Display & Stretch</span>
        </div>
        <div className="flex items-center gap-2.5">
          <button type="button" onClick={onReset} className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white cursor-pointer">
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
          <button type="button" onClick={onClose} aria-label="Close infrared display panel" className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {!hasActiveCutout && (
        <div className="mb-3 p-2 border border-amber-800/60 bg-amber-950/20 text-amber-200 rounded text-[11px]">
          Load a FITS cutout from Observations to re-render server-side FITS pixels. Settings also apply to Spectral slices.
        </div>
      )}

      <div className="space-y-3">
        <div>
          <div className="text-[11px] text-slate-400 mb-1">FITS MEF Extension (SPHEREx L2)</div>
          <div className="grid grid-cols-4 gap-1 font-mono">
            {EXTENSIONS.map((ext) => (
              <button
                key={ext}
                type="button"
                onClick={() => update('extName', ext)}
                className={`py-1.5 px-1 text-[10px] rounded border cursor-pointer transition-colors ${
                  adjustments.extName === ext
                    ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {ext}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="text-[11px] text-slate-400 mb-1">Server-Side FITS Stretch</div>
          <div className="grid grid-cols-5 gap-1 font-mono">
            {STRETCHES.map((stretch) => (
              <button
                key={stretch}
                type="button"
                onClick={() => update('stretch', stretch)}
                className={`py-1.5 px-1 text-[10px] uppercase rounded border cursor-pointer transition-colors ${
                  adjustments.stretch === stretch
                    ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {stretch}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="text-[11px] text-slate-400 mb-1">Scientific Colormap</div>
          <div className="grid grid-cols-2 gap-1">
            {PALETTES.map((pal) => (
              <button
                key={pal.id}
                type="button"
                onClick={() => update('palette', pal.id)}
                className={`p-1.5 rounded border text-left text-[11px] cursor-pointer transition-colors ${
                  adjustments.palette === pal.id
                    ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {pal.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-0.5 font-mono tabular-nums">
              <span>Display Brightness</span>
              <span className="text-slate-200">{adjustments.brightness > 0 ? `+${adjustments.brightness}` : adjustments.brightness}</span>
            </div>
            <input
              type="range"
              min={-80}
              max={80}
              step={1}
              value={adjustments.brightness}
              onChange={(e) => update('brightness', Number(e.target.value))}
              className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded cursor-pointer"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-0.5 font-mono tabular-nums">
              <span>Display Contrast</span>
              <span className="text-slate-200">{adjustments.contrast.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={3.0}
              step={0.1}
              value={adjustments.contrast}
              onChange={(e) => update('contrast', Number(e.target.value))}
              className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
