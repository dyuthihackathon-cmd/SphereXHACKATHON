import React from 'react';
import { Search } from 'lucide-react';
import { ActiveWorkspace } from '../types';

interface TopNavigationProps {
  currentWorkspace: ActiveWorkspace;
  onSelectWorkspace: (workspace: ActiveWorkspace) => void;
  onToggleSearch: () => void;
}

const NAV_ITEMS: Array<{ id: ActiveWorkspace; label: string }> = [
  { id: 'sky', label: 'Sky Explorer' },
  { id: 'observations', label: 'Observations' },
  { id: 'spectral', label: 'Spectral Explorer' },
  { id: 'time-domain', label: 'Time Domain' },
  { id: 'compare', label: 'Compare Images' },
  { id: 'sources', label: 'Sources' },
  { id: 'moving-objects', label: 'Moving Objects' },
  { id: 'research', label: 'Research & Export' },
];

export const TopNavigation: React.FC<TopNavigationProps> = ({
  currentWorkspace,
  onSelectWorkspace,
  onToggleSearch,
}) => {
  return (
    <header className="h-12 border-b border-slate-800 bg-[#090d16] px-4 flex items-center justify-between gap-6 shrink-0 z-40">
      {/* Zone 1: Single-line Brand Wordmark */}
      <button
        type="button"
        onClick={() => onSelectWorkspace('sky')}
        className="flex items-center gap-2.5 whitespace-nowrap shrink-0 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-cyan-500 cursor-pointer"
      >
        <img
          src="/assets/aistudio/spherex-hero.webp"
          alt="SphereX"
          width={28}
          height={28}
          loading="lazy"
          decoding="async"
          className="w-7 h-7 rounded-full object-cover border border-slate-700 shrink-0"
        />
        <span className="text-sm font-semibold tracking-wide text-slate-100 whitespace-nowrap shrink-0">
          SphereX
        </span>
      </button>

      {/* Zone 2: Clean Typographic 8-Section Research Navigation */}
      <nav
        aria-label="Primary Workspaces"
        className="flex-1 min-w-0 flex items-center justify-start lg:justify-center gap-4 xl:gap-5 overflow-x-auto no-scrollbar"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = currentWorkspace === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectWorkspace(item.id)}
              className={`relative py-3 text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              {item.label}
              {isActive && (
                <span
                  aria-hidden="true"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400"
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Single Primary Action */}
      <div className="shrink-0">
        <button
          type="button"
          onClick={onToggleSearch}
          className="inline-flex items-center gap-2 h-8 px-3.5 text-xs font-medium bg-cyan-600 hover:bg-cyan-500 text-slate-950 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          title="Search sky coordinates or resolve target via SIMBAD/NED (/)"
        >
          <Search className="w-3.5 h-3.5 shrink-0" />
          <span>Target Search</span>
        </button>
      </div>
    </header>
  );
};
