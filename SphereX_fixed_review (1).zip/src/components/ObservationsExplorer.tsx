import React, { useEffect, useRef, useState } from 'react';
import {
  Database,
  Search,
  Eye,
  Download,
  ShieldCheck,
  AlertCircle,
  Loader2,
  BookmarkPlus,
} from 'lucide-react';
import { ArchiveObservation } from '../types';
import {
  getObservationFitsUrl,
  searchSpherexObservations,
  searchWiseImages,
  fetchZtfImages,
} from '../services/spherexApi';
import { formatAstroTime } from '../utils/timeControls';
import { buildCsvDocument, downloadJsonFile, downloadTextFile } from '../utils/exportHelpers';

interface ObservationsExplorerProps {
  centerRA: number;
  centerDec: number;
  onUpdateCenter: (ra: number, dec: number) => void;
  observations: ArchiveObservation[];
  onObservationsChange: (items: ArchiveObservation[], ra: number, dec: number, fovArcmin: number) => void;
  onLoadToSkyViewer: (obs: ArchiveObservation, index: number) => void;
  onInspectFits: (obs: ArchiveObservation) => void;
  onSendToCompare: (obsA: ArchiveObservation, obsB: ArchiveObservation) => void;
  onSaveResearch: (title: string, kind: 'observation', summary: string, payload: unknown) => void;
  timeFormat: 'UTC' | 'JD' | 'MJD';
}

const PAGE_SIZE = 20;

export const ObservationsExplorer: React.FC<ObservationsExplorerProps> = ({
  centerRA,
  centerDec,
  onUpdateCenter,
  observations,
  onObservationsChange,
  onLoadToSkyViewer,
  onInspectFits,
  onSendToCompare,
  onSaveResearch,
  timeFormat,
}) => {
  const [ra, setRa] = useState(String(centerRA));
  const [dec, setDec] = useState(String(centerDec));
  const [fovArcmin, setFovArcmin] = useState('6');
  const [missionScope, setMissionScope] = useState<'spherex' | 'wise' | 'ztf'>('spherex');
  const [spherexRelease, setSpherexRelease] = useState<'both' | 'dr1' | 'qr3'>('both');
  const [includeDeep, setIncludeDeep] = useState(false);
  const [wiseCollection, setWiseCollection] = useState('wise_allwise');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [limit, setLimit] = useState('100');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusNote, setStatusNote] = useState<string>('');
  const [archiveErrors, setArchiveErrors] = useState<string[]>([]);
  const [ztfInfo, setZtfInfo] = useState<any | null>(null);

  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    setRa(String(centerRA));
    setDec(String(centerDec));
  }, [centerRA, centerDec]);

  useEffect(() => {
    return () => abortRef.current?.abort();
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const raNum = Number(ra);
    const decNum = Number(dec);
    const fovNum = Number(fovArcmin);
    const limNum = Math.min(300, Math.max(1, Number(limit) || 100));

    if (!Number.isFinite(raNum) || raNum < 0 || raNum >= 360 || !Number.isFinite(decNum) || decNum < -90 || decNum > 90 || !Number.isFinite(fovNum) || fovNum <= 0) {
      setError('Invalid coordinates: RA must be [0, 360), Dec [-90, 90], FOV > 0.');
      return;
    }

    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    setLoading(true);
    setError(null);
    setArchiveErrors([]);
    setStatusNote('');
    setZtfInfo(null);
    setPage(1);
    onUpdateCenter(raNum, decNum);

    try {
      if (missionScope === 'spherex') {
        const res = await searchSpherexObservations(
          {
            ra: raNum,
            dec: decNum,
            fovArcmin: fovNum,
            release: spherexRelease,
            includeDeep,
            startDate: startDate || undefined,
            endDate: endDate || undefined,
            limit: limNum,
          },
          ctrl.signal,
        );
        onObservationsChange(res.observations, raNum, decNum, fovNum);
        setArchiveErrors(res.errors || []);
        setStatusNote(res.observations.length ? `${res.count} SPHEREx Level-2 observations retrieved.` : 'IRSA reported no SPHEREx coverage at this coordinate.');
      } else if (missionScope === 'wise') {
        const res = await searchWiseImages(
          {
            ra: raNum,
            dec: decNum,
            radiusArcmin: Math.max(1, fovNum / 2),
            collection: wiseCollection,
            limit: limNum,
          },
          ctrl.signal,
        );
        onObservationsChange(res.products, raNum, decNum, fovNum);
        setStatusNote(res.products.length ? `${res.count} ${wiseCollection} products retrieved.` : `No ${wiseCollection} image products found at this position.`);
      } else {
        const res = await fetchZtfImages(raNum, decNum, Math.max(1, fovNum / 2), ctrl.signal);
        setZtfInfo(res);
        setStatusNote(res.coverage_note || 'ZTF coverage check complete.');
        if (res.status === 'provider_unavailable') {
          setError(res.error || 'ZTF provider unavailable.');
        }
      }
    } catch (err) {
      if ((err as Error).name === 'AbortError') return;
      setError(err instanceof Error ? err.message : 'Archive search failed.');
    } finally {
      setLoading(false);
    }
  };

  const sortedObservations = [...observations].sort((a, b) => {
    const ma = a.start_mjd ?? 0;
    const mb = b.start_mjd ?? 0;
    return sortOrder === 'asc' ? ma - mb : mb - ma;
  });

  const totalPages = Math.max(1, Math.ceil(sortedObservations.length / PAGE_SIZE));
  const paged = sortedObservations.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const exportCsv = () => {
    const headers = ['id', 'mission', 'collection', 'start_time', 'start_mjd', 'ra', 'dec', 'instrument', 'wavelength_label', 'access_url'];
    const csv = buildCsvDocument(
      headers,
      sortedObservations as unknown as Array<Record<string, unknown>>,
      sortedObservations[0]?.provenance,
    );
    downloadTextFile(`spherex_observations_${centerRA.toFixed(3)}_${centerDec.toFixed(3)}.csv`, csv);
  };

  return (
    <section className="flex-1 min-h-0 flex flex-col bg-[#07090e] text-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-800 bg-[#090d16] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-slate-100">Multi-Wavelength Archive Explorer</h2>
          </div>

          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded text-xs">
            {[
              { id: 'spherex' as const, label: 'NASA SPHEREx L2' },
              { id: 'wise' as const, label: 'WISE / NEOWISE-R' },
              { id: 'ztf' as const, label: 'ZTF Coverage' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMissionScope(tab.id)}
                className={`px-3 py-1 rounded transition-colors cursor-pointer whitespace-nowrap ${
                  missionScope === tab.id ? 'bg-cyan-600 text-slate-950 font-medium' : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSearch} className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-xs">
          <label className="block">
            <span className="text-[11px] text-slate-400">RA (deg)</span>
            <input
              type="number"
              step="any"
              value={ra}
              onChange={(e) => setRa(e.target.value)}
              className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
              required
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-slate-400">Dec (deg)</span>
            <input
              type="number"
              step="any"
              value={dec}
              onChange={(e) => setDec(e.target.value)}
              className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
              required
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-slate-400">FOV (arcmin)</span>
            <input
              type="number"
              step="0.5"
              min="0.5"
              max="120"
              value={fovArcmin}
              onChange={(e) => setFovArcmin(e.target.value)}
              className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
              required
            />
          </label>

          {missionScope === 'spherex' && (
            <>
              <label className="block">
                <span className="text-[11px] text-slate-400">Release</span>
                <select
                  value={spherexRelease}
                  onChange={(e) => setSpherexRelease(e.target.value as 'both' | 'dr1' | 'qr3')}
                  className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-100"
                >
                  <option value="both">DR1 + QR3</option>
                  <option value="dr1">DR1 only</option>
                  <option value="qr3">QR3 only</option>
                </select>
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-400">Start Date</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-400">End Date</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
                />
              </label>
              <label className="flex items-center gap-2 self-end pb-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeDeep}
                  onChange={(e) => setIncludeDeep(e.target.checked)}
                  className="accent-cyan-500"
                />
                <span className="text-slate-300">Include Deep</span>
              </label>
            </>
          )}

          {missionScope === 'wise' && (
            <label className="block col-span-2">
              <span className="text-[11px] text-slate-400">WISE Collection</span>
              <select
                value={wiseCollection}
                onChange={(e) => setWiseCollection(e.target.value)}
                className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-slate-100"
              >
                <option value="wise_allwise">AllWISE Atlas Coadds</option>
                <option value="neowiser">NEOWISE-R Single Exposures</option>
                <option value="wise_allsky">WISE All-Sky 4-Band</option>
                <option value="wise_3band">WISE 3-Band Cryo</option>
                <option value="wise_postcryo">WISE Post-Cryo 2-Band</option>
              </select>
            </label>
          )}

          <label className="block">
            <span className="text-[11px] text-slate-400">Max Results</span>
            <input
              type="number"
              min="1"
              max="300"
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              className="mt-1 w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 font-mono text-slate-100"
            />
          </label>

          <button
            type="submit"
            disabled={loading}
            className="self-end h-8 px-4 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-medium rounded flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>{loading ? 'Querying...' : 'Query Archive'}</span>
          </button>
        </form>
      </div>

      {/* Results & Controls */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-3">
        {error && (
          <div className="p-3 border border-rose-800 bg-rose-950/30 rounded text-xs text-rose-200 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-medium">Provider unavailable / Query error</div>
              <div className="mt-0.5 text-rose-300">{error}</div>
            </div>
          </div>
        )}

        {archiveErrors.length > 0 && (
          <div className="p-2.5 border border-amber-800 bg-amber-950/30 rounded text-xs text-amber-200">
            Partial provider warnings: {archiveErrors.join(' | ')}
          </div>
        )}

        {statusNote && !error && (
          <div className="text-xs text-slate-400">{statusNote}</div>
        )}

        {ztfInfo && (
          <div className="border border-slate-800 rounded p-3 bg-[#0b101b] text-xs space-y-2">
            <div className="font-medium text-slate-100">ZTF Coverage Status: {ztfInfo.status}</div>
            <p className="text-slate-400">{ztfInfo.coverage_note}</p>
            {ztfInfo.dr24_hats_tiles_covering_position?.length > 0 && (
              <div className="font-mono text-[11px] text-cyan-300">
                DR24 HATS Object Tiles: {ztfInfo.dr24_hats_tiles_covering_position.join(', ')}
              </div>
            )}
          </div>
        )}

        {sortedObservations.length > 0 && (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-3">
                <span className="font-mono text-slate-300 tabular-nums">
                  {sortedObservations.length} observations
                </span>
                <button
                  type="button"
                  onClick={() => setSortOrder((s) => (s === 'asc' ? 'desc' : 'asc'))}
                  className="px-2.5 py-1 border border-slate-700 rounded text-slate-300 hover:text-white cursor-pointer"
                >
                  Sort Time: {sortOrder === 'asc' ? 'Oldest First' : 'Newest First'}
                </button>
                {sortedObservations.length >= 2 && (
                  <button
                    type="button"
                    onClick={() => onSendToCompare(sortedObservations[0], sortedObservations[1])}
                    className="px-2.5 py-1 border border-cyan-700 text-cyan-300 hover:bg-cyan-950/40 rounded cursor-pointer"
                  >
                    Compare First Two Epochs
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={exportCsv}
                  className="px-2.5 py-1 border border-slate-700 hover:border-slate-500 rounded text-slate-300 cursor-pointer flex items-center gap-1"
                >
                  <Download className="w-3 h-3" />
                  <span>CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => downloadJsonFile(`spherex_observations_${centerRA.toFixed(3)}.json`, sortedObservations)}
                  className="px-2.5 py-1 border border-slate-700 hover:border-slate-500 rounded text-slate-300 cursor-pointer"
                >
                  JSON
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onSaveResearch(
                      `Observation Search (${centerRA.toFixed(3)}, ${centerDec.toFixed(3)})`,
                      'observation',
                      `${sortedObservations.length} archive observations (${missionScope})`,
                      sortedObservations,
                    )
                  }
                  className="px-2.5 py-1 border border-slate-700 hover:border-cyan-500 rounded text-slate-300 cursor-pointer flex items-center gap-1"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Save</span>
                </button>
              </div>
            </div>

            <div className="border border-slate-800 rounded overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#090d16] text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2.5 font-medium">Observation ID</th>
                    <th className="p-2.5 font-medium">Collection</th>
                    <th className="p-2.5 font-medium">Timestamp ({timeFormat})</th>
                    <th className="p-2.5 font-medium">Wavelength / Band</th>
                    <th className="p-2.5 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {paged.map((obs, idx) => {
                    const globalIdx = (page - 1) * PAGE_SIZE + idx;
                    return (
                      <tr key={`${obs.id}-${globalIdx}`} className="hover:bg-slate-900/50">
                        <td className="p-2.5 font-mono text-slate-100 break-all max-w-xs">{obs.id}</td>
                        <td className="p-2.5 font-mono text-slate-300 whitespace-nowrap">{obs.collection}</td>
                        <td className="p-2.5 font-mono text-slate-300 tabular-nums whitespace-nowrap">
                          {formatAstroTime(obs.start_time, timeFormat)}
                        </td>
                        <td className="p-2.5 text-slate-300 whitespace-nowrap">
                          {(obs as any).wavelength_label || obs.band || 'Not available'}
                        </td>
                        <td className="p-2.5 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onLoadToSkyViewer(obs, globalIdx)}
                              className="px-2 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium rounded flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3 h-3" />
                              <span>View Cutout</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onInspectFits(obs)}
                              className="px-2 py-1 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded flex items-center gap-1 cursor-pointer"
                            >
                              <ShieldCheck className="w-3 h-3 text-cyan-400" />
                              <span>Quality</span>
                            </button>
                            <a
                              href={getObservationFitsUrl(obs, Number(ra), Number(dec), Number(fovArcmin))}
                              download
                              className="px-2 py-1 border border-slate-700 hover:border-slate-500 text-slate-300 rounded"
                            >
                              FITS
                            </a>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {totalPages > 1 && (
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <span>
                  Page {page} of {totalPages}
                </span>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    disabled={page <= 1}
                    onClick={() => setPage((p) => p - 1)}
                    className="px-3 py-1 border border-slate-700 rounded disabled:opacity-40 cursor-pointer"
                  >
                    Previous
                  </button>
                  <button
                    type="button"
                    disabled={page >= totalPages}
                    onClick={() => setPage((p) => p + 1)}
                    className="px-3 py-1 border border-slate-700 rounded disabled:opacity-40 cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
};
