import React, { useEffect, useState } from 'react';

interface IntroAnimationProps {
  onComplete: () => void;
}

export const IntroAnimation: React.FC<IntroAnimationProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState<'stars' | 'illuminate' | 'orbital' | 'title' | 'fadeout'>('stars');

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      onComplete();
      return;
    }

    const t1 = window.setTimeout(() => setPhase('illuminate'), 600);
    const t2 = window.setTimeout(() => setPhase('orbital'), 1400);
    const t3 = window.setTimeout(() => setPhase('title'), 2200);
    const t4 = window.setTimeout(() => setPhase('fadeout'), 3600);
    const t5 = window.setTimeout(() => onComplete(), 4100);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
      window.clearTimeout(t4);
      window.clearTimeout(t5);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#05070d] text-slate-100 transition-opacity duration-500 ${
        phase === 'fadeout' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      role="region"
      aria-label="SphereX Explorer Introduction"
    >
      <div className="relative flex items-center justify-center max-w-[85vw] max-h-[55vh] w-[580px] aspect-[3/2] px-4">
        <img
          src="/assets/aistudio/spherex-hero.webp"
          alt="SphereX Multi-Wavelength Time-Domain Observatory"
          width={800}
          height={533}
          fetchPriority="high"
          decoding="async"
          className={`relative z-10 w-full h-full object-contain rounded transition-all duration-1000 ${
            phase === 'stars'
              ? 'opacity-20 scale-95'
              : phase === 'illuminate'
              ? 'opacity-85 scale-100'
              : 'opacity-100 scale-100'
          }`}
        />
      </div>

      <div className="relative z-30 mt-5 text-center select-none">
        <h1 className="text-3xl md:text-4xl font-semibold tracking-[0.28em] uppercase text-white">
          SphereX
        </h1>
        <p className="mt-2 text-xs tracking-[0.35em] uppercase text-cyan-400">
          Multi-Wavelength Time-Domain Astronomy Explorer
        </p>
      </div>

      <button
        type="button"
        onClick={onComplete}
        className="mt-8 px-4 py-2 text-xs font-medium border border-slate-700 bg-slate-900/90 text-slate-200 hover:border-cyan-500 hover:text-white rounded transition-colors cursor-pointer"
      >
        Enter Observatory
      </button>
    </div>
  );
};
