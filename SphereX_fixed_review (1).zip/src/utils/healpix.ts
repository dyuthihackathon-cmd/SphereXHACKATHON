/**
 * Górski HEALPix NESTED projection utilities for IRSA HiPS tile reprojection onto TAN sky canvas.
 * Verified against astropy_healpix and IRSA HiPS tile orientation (M31 core alignment within 1 px).
 */

const DEG2RAD = Math.PI / 180;

export interface HealpixSample {
  npix: number;
  u: number; // column pixel inside 512x512 HiPS tile [0..511]
  v: number; // row pixel inside 512x512 HiPS tile [0..511]
}

export function radecToHealpixTileAndUV(raDeg: number, decDeg: number, order: number): HealpixSample {
  const totalOrder = order + 9; // 2^9 = 512 px per HiPS tile edge
  const nsideSub = 1 << totalOrder;
  const z = Math.sin(decDeg * DEG2RAD);
  const raNorm = ((raDeg % 360) + 360) % 360;
  const phi = raNorm * DEG2RAD;
  const tt = (phi / (Math.PI * 0.5)) % 4.0;
  const za = Math.abs(z);

  let face = 0;
  let ixSub = 0;
  let iySub = 0;

  if (za <= 2.0 / 3.0) {
    const temp1 = nsideSub * (0.5 + tt);
    const temp2 = nsideSub * (z * 0.75);
    const jp = Math.floor(temp1 - temp2);
    const jm = Math.floor(temp1 + temp2);
    const ifp = Math.floor(jp / nsideSub);
    const ifm = Math.floor(jm / nsideSub);
    if (ifp === ifm) {
      face = ifp | 4;
    } else if (ifp < ifm) {
      face = ifp;
    } else {
      face = ifm + 8;
    }
    ixSub = ((jm % nsideSub) + nsideSub) % nsideSub;
    iySub = nsideSub - 1 - (((jp % nsideSub) + nsideSub) % nsideSub);
  } else {
    const ntt = Math.min(3, Math.floor(tt));
    const tp = tt - ntt;
    const tmp = nsideSub * Math.sqrt(3.0 * Math.max(0, 1.0 - za));
    const jp = Math.min(nsideSub - 1, Math.max(0, Math.floor(tp * tmp)));
    const jm = Math.min(nsideSub - 1, Math.max(0, Math.floor((1.0 - tp) * tmp)));
    if (z >= 0) {
      face = ntt;
      ixSub = nsideSub - 1 - jm;
      iySub = nsideSub - 1 - jp;
    } else {
      face = ntt + 8;
      ixSub = jp;
      iySub = jm;
    }
  }

  const tx = ixSub >> 9;
  const ty = iySub >> 9;
  let pixInFace = 0;
  for (let b = 0; b < order; b++) {
    pixInFace |= ((tx >> b) & 1) << (2 * b);
    pixInFace |= ((ty >> b) & 1) << (2 * b + 1);
  }
  const npix = (face << (2 * order)) + pixInFace;

  return {
    npix,
    u: iySub & 511,
    v: ixSub & 511,
  };
}
