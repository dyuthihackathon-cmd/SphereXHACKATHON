import type { ProvenanceRecord } from '../types/index.ts';

/**
 * RFC-4180 compliant CSV cell escaping with formula-neutralization safety.
 */
export function escapeCsvCell(value: unknown): string {
  if (value === null || value === undefined) return '';
  let str = String(value);
  if (/^[=+\-@]/.test(str)) {
    str = `'${str}`;
  }
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function buildCsvDocument(
  headers: string[],
  rows: Array<Record<string, unknown>>,
  provenance?: ProvenanceRecord,
  extraComments?: string[],
): string {
  const comments: string[] = [];
  if (provenance) {
    comments.push(`# SphereX Scientific Export`);
    comments.push(`# Provider: ${provenance.data_provider}`);
    comments.push(`# Mission / Survey: ${provenance.mission_survey} (${provenance.data_release})`);
    comments.push(`# Collection: ${provenance.archive_collection}`);
    comments.push(`# Source / Obs ID: ${provenance.source_or_obs_id}`);
    comments.push(`# Units: ${provenance.units}`);
    comments.push(`# Archive URL: ${provenance.archive_url}`);
    comments.push(`# Processing: ${provenance.spherex_processing}`);
    comments.push(`# Retrieved UTC: ${provenance.retrieved_at_utc}`);
  }
  if (extraComments) {
    for (const line of extraComments) {
      comments.push(`# ${line}`);
    }
  }
  const csvRows = [
    headers.map(escapeCsvCell).join(','),
    ...rows.map((row) => headers.map((h) => escapeCsvCell(row[h])).join(',')),
  ];
  return [...comments, ...csvRows].join('\n');
}

export function downloadTextFile(filename: string, content: string, mimeType = 'text/csv;charset=utf-8;'): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } finally {
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

export function downloadJsonFile(filename: string, payload: unknown): void {
  downloadTextFile(filename, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8;');
}
