import test from 'node:test';
import assert from 'node:assert/strict';
import { generateSPHERExBands, SPHEREX_BANDS, getBandById, DEFAULT_LAYERS, BENCHMARK_TARGETS } from './spherexData.ts';
import { escapeCsvCell, buildCsvDocument } from './exportHelpers.ts';

test('spectral band metadata remains unfabricated in static utils', () => {
  assert.deepEqual(generateSPHERExBands(), []);
  assert.deepEqual(SPHEREX_BANDS, []);
  assert.equal(getBandById(1), undefined);
});

test('all layer categories are represented cleanly', () => {
  const categories = new Set(DEFAULT_LAYERS.map((l) => l.category));
  for (const category of ['observations', 'grid', 'galactic', 'known_objects', 'candidates', 'differences']) {
    assert.ok(categories.has(category as any));
  }
  assert.ok(BENCHMARK_TARGETS[0].label === 'WISE 0855');
});

test('escapeCsvCell and buildCsvDocument conform to RFC-4180 and preserve provenance', () => {
  assert.equal(escapeCsvCell('hello, "world"'), '"hello, ""world"""');
  assert.equal(escapeCsvCell('=CMD()'), "'=CMD()");
  const doc = buildCsvDocument(['colA', 'colB'], [{ colA: 'a,b', colB: 42 }]);
  assert.ok(doc.includes('"a,b",42'));
});
