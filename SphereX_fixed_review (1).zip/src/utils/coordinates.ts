/**
 * Astronomical coordinate utilities for SphereX
 * Provides RA/Dec sexagesimal conversions, galactic coordinates,
 * and true Gnomonic (TAN) sky projection helpers for interactive sky viewing.
 */

const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;

export function normalizeRA(degrees: number): number {
  return ((degrees % 360) + 360) % 360;
}

export function clampDec(degrees: number): number {
  return Math.max(-90, Math.min(90, degrees));
}

export function formatRA(degrees: number): string {
  if (!Number.isFinite(degrees)) return 'Not available';
  const normDeg = normalizeRA(degrees);
  // Round first in centiseconds so 23:59:59.999 correctly wraps to 00:00:00.00.
  const totalCentiseconds = Math.round((normDeg / 15) * 360000) % (24 * 360000);
  const hours = Math.floor(totalCentiseconds / 360000);
  const remainder = totalCentiseconds % 360000;
  const minutes = Math.floor(remainder / 6000);
  const seconds = (remainder % 6000) / 100;

  const hStr = hours.toString().padStart(2, '0');
  const mStr = minutes.toString().padStart(2, '0');
  const sStr = seconds.toFixed(2).padStart(5, '0');

  return `${hStr}h ${mStr}m ${sStr}s`;
}

export function formatDec(degrees: number): string {
  if (!Number.isFinite(degrees)) return 'Not available';
  const clamped = clampDec(degrees);
  const sign = clamped >= 0 ? '+' : '-';
  const absDeg = Math.abs(clamped);
  // Round in tenths of an arcsecond before splitting fields to avoid displaying 60.0 seconds.
  const totalTenthsArcsec = Math.round(absDeg * 36000);
  const deg = Math.floor(totalTenthsArcsec / 36000);
  const remainder = totalTenthsArcsec % 36000;
  const arcmin = Math.floor(remainder / 600);
  const arcsec = (remainder % 600) / 10;

  const dStr = deg.toString().padStart(2, '0');
  const mStr = arcmin.toString().padStart(2, '0');
  const sStr = arcsec.toFixed(1).padStart(4, '0');

  return `${sign}${dStr}° ${mStr}′ ${sStr}″`;
}

export function parseRA(input: string): number | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  const num = Number(trimmed);
  if (Number.isFinite(num)) {
    return normalizeRA(num);
  }

  const regex = /(\d{1,2})[h:\s]\s*(\d{1,2})[m:\s]\s*([\d.]+)s?/i;
  const match = trimmed.match(regex);
  if (match) {
    const h = parseFloat(match[1]);
    const m = parseFloat(match[2]);
    const s = parseFloat(match[3]);
    if (h >= 0 && h < 24 && m >= 0 && m < 60 && s >= 0 && s < 60) {
      return (h + m / 60 + s / 3600) * 15;
    }
  }
  return null;
}

export function parseDec(input: string): number | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  const num = Number(trimmed);
  if (Number.isFinite(num) && num >= -90 && num <= 90) {
    return num;
  }

  const regex = /([+-]?)(\d{1,2})[°d:\s]\s*(\d{1,2})[′'m:\s]\s*([\d.]+)[″"s]?/i;
  const match = trimmed.match(regex);
  if (match) {
    const sign = match[1] === '-' ? -1 : 1;
    const d = parseFloat(match[2]);
    const m = parseFloat(match[3]);
    const s = parseFloat(match[4]);
    const val = sign * (d + m / 60 + s / 3600);
    if (d <= 90 && m < 60 && s < 60 && val >= -90 && val <= 90) {
      return val;
    }
  }
  return null;
}

/**
 * Standard IAU J2000 equatorial (RA, Dec) to Galactic (l, b) conversion.
 */
export function equatorialToGalactic(raDeg: number, decDeg: number): { l: number; b: number } {
  const ra = raDeg * DEG2RAD;
  const dec = decDeg * DEG2RAD;

  const raG = 192.85948 * DEG2RAD;
  const decG = 27.12825 * DEG2RAD;
  const lCP = 122.93192 * DEG2RAD;

  const sinB = Math.sin(dec) * Math.sin(decG) + Math.cos(dec) * Math.cos(decG) * Math.cos(ra - raG);
  const b = Math.asin(Math.max(-1, Math.min(1, sinB)));

  const y = Math.cos(dec) * Math.sin(ra - raG);
  const x = Math.sin(dec) * Math.cos(decG) - Math.cos(dec) * Math.sin(decG) * Math.cos(ra - raG);
  const l = lCP - Math.atan2(y, x);

  return {
    l: Number(normalizeRA(l * RAD2DEG).toFixed(4)),
    b: Number((b * RAD2DEG).toFixed(4)),
  };
}

/**
 * Inverse Galactic (l, b) -> ICRS (ra, dec) for rendering the Galactic Plane curve.
 */
export function galacticToEquatorial(lDeg: number, bDeg: number): { ra: number; dec: number } {
  const l = lDeg * DEG2RAD;
  const b = bDeg * DEG2RAD;
  const raG = 192.85948 * DEG2RAD;
  const decG = 27.12825 * DEG2RAD;
  const lCP = 122.93192 * DEG2RAD;

  const sinDec = Math.sin(b) * Math.sin(decG) + Math.cos(b) * Math.cos(decG) * Math.cos(lCP - l);
  const dec = Math.asin(Math.max(-1, Math.min(1, sinDec)));
  const y = Math.cos(b) * Math.sin(lCP - l);
  const x = Math.sin(b) * Math.cos(decG) - Math.cos(b) * Math.sin(decG) * Math.cos(lCP - l);
  const ra = raG + Math.atan2(y, x);

  return {
    ra: normalizeRA(ra * RAD2DEG),
    dec: clampDec(dec * RAD2DEG),
  };
}

/**
 * True Gnomonic (TAN) projection from ICRS (RA, Dec) to canvas pixel (x, y).
 * Astronomical convention: North is up (-y), East (increasing RA) is left (-x).
 */
export function gnomonicProject(
  raDeg: number,
  decDeg: number,
  centerRA: number,
  centerDec: number,
  fovDeg: number,
  width: number,
  height: number,
): { x: number; y: number; visible: boolean } {
  const a = raDeg * DEG2RAD;
  const d = decDeg * DEG2RAD;
  const a0 = centerRA * DEG2RAD;
  const d0 = centerDec * DEG2RAD;

  const cosC = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * Math.cos(d) * Math.cos(a - a0);
  if (cosC <= 0.05) {
    return { x: -9999, y: -9999, visible: false };
  }

  // Standard plane coordinates (radians) where +xi points East and +eta points North
  const xi = (Math.cos(d) * Math.sin(a - a0)) / cosC;
  const eta = (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * Math.cos(d) * Math.cos(a - a0)) / cosC;

  const minDim = Math.min(width, height) || 600;
  const pxPerRad = minDim / (2 * Math.tan((fovDeg * DEG2RAD) / 2));

  // East is to the left in sky view (-xi), North is up (-eta)
  const x = width / 2 - xi * pxPerRad;
  const y = height / 2 - eta * pxPerRad;
  return { x, y, visible: true };
}

/**
 * Inverse Gnomonic (TAN) projection from canvas pixel (x, y) to ICRS (RA, Dec).
 */
export function gnomonicUnproject(
  pixelX: number,
  pixelY: number,
  centerRA: number,
  centerDec: number,
  fovDeg: number,
  width: number,
  height: number,
): { ra: number; dec: number } {
  const minDim = Math.min(width, height) || 600;
  const pxPerRad = minDim / (2 * Math.tan((fovDeg * DEG2RAD) / 2));

  const xi = -(pixelX - width / 2) / pxPerRad;
  const eta = -(pixelY - height / 2) / pxPerRad;

  const a0 = centerRA * DEG2RAD;
  const d0 = centerDec * DEG2RAD;
  const rho = Math.hypot(xi, eta);

  if (rho < 1e-12) {
    return { ra: normalizeRA(centerRA), dec: clampDec(centerDec) };
  }

  const c = Math.atan(rho);
  const sinC = Math.sin(c);
  const cosC = Math.cos(c);

  const dec = Math.asin(Math.max(-1, Math.min(1, cosC * Math.sin(d0) + (eta * sinC * Math.cos(d0)) / rho)));
  const ra = a0 + Math.atan2(xi * sinC, rho * Math.cos(d0) * cosC - eta * Math.sin(d0) * sinC);

  return {
    ra: Number(normalizeRA(ra * RAD2DEG).toFixed(6)),
    dec: Number(clampDec(dec * RAD2DEG).toFixed(6)),
  };
}

export function canvasPixelToCelestial(
  pixelX: number,
  pixelY: number,
  canvasWidth: number,
  canvasHeight: number,
  centerRA: number,
  centerDec: number,
  fovDeg: number,
): { ra: number; dec: number } {
  return gnomonicUnproject(pixelX, pixelY, centerRA, centerDec, fovDeg, canvasWidth, canvasHeight);
}

/**
 * Compute angular separation in arcseconds via Vincenty spherical formula.
 */
export function angularSeparationArcsec(ra1Deg: number, dec1Deg: number, ra2Deg: number, dec2Deg: number): number {
  const a1 = ra1Deg * DEG2RAD;
  const d1 = dec1Deg * DEG2RAD;
  const a2 = ra2Deg * DEG2RAD;
  const d2 = dec2Deg * DEG2RAD;
  const da = a2 - a1;
  const num = Math.hypot(Math.cos(d2) * Math.sin(da), Math.cos(d1) * Math.sin(d2) - Math.sin(d1) * Math.cos(d2) * Math.cos(da));
  const den = Math.sin(d1) * Math.sin(d2) + Math.cos(d1) * Math.cos(d2) * Math.cos(da);
  return Math.atan2(num, den) * RAD2DEG * 3600;
}
