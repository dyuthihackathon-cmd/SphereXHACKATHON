import type { LayerItem, SPHERExBand } from '../types/index.ts';

export function generateSPHERExBands(): SPHERExBand[] {
  return [];
}

export const SPHEREX_BANDS: SPHERExBand[] = [];

export function getBandById(bandId: number): SPHERExBand | undefined {
  return SPHEREX_BANDS.find((b) => b.id === bandId);
}

export const DEFAULT_LAYERS: LayerItem[] = [
  {
    id: 'coord_grid',
    name: 'Celestial Coordinate Grid',
    category: 'grid',
    sourceType: 'Reference Catalogue',
    enabled: true,
    available: true,
    description: 'Calibrated ICRS Right Ascension and Declination graticule in TAN projection.',
  },
  {
    id: 'galactic_plane',
    name: 'Galactic Equator (b = 0°)',
    category: 'galactic',
    sourceType: 'Reference Catalogue',
    enabled: true,
    available: true,
    description: 'IAU J2000 Galactic equator trajectory transformed to ICRS.',
  },
  {
    id: 'spx_observations',
    name: 'Selected Archive Image Cutout',
    category: 'observations',
    sourceType: 'Actual SPHEREx Observation',
    enabled: false,
    available: false,
    description: 'Loaded SPHEREx / WISE FITS cutout rendered with server-side WCS.',
  },
  {
    id: 'spx_coverage_map',
    name: 'Observation Search Footprints',
    category: 'observations',
    sourceType: 'Actual SPHEREx Observation',
    enabled: true,
    available: false,
    description: 'Positions of retrieved SPHEREx / WISE / ZTF observations.',
  },
  {
    id: 'known_objects',
    name: 'Gaia DR3 Source Overlay',
    category: 'known_objects',
    sourceType: 'Reference Catalogue',
    enabled: true,
    available: false,
    description: 'Real Gaia DR3 sources retrieved from TAP cone search.',
  },
  {
    id: 'moving_candidates',
    name: 'Moving-Object Candidates & Ephemerides',
    category: 'candidates',
    sourceType: 'Unverified Candidate',
    enabled: true,
    available: false,
    description: 'Detected candidate tracks and JPL Horizons ephemeris points.',
  },
  {
    id: 'observation_differences',
    name: 'Proper Motion Trajectories',
    category: 'differences',
    sourceType: 'Reference Catalogue',
    enabled: true,
    available: false,
    description: 'Astropy apply_space_motion tracks propagated from J2016.0.',
  },
];

export const BENCHMARK_TARGETS = [
  {
    label: 'WISE 0855',
    subtitle: 'Coldest brown dwarf (~250 K) · 8.1″/yr PM',
    ra: 133.79512917,
    dec: -7.24514722,
  },
  {
    label: "Barnard's Star",
    subtitle: 'High proper motion M4V (~10.4″/yr)',
    ra: 269.4485025,
    dec: 4.73942,
  },
  {
    label: 'RW Aurigae',
    subtitle: 'Variable T Tauri star (ZTF + NEOWISE coverage)',
    ra: 76.9565,
    dec: 30.4014,
  },
  {
    label: 'M31 (Andromeda)',
    subtitle: 'Nearby spiral galaxy reference field',
    ra: 10.6847083,
    dec: 41.26875,
  },
] as const;

export const HIPS_SURVEY_OPTIONS = [
  { id: 'allwise_rgb', label: 'AllWISE Color (W4/W2/W1)', provider: 'NASA/IPAC IRSA HiPS' },
  { id: 'allwise_w1', label: 'AllWISE W1 (3.4 µm)', provider: 'NASA/IPAC IRSA HiPS' },
  { id: 'allwise_w2', label: 'AllWISE W2 (4.6 µm)', provider: 'NASA/IPAC IRSA HiPS' },
  { id: 'spherex_cube', label: 'SPHEREx DR1 All-Sky HiPS', provider: 'NASA/IPAC IRSA HiPS' },
  { id: '2mass_color', label: '2MASS JHK Color', provider: 'NASA/IPAC IRSA HiPS' },
  { id: 'dss2_color', label: 'DSS2 Optical Color', provider: 'NASA/IPAC IRSA HiPS' },
  { id: 'sdss9_color', label: 'SDSS DR9 Optical', provider: 'NASA/IPAC IRSA HiPS' },
] as const;

export const OBSERVATION_PIPELINE_STATUS = {
  connected: true,
  archiveSource: 'NASA / IPAC IRSA, S3 Open Data, ESA Gaia, ZTF DR24, JPL Horizons & MPC',
  statusMessage: 'Real multi-wavelength archive bridge active. No synthetic data is generated.',
};
