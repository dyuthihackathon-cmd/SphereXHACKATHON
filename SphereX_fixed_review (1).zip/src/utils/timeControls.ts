/**
 * Time manipulation and validation utilities for astronomical observations
 */

export function parseValidDate(input: string | number | Date | null | undefined): Date | null {
  if (input === null || input === undefined || input === '') return null;
  const d = input instanceof Date ? new Date(input.getTime()) : new Date(input);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function stepObservationTime(currentDate: Date, secondsDelta: number): Date {
  return new Date(currentDate.getTime() + secondsDelta * 1000);
}

export function getJulianDate(date: Date): number {
  const time = date.getTime();
  return time / 86400000 + 2440587.5;
}

export function getModifiedJulianDate(date: Date): number {
  return getJulianDate(date) - 2400000.5;
}

export function formatUTC(date: Date): string {
  if (Number.isNaN(date.getTime())) return 'Time unavailable';
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  const h = String(date.getUTCHours()).padStart(2, '0');
  const min = String(date.getUTCMinutes()).padStart(2, '0');
  const s = String(date.getUTCSeconds()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${min}:${s} UTC`;
}

export function formatAstroTime(
  input: string | number | Date | null | undefined,
  format: 'UTC' | 'JD' | 'MJD' = 'UTC',
): string {
  const d = parseValidDate(input);
  if (!d) return 'Time unavailable';
  if (format === 'JD') return `JD ${getJulianDate(d).toFixed(5)}`;
  if (format === 'MJD') return `MJD ${getModifiedJulianDate(d).toFixed(5)}`;
  return formatUTC(d);
}
