import test from 'node:test';
import assert from 'node:assert/strict';
import { stepObservationTime, getJulianDate, getModifiedJulianDate, formatUTC, formatAstroTime } from './timeControls.ts';

test('stepObservationTime moves time by exact seconds delta', () => {
  const base = new Date('2026-06-15T12:00:00.000Z');
  assert.equal(stepObservationTime(base, 2).toISOString(), '2026-06-15T12:00:02.000Z');
  assert.equal(stepObservationTime(base, -2).toISOString(), '2026-06-15T11:59:58.000Z');
});

test('getJulianDate and getModifiedJulianDate calculate astronomical dates correctly', () => {
  const unixEpoch = new Date('1970-01-01T00:00:00.000Z');
  assert.equal(getJulianDate(unixEpoch), 2440587.5);
  assert.equal(getModifiedJulianDate(unixEpoch), 40587.0);

  const j2000 = new Date('2000-01-01T12:00:00.000Z');
  assert.equal(getJulianDate(j2000), 2451545.0);
  assert.equal(getModifiedJulianDate(j2000), 51544.5);
});

test('formatUTC and formatAstroTime validate invalid timestamps cleanly', () => {
  const date = new Date('2026-11-10T22:15:30.000Z');
  assert.equal(formatUTC(date), '2026-11-10 22:15:30 UTC');
  assert.equal(formatAstroTime('not-a-valid-date', 'UTC'), 'Time unavailable');
  assert.equal(formatAstroTime(null, 'MJD'), 'Time unavailable');
});
