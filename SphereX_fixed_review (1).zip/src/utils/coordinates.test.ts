import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatRA,
  formatDec,
  parseRA,
  parseDec,
  equatorialToGalactic,
  galacticToEquatorial,
  gnomonicProject,
  gnomonicUnproject,
  canvasPixelToCelestial,
  angularSeparationArcsec,
} from './coordinates.ts';

test('formatRA correctly formats degrees into sexagesimal hours, minutes, seconds', () => {
  assert.equal(formatRA(0), '00h 00m 00.00s');
  assert.equal(formatRA(15), '01h 00m 00.00s');
  assert.equal(formatRA(359.9999999), '00h 00m 00.00s');
  const formatted = formatRA(279.23);
  assert.ok(formatted.startsWith('18h 36m'), `Expected 18h 36m, got ${formatted}`);
});

test('formatDec correctly formats degrees into sexagesimal degrees, arcminutes, arcseconds', () => {
  assert.equal(formatDec(0), '+00° 00′ 00.0″');
  assert.equal(formatDec(38.78), '+38° 46′ 48.0″');
  assert.equal(formatDec(-12.5), '-12° 30′ 00.0″');
  assert.equal(formatDec(12 + 59 / 60 + 59.96 / 3600), '+13° 00′ 00.0″');
});

test('parseRA and parseDec parse decimal and sexagesimal strings and reject invalid values', () => {
  assert.equal(parseRA('15'), 15);
  assert.equal(parseRA('01h 00m 00s'), 15);
  assert.equal(parseRA('invalid'), null);
  assert.equal(parseDec('+38.5'), 38.5);
  assert.equal(parseDec('-12.5'), -12.5);
  assert.equal(parseDec('+38° 30′ 00″'), 38.5);
  assert.equal(parseDec('invalid'), null);
});

test('equatorialToGalactic and galacticToEquatorial form a round trip', () => {
  const gal = equatorialToGalactic(266.4, -29.0);
  assert.ok(Math.abs(gal.b) < 3, `Expected b near 0°, got ${gal.b}`);
  const eq = galacticToEquatorial(gal.l, gal.b);
  assert.ok(angularSeparationArcsec(266.4, -29.0, eq.ra, eq.dec) < 2.0);
});

test('gnomonic TAN projection round-trips accurately across RA=0/360 boundary', () => {
  const proj = gnomonicProject(0.2, -7.2, 359.8, -7.0, 4.0, 800, 600);
  assert.equal(proj.visible, true);
  const back = gnomonicUnproject(proj.x, proj.y, 359.8, -7.0, 4.0, 800, 600);
  assert.ok(angularSeparationArcsec(0.2, -7.2, back.ra, back.dec) < 0.05);
});

test('canvasPixelToCelestial maps center pixel to center coordinates', () => {
  const result = canvasPixelToCelestial(400, 300, 800, 600, 50, 20, 10);
  assert.equal(result.ra, 50);
  assert.equal(result.dec, 20);
});
