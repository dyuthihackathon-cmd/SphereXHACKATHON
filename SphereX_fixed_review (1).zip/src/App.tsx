import React, { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { IntroAnimation } from './components/IntroAnimation';
import { TopNavigation } from './components/TopNavigation';
import { SkyViewer } from './components/SkyViewer';
import { BottomToolbar } from './components/BottomToolbar';
import { LayersPanel } from './components/LayersPanel';
import { SearchPanel } from './components/SearchPanel';
import { CoordinateInspector } from './components/CoordinateInspector';
import { QualityControlPanel } from './components/QualityControlPanel';
import { InfraredAdjustmentPanel } from './components/InfraredAdjustmentPanel';

const ObservationsExplorer = lazy(() => import('./components/ObservationsExplorer').then((m) => ({ default: m.ObservationsExplorer })));
const SpectralExplorer = lazy(() => import('./components/SpectralExplorer').then((m) => ({ default: m.SpectralExplorer })));
const TimeDomainWorkspace = lazy(() => import('./components/TimeDomainWorkspace').then((m) => ({ default: m.TimeDomainWorkspace })));
const CompareWorkspace = lazy(() => import('./components/CompareWorkspace').then((m) => ({ default: m.CompareWorkspace })));
const SourcesWorkspace = lazy(() => import('./components/SourcesWorkspace').then((m) => ({ default: m.SourcesWorkspace })));
const MovingObjectsWorkspace = lazy(() => import('./components/MovingObjectsWorkspace').then((m) => ({ default: m.MovingObjectsWorkspace })));
const ResearchExportWorkspace = lazy(() => import('./components/ResearchExportWorkspace').then((m) => ({ default: m.ResearchExportWorkspace })));
import {
  ActiveWorkspace,
  ArchiveObservation,
  FitsQualityInspection,
  GaiaSourceRecord,
  InfraredAdjustments,
  LayerItem,
  MovingObjectCandidate,
  ProperMotionResult,
  ProvenanceRecord,
  SavedResearchArtifact,
  SkyCoordinate,
} from './types';
import { BENCHMARK_TARGETS, DEFAULT_LAYERS } from './utils/spherexData';
import {
  getObservationFitsUrl,
  getObservationPreviewUrl,
  inspectObservationFits,
  pixelToWorld,
} from './services/spherexApi';

const DEFAULT_ADJUSTMENTS: InfraredAdjustments = {
  brightness: 0,
  contrast: 1.0,
  intensity: 1.0,
  stretch: 'asinh',
  palette: 'monochrome',
  activeBandId: 1,
  extName: 'IMAGE',
};

export function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [workspace, setWorkspace] = useState<ActiveWorkspace>('sky');
  const handleIntroComplete = useCallback(() => setShowIntro(false), []);

  // Sky / Coordinate State (Defaults to WISE 0855 benchmark target or user-steered field)
  const [centerRA, setCenterRA] = useState<number>(BENCHMARK_TARGETS[0].ra);
  const [centerDec, setCenterDec] = useState<number>(BENCHMARK_TARGETS[0].dec);
  const [fovArcmin, setFovArcmin] = useState<number>(6.0);
  const [zoomFactor, setZoomFactor] = useState<number>(1.0);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hipsSurvey, setHipsSurvey] = useState<string>('allwise_rgb');
  const [selectedCoordinate, setSelectedCoordinate] = useState<SkyCoordinate | null>(null);

  // Panels & Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLayersOpen, setIsLayersOpen] = useState(false);
  const [isInfraredAdjustOpen, setIsInfraredAdjustOpen] = useState(false);
  const [isQualityOpen, setIsQualityOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Layers & Display Settings
  const [layers, setLayers] = useState<LayerItem[]>(DEFAULT_LAYERS);
  const [adjustments, setAdjustments] = useState<InfraredAdjustments>(DEFAULT_ADJUSTMENTS);

  // User Preferences (exposed in Research & Export)
  const [timeFormat, setTimeFormat] = useState<'UTC' | 'JD' | 'MJD'>('UTC');
  const [coordFormat, setCoordFormat] = useState<'sexagesimal' | 'decimal'>('sexagesimal');
  const [stepSeconds, setStepSeconds] = useState<number>(1800);

  // Loaded Scientific Datasets
  const [observations, setObservations] = useState<ArchiveObservation[]>([]);
  const [activeObsIndex, setActiveObsIndex] = useState<number>(-1);
  const [isCutoutLoading, setIsCutoutLoading] = useState(false);
  const [cutoutError, setCutoutError] = useState<string | null>(null);
  const [isPlayingEpochs, setIsPlayingEpochs] = useState(false);

  const [gaiaSources, setGaiaSources] = useState<GaiaSourceRecord[]>([]);
  const [properMotion, setProperMotion] = useState<ProperMotionResult | null>(null);
  const [candidates, setCandidates] = useState<MovingObjectCandidate[]>([]);
  const [comparePair, setComparePair] = useState<{ a: ArchiveObservation | null; b: ArchiveObservation | null }>({
    a: null,
    b: null,
  });

  // Quality Inspection State
  const [qcInspection, setQcInspection] = useState<FitsQualityInspection | null>(null);
  const [qcProvenance, setQcProvenance] = useState<ProvenanceRecord | null>(null);
  const [qcLoading, setQcLoading] = useState(false);
  const [qcError, setQcError] = useState<string | null>(null);

  // Research Artifact Ledger
  const [researchArtifacts, setResearchArtifacts] = useState<SavedResearchArtifact[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeObservation = activeObsIndex >= 0 && activeObsIndex < observations.length ? observations[activeObsIndex] : null;
  const cutoutEnabled = layers.some((l) => l.id === 'spx_observations' && l.enabled);

  const activeCutoutUrl = useMemo(() => {
    if (!activeObservation || !cutoutEnabled) return null;
    return getObservationPreviewUrl(activeObservation, centerRA, centerDec, fovArcmin, {
      stretch: adjustments.stretch,
      palette: adjustments.palette,
      extName: adjustments.extName,
    });
  }, [activeObservation, cutoutEnabled, centerRA, centerDec, fovArcmin, adjustments.stretch, adjustments.palette, adjustments.extName]);

  useEffect(() => {
    setCutoutError(null);
    setIsCutoutLoading(Boolean(activeCutoutUrl));
  }, [activeCutoutUrl]);

  // Synchronize layer availability with live data state
  useEffect(() => {
    setLayers((prev) =>
      prev.map((layer) => {
        if (layer.id === 'spx_observations') return { ...layer, available: Boolean(activeObservation) };
        if (layer.id === 'spx_coverage_map') return { ...layer, available: observations.length > 0 };
        if (layer.id === 'known_objects') return { ...layer, available: gaiaSources.length > 0 };
        if (layer.id === 'observation_differences') return { ...layer, available: Boolean(properMotion) };
        if (layer.id === 'moving_candidates') return { ...layer, available: candidates.length > 0 };
        return layer;
      }),
    );
  }, [activeObservation, observations.length, gaiaSources.length, properMotion, candidates.length]);

  // Multi-epoch sky viewer playback
  useEffect(() => {
    if (!isPlayingEpochs || observations.length < 2) return;
    const id = window.setInterval(() => {
      setActiveObsIndex((prev) => (prev + 1) % observations.length);
    }, 1500);
    return () => window.clearInterval(id);
  }, [isPlayingEpochs, observations.length]);

  const navigateToCoord = useCallback((ra: number, dec: number, select = true) => {
    setCenterRA(ra);
    setCenterDec(dec);
    setPanOffset({ x: 0, y: 0 });
    if (select) {
      setSelectedCoordinate({
        ra,
        dec,
        isScientific: true,
        coordinateSource: 'Manual Target Entry',
      });
    }
  }, []);

  const handleLoadToSkyViewer = useCallback((obs: ArchiveObservation, index: number) => {
    setActiveObsIndex(index);
    if (obs.ra !== null && obs.dec !== null) {
      setCenterRA(obs.ra);
      setCenterDec(obs.dec);
      setPanOffset({ x: 0, y: 0 });
    }
    setLayers((prev) =>
      prev.map((l) => (l.id === 'spx_observations' ? { ...l, available: true, enabled: true } : l)),
    );
    setWorkspace('sky');
  }, []);

  const handleInspectFits = useCallback(
    async (obs: ArchiveObservation) => {
      setIsQualityOpen(true);
      setQcLoading(true);
      setQcError(null);
      try {
        const res = await inspectObservationFits(obs, centerRA, centerDec, fovArcmin, adjustments.extName);
        setQcInspection(res);
        setQcProvenance(res.provenance ?? obs.provenance ?? null);
      } catch (err) {
        setQcError(err instanceof Error ? err.message : 'FITS inspection failed.');
      } finally {
        setQcLoading(false);
      }
    },
    [centerRA, centerDec, fovArcmin, adjustments.extName],
  );

  const handleCanvasPixelClick = useCallback(
    async (normX: number, normY: number, naturalWidth: number, naturalHeight: number) => {
      if (!activeObservation) return;
      const px = Math.max(0, Math.min(naturalWidth - 1, normX * (naturalWidth - 1)));
      // Fits preview flips vertically via np.flipud so FITS row 0 is at the bottom
      const py = Math.max(0, Math.min(naturalHeight - 1, (1 - normY) * (naturalHeight - 1)));
      const isWise = (activeObservation.mission || activeObservation.source || '').toLowerCase().includes('wise');
      try {
        const wcsRes = await pixelToWorld({
          access_url: activeObservation.access_url,
          mission: isWise ? 'wise' : 'spherex',
          ra: centerRA,
          dec: centerDec,
          fov_arcmin: fovArcmin,
          pixel_x: px,
          pixel_y: py,
          ext_name: adjustments.extName,
        });
        setSelectedCoordinate({
          ra: wcsRes.ra,
          dec: wcsRes.dec,
          isScientific: true,
          pixelX: Math.round(wcsRes.pixel_x),
          pixelY: Math.round(wcsRes.pixel_y),
          coordinateSource: 'WCS FITS Header',
          surfaceBrightness: wcsRes.pixel_value,
          units: wcsRes.bunit,
        });
      } catch {
        // Fallback already handled if cutout lacks WCS
      }
    },
    [activeObservation, centerRA, centerDec, fovArcmin, adjustments.extName],
  );

  const handleSaveResearch = useCallback(
    (
      title: string,
      kind: SavedResearchArtifact['kind'],
      summary: string,
      payload: unknown,
      provenance?: ProvenanceRecord,
    ) => {
      setResearchArtifacts((prev) => [
        {
          id: `${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          createdAtUtc: new Date().toISOString(),
          kind,
          title,
          ra: centerRA,
          dec: centerDec,
          summary,
          provenance,
          payload,
        },
        ...prev,
      ]);
    },
    [centerRA, centerDec],
  );

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement && containerRef.current) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else if (document.fullscreenElement) {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  useEffect(() => {
    const syncFullscreenState = () => {
      setIsFullscreen(Boolean(document.fullscreenElement && document.fullscreenElement === containerRef.current));
    };
    document.addEventListener('fullscreenchange', syncFullscreenState);
    return () => document.removeEventListener('fullscreenchange', syncFullscreenState);
  }, []);

  const handleDownloadPngSnapshot = () => {
    const imgEl = document.getElementById('spherex-viewer-image') as HTMLImageElement | null;
    if (imgEl && imgEl.src) {
      const a = document.createElement('a');
      a.href = imgEl.src;
      a.download = `spherex_cutout_${centerRA.toFixed(3)}_${centerDec.toFixed(3)}.png`;
      a.click();
      return;
    }
    const canvas = document.getElementById('spherex-viewer-canvas') as HTMLCanvasElement | null;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `spherex_hips_${hipsSurvey}_${centerRA.toFixed(3)}_${centerDec.toFixed(3)}.png`;
    a.click();
  };

  // Global keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) return;
      if (e.key === 'Escape') {
        setIsSearchOpen(false);
        setIsLayersOpen(false);
        setIsInfraredAdjustOpen(false);
        setIsQualityOpen(false);
      } else if (e.key === '/' || (e.key === 'k' && (e.ctrlKey || e.metaKey))) {
        e.preventDefault();
        setIsSearchOpen(true);
      } else if (workspace === 'sky') {
        if (e.key === '+' || e.key === '=') setZoomFactor((z) => Math.min(8, Number((z * 1.25).toFixed(2))));
        if (e.key === '-') setZoomFactor((z) => Math.max(0.25, Number((z / 1.25).toFixed(2))));
        if (e.key === 'ArrowRight' && observations.length > 0) {
          setActiveObsIndex((i) => (i + 1) % observations.length);
        }
        if (e.key === 'ArrowLeft' && observations.length > 0) {
          setActiveObsIndex((i) => (i <= 0 ? observations.length - 1 : i - 1));
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [workspace, observations.length]);

  const cssFilter = useMemo(() => {
    if (!activeCutoutUrl) return undefined;
    const b = 100 + adjustments.brightness * 0.5;
    const c = adjustments.contrast * 100;
    const s = adjustments.intensity * 100;
    return `brightness(${b}%) contrast(${c}%) saturate(${s}%)`;
  }, [activeCutoutUrl, adjustments.brightness, adjustments.contrast, adjustments.intensity]);

  const activeLayerCount = layers.filter((l) => l.enabled && l.available).length;
  const fitsDownloadUrl = activeObservation
    ? getObservationFitsUrl(activeObservation, centerRA, centerDec, fovArcmin)
    : null;

  return (
    <div ref={containerRef} className="h-screen w-screen flex flex-col bg-[#05070b] text-slate-100 overflow-hidden">
      {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}

      <TopNavigation
        currentWorkspace={workspace}
        onSelectWorkspace={setWorkspace}
        onToggleSearch={() => setIsSearchOpen(true)}
      />

      <main className="flex-1 min-h-0 relative flex flex-col overflow-hidden">
        <Suspense fallback={<div className="flex-1 grid place-items-center text-xs text-slate-400" role="status">Loading workspace…</div>}>
        {workspace === 'sky' && (
          <div className="flex-1 min-h-0 relative flex overflow-hidden">
            <SkyViewer
              layers={layers}
              zoomFactor={zoomFactor}
              panOffset={panOffset}
              onPanChange={setPanOffset}
              centerRA={centerRA}
              centerDec={centerDec}
              fovDeg={Math.max(0.15, fovArcmin / 60 * 6)}
              selectedCoordinate={selectedCoordinate}
              onSelectCoordinate={setSelectedCoordinate}
              onZoomChange={setZoomFactor}
              hipsSurvey={hipsSurvey}
              imageSrc={activeCutoutUrl}
              onImageLoaded={() => {
                setIsCutoutLoading(false);
                setCutoutError(null);
              }}
              onImageError={() => {
                setIsCutoutLoading(false);
                setCutoutError('Preview unavailable. Check the backend and archive connection.');
              }}
              imageError={cutoutError}
              isImageLoading={isCutoutLoading}
              imageFilter={cssFilter}
              observations={observations}
              gaiaSources={gaiaSources}
              properMotion={properMotion}
              candidates={candidates}
              onCanvasPixelClick={handleCanvasPixelClick}
              activeObservationLabel={
                activeObservation ? `${activeObservation.id} (${adjustments.extName})` : null
              }
            />

            {selectedCoordinate && (
              <CoordinateInspector
                coordinate={selectedCoordinate}
                onClear={() => setSelectedCoordinate(null)}
                onInspectSpectrum={(ra, dec) => {
                  setCenterRA(ra);
                  setCenterDec(dec);
                  setWorkspace('spectral');
                }}
                onSearchArchives={(ra, dec) => {
                  setCenterRA(ra);
                  setCenterDec(dec);
                  setWorkspace('observations');
                }}
              />
            )}

            <LayersPanel
              isOpen={isLayersOpen}
              onClose={() => setIsLayersOpen(false)}
              layers={layers}
              onToggleLayer={(id) =>
                setLayers((prev) => prev.map((l) => (l.id === id ? { ...l, enabled: !l.enabled } : l)))
              }
              onResetLayers={() => setLayers(DEFAULT_LAYERS)}
              onSetAllLayers={(enabled) =>
                setLayers((prev) => prev.map((l) => (l.available ? { ...l, enabled } : l)))
              }
            />

            {isInfraredAdjustOpen && (
              <InfraredAdjustmentPanel
                adjustments={adjustments}
                onChangeAdjustments={setAdjustments}
                onReset={() => setAdjustments(DEFAULT_ADJUSTMENTS)}
                onClose={() => setIsInfraredAdjustOpen(false)}
                hasActiveCutout={Boolean(activeObservation)}
              />
            )}
          </div>
        )}

        {workspace === 'observations' && (
          <ObservationsExplorer
            centerRA={centerRA}
            centerDec={centerDec}
            onUpdateCenter={(ra, dec) => navigateToCoord(ra, dec, false)}
            observations={observations}
            onObservationsChange={(items, ra, dec, fov) => {
              setObservations(items);
              setCenterRA(ra);
              setCenterDec(dec);
              setFovArcmin(fov);
              setActiveObsIndex(items.length > 0 ? 0 : -1);
            }}
            onLoadToSkyViewer={handleLoadToSkyViewer}
            onInspectFits={handleInspectFits}
            onSendToCompare={(obsA, obsB) => {
              setComparePair({ a: obsA, b: obsB });
              setWorkspace('compare');
            }}
            onSaveResearch={(title, kind, summary, payload) =>
              handleSaveResearch(title, kind, summary, payload)
            }
            timeFormat={timeFormat}
          />
        )}

        {workspace === 'spectral' && (
          <SpectralExplorer
            centerRA={centerRA}
            centerDec={centerDec}
            onUpdateCenter={(ra, dec) => navigateToCoord(ra, dec, false)}
            stretch={adjustments.stretch}
            palette={adjustments.palette === 'monochrome' ? 'spherex_ir' : adjustments.palette}
            onSaveResearch={handleSaveResearch}
          />
        )}

        {workspace === 'time-domain' && (
          <TimeDomainWorkspace
            centerRA={centerRA}
            centerDec={centerDec}
            observations={observations}
            fovArcmin={fovArcmin}
            timeFormat={timeFormat}
            stretch={adjustments.stretch}
            palette={adjustments.palette}
            onSaveResearch={handleSaveResearch}
          />
        )}

        {workspace === 'compare' && (
          <CompareWorkspace
            centerRA={centerRA}
            centerDec={centerDec}
            fovArcmin={fovArcmin}
            observations={observations}
            initialObsA={comparePair.a}
            initialObsB={comparePair.b}
            stretch={adjustments.stretch}
            palette={adjustments.palette}
            onSaveResearch={handleSaveResearch}
          />
        )}

        {workspace === 'sources' && (
          <SourcesWorkspace
            centerRA={centerRA}
            centerDec={centerDec}
            gaiaSources={gaiaSources}
            onGaiaSourcesLoaded={(sources, pm) => {
              setGaiaSources(sources);
              if (pm !== undefined) setProperMotion(pm);
            }}
            onNavigateToCoord={(ra, dec) => {
              navigateToCoord(ra, dec, true);
              setWorkspace('sky');
            }}
          />
        )}

        {workspace === 'moving-objects' && (
          <MovingObjectsWorkspace
            centerRA={centerRA}
            centerDec={centerDec}
            fovArcmin={fovArcmin}
            observations={observations}
            candidates={candidates}
            onCandidatesChange={setCandidates}
            onNavigateToCoord={(ra, dec) => {
              navigateToCoord(ra, dec, true);
              setWorkspace('sky');
            }}
            onSaveResearch={handleSaveResearch}
          />
        )}

        {workspace === 'research' && (
          <ResearchExportWorkspace
            artifacts={researchArtifacts}
            onRemoveArtifact={(id) => setResearchArtifacts((prev) => prev.filter((a) => a.id !== id))}
            timeFormat={timeFormat}
            onChangeTimeFormat={setTimeFormat}
            coordFormat={coordFormat}
            onChangeCoordFormat={setCoordFormat}
            stepSeconds={stepSeconds}
            onChangeStepSeconds={setStepSeconds}
          />
        )}
        </Suspense>
      </main>

      <QualityControlPanel
        isOpen={isQualityOpen}
        onClose={() => setIsQualityOpen(false)}
        inspection={qcInspection}
        provenance={qcProvenance}
        loading={qcLoading}
        error={qcError}
      />

      {workspace === 'sky' && (
        <BottomToolbar
          isPlaying={isPlayingEpochs}
          onTogglePlay={() => setIsPlayingEpochs((p) => !p)}
          onStepBackward={() =>
            observations.length > 0 &&
            setActiveObsIndex((i) => (i <= 0 ? observations.length - 1 : i - 1))
          }
          onStepForward={() =>
            observations.length > 0 && setActiveObsIndex((i) => (i + 1) % observations.length)
          }
          onZoomIn={() => setZoomFactor((z) => Math.min(8, Number((z * 1.25).toFixed(2))))}
          onZoomOut={() => setZoomFactor((z) => Math.max(0.25, Number((z / 1.25).toFixed(2))))}
          onFitSky={() => {
            setZoomFactor(1.0);
            setPanOffset({ x: 0, y: 0 });
          }}
          onResetView={() => {
            setZoomFactor(1.0);
            setPanOffset({ x: 0, y: 0 });
            navigateToCoord(BENCHMARK_TARGETS[0].ra, BENCHMARK_TARGETS[0].dec, false);
          }}
          zoomFactor={zoomFactor}
          hipsSurvey={hipsSurvey}
          onChangeHipsSurvey={setHipsSurvey}
          isLayersOpen={isLayersOpen}
          onToggleLayers={() => setIsLayersOpen((o) => !o)}
          activeLayerCount={activeLayerCount}
          isInfraredAdjustOpen={isInfraredAdjustOpen}
          onToggleInfraredAdjust={() => setIsInfraredAdjustOpen((o) => !o)}
          isQualityOpen={isQualityOpen}
          onToggleQuality={() => {
            if (!isQualityOpen && activeObservation) {
              handleInspectFits(activeObservation);
            } else {
              setIsQualityOpen((o) => !o);
            }
          }}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          canNavigateObservations={observations.length > 0}
          canPlayObservations={observations.length > 1}
          onDownloadPngSnapshot={handleDownloadPngSnapshot}
          hasCutoutLoaded={Boolean(activeCutoutUrl)}
          fitsDownloadUrl={fitsDownloadUrl}
        />
      )}

      <SearchPanel
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigateToCoord={(coord) => {
          navigateToCoord(coord.ra, coord.dec, true);
          setWorkspace('sky');
        }}
      />
    </div>
  );
}

export default App;
